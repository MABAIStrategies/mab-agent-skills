# Prospect-to-Proposal Engine for Claude

This is a portable skill bundle for Claude. Install by pasting `instructions.md` into the platform's persistent instruction, project, space, or agent context area.

For best results, attach or reference the relevant Gmail exports, Drive docs, GitHub files, CRM rows, meeting notes, or source artifacts before asking the model to run the skill.
