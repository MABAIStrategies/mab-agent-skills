# Prospect-to-Proposal Engine for Perplexity

This is a portable skill bundle for Perplexity. Install by pasting `instructions.md` into the platform's persistent instruction, project, space, or agent context area.

For best results, attach or reference the relevant Gmail exports, Drive docs, GitHub files, CRM rows, meeting notes, or source artifacts before asking the model to run the skill.
