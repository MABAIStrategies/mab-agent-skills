# Skill Index

## skills

| Name | Main file | Files |
|---|---|---:|
| `01-competitive-intelligence` | `skills/01-competitive-intelligence/SKILL.md` | 6 |
| `02-client-health-monitor` | `skills/02-client-health-monitor/SKILL.md` | 3 |

## opencode-skills

| Name | Main file | Files |
|---|---|---:|
| `ai-agent-development-deployment-architect` | `opencode-skills/ai-agent-development-deployment-architect/SKILL.md` | 1 |
| `ai-automation-discovery-scoping-engine` | `opencode-skills/ai-automation-discovery-scoping-engine/SKILL.md` | 1 |
| `algorithmic-art` | `opencode-skills/algorithmic-art/SKILL.md` | 4 |
| `brand-guidelines` | `opencode-skills/brand-guidelines/SKILL.md` | 2 |
| `canvas-design` | `opencode-skills/canvas-design/SKILL.md` | 29 |
| `client-onboarding-success-playbook-generator` | `opencode-skills/client-onboarding-success-playbook-generator/SKILL.md` | 1 |
| `creative-catalyst-style` | `opencode-skills/creative-catalyst-style/SKILL.md` | 1 |
| `doc-coauthoring` | `opencode-skills/doc-coauthoring/SKILL.md` | 1 |
| `docx` | `opencode-skills/docx/SKILL.md` | 22 |
| `enterprise-sales-intelligence-architect` | `opencode-skills/enterprise-sales-intelligence-architect/SKILL.md` | 1 |
| `executive-business-intelligence-synthesizer` | `opencode-skills/executive-business-intelligence-synthesizer/SKILL.md` | 1 |
| `file-reading` | `opencode-skills/file-reading/SKILL.md` | 2 |
| `frontend-design` | `opencode-skills/frontend-design/SKILL.md` | 2 |
| `innovative-strategist-style` | `opencode-skills/innovative-strategist-style/SKILL.md` | 1 |
| `job-hunt-os` | `opencode-skills/job-hunt-os/SKILL.md` | 15 |
| `learn` | `opencode-skills/learn/SKILL.md` | 2 |
| `legal-strategist-style` | `opencode-skills/legal-strategist-style/SKILL.md` | 1 |
| `mab-conversion-engine` | `opencode-skills/mab-conversion-engine/SKILL.md` | 1 |
| `mab-outbound-swarm` | `opencode-skills/mab-outbound-swarm/SKILL.md` | 5 |
| `mab-revenue-pulse` | `opencode-skills/mab-revenue-pulse/SKILL.md` | 5 |
| `mab-strategy-intelligence-vault` | `opencode-skills/mab-strategy-intelligence-vault/SKILL.md` | 1 |
| `mab-vertical-strategy-engine` | `opencode-skills/mab-vertical-strategy-engine/SKILL.md` | 8 |
| `mcp-builder` | `opencode-skills/mcp-builder/SKILL.md` | 10 |
| `pdf` | `opencode-skills/pdf/SKILL.md` | 12 |
| `pdf-reading` | `opencode-skills/pdf-reading/SKILL.md` | 3 |
| `pptx` | `opencode-skills/pptx/SKILL.md` | 20 |
| `production-engineer-style` | `opencode-skills/production-engineer-style/SKILL.md` | 1 |
| `proposal-pitch-deck-designer` | `opencode-skills/proposal-pitch-deck-designer/SKILL.md` | 1 |
| `resume-optimizer` | `opencode-skills/resume-optimizer/SKILL.md` | 1 |
| `skill-creator` | `opencode-skills/skill-creator/SKILL.md` | 18 |
| `skill-modernizer` | `opencode-skills/skill-modernizer/SKILL.md` | 1 |
| `theme-factory` | `opencode-skills/theme-factory/SKILL.md` | 12 |
| `web-artifacts-builder` | `opencode-skills/web-artifacts-builder/SKILL.md` | 4 |
| `xlsx` | `opencode-skills/xlsx/SKILL.md` | 15 |

## chatgpt-skills

| Name | Main file | Files |
|---|---|---:|
| `ai-native-teaching-studio` | `chatgpt-skills/ai-native-teaching-studio/SKILL.md` | 3 |
| `b2b-lead-generation` | `chatgpt-skills/b2b-lead-generation/b2b-lead-generation.skill` | 1 |
| `founder-operating-system` | `chatgpt-skills/founder-operating-system/SKILL.md` | 3 |
| `industry-research-report-writer` | `chatgpt-skills/industry-research-report-writer/industry-research-report-writer.skill` | 1 |
| `interactive-visualization-architect` | `chatgpt-skills/interactive-visualization-architect/interactive-visualization-architect.skill` | 1 |
| `landing-page-builder` | `chatgpt-skills/landing-page-builder/landing-page-builder.skill` | 1 |
| `prospect-to-proposal-engine` | `chatgpt-skills/prospect-to-proposal-engine/SKILL.md` | 3 |
| `sales-power-map` | `chatgpt-skills/sales-power-map/sales-power-map.skill` | 1 |
| `seo-geo-optimization-expert` | `chatgpt-skills/seo-geo-optimization-expert/seo-geo-optimization-expert.skill` | 2 |
| `video-story-generator` | `chatgpt-skills/video-story-generator/video-story-generator.skill` | 2 |

## multi-platform-bundles

| Name | Main file | Files |
|---|---|---:|
| `founder-operating-system` | `multi-platform-bundles/founder-operating-system/founder-operating-system-antigravity/founder-operating-system-antigravity/AGENTS.md` | 8 |
| `prospect-to-proposal` | `multi-platform-bundles/prospect-to-proposal/prospect-to-proposal-engine-antigravity/prospect-to-proposal-engine-antigravity/AGENTS.md` | 8 |

## plugins

| Name | Main file | Files |
|---|---|---:|
| `sales-persona-plugin` | `plugins/sales-persona-plugin/plugin_manifest.json` | 16 |

