# Third-Party Notices

This repository contains a mix of MAB-authored skills and third-party/open-source skill packs.

## License posture

- Keep each skill's embedded license file or attribution with that skill.
- Do not assume the entire repository is under one permissive license.
- For commercial redistribution, review each skill directory and its preserved license notice.

## Excluded vendored assets

To keep the repository lean and avoid unnecessary binary redistribution, this import excludes font binaries, binary showcases, compressed vendored bundles, and large Office schema directories from the uploaded ZIP set.

## Operational note

If a skill depends on an excluded binary or vendored asset, restore that asset from the original upstream source or a private artifact store rather than committing it directly to this public repository.
