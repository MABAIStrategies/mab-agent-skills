# Ingestion Report

## Summary

- Included files: 264
- Excluded items/files: 198
- Staged repository files including generated docs: 266

## Included categories

- `skills/`: 2 top-level entries
- `opencode-skills/`: 34 top-level entries
- `chatgpt-skills/`: 10 top-level entries
- `multi-platform-bundles/`: 2 top-level entries
- `plugins/`: 1 top-level entries

## Exclusion reasons

- large vendored Office schema excluded: 117
- font binary excluded: 54
- source ZIP excluded after extraction: 11
- duplicate ChatGPT bundle content represented in chatgpt-skills/: 6
- private/legal skill excluded from public repo: 4
- binary/vendored artifact excluded: 2
- exact duplicate of chatgpt-skills/interactive-visualization-architect/interactive-visualization-architect.skill: 1
- exact duplicate of chatgpt-skills/landing-page-builder/landing-page-builder.skill: 1
- exact duplicate of chatgpt-skills/sales-power-map/sales-power-map.skill: 1
- uploaded ZIP contained only an empty directory; no skill source files to commit: 1

## Sensitive-public-repo handling

One private/legal case-specific OpenCode skill was excluded from the public repository. Some operational references to a protected employer were sanitized to generic firewall terminology where the skill itself remained business-relevant.

## Empty uploads

The uploaded ZIP named for skills 03–10 contained only an empty directory and no source files. Those skills were not fabricated.
