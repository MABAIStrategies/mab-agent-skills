---
name: executive-business-intelligence-synthesizer
description: |
  Transforms raw business data, market research, and industry news into executive-ready intelligence reports. Specializes in identifying strategic implications, competitive threats, and growth opportunities from disparate sources. Creates MAB Mindsphere style digests that position insights for decision-making rather than information sharing. Provides multi-source synthesis, trend identification with business impact analysis, competitive intelligence patterns, executive summaries with implications, newsletter formatting, and strategic recommendations. Use for intelligence digests, QBR presentations, competitive briefs, and thought leadership content.
---
