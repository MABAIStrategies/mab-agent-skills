"""
MAB Revenue Pulse — orchestration script.

Repo root: /home/claude/mab-revenue-pulse/
CLI: bash / python 3.10+

Run: python -m scripts.run_pulse [--first-run] [--all] [--skip-vault]

This is the orchestration backbone. The skill's SKILL.md contains the
behavioral rules; this script is what executes them deterministically.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)
CONFIG_PATH = Path(__file__).parent / "config.json"


# ─── Data structures ────────────────────────────────────────────────────────


@dataclass
class Deal:
    id: str
    company: str
    contact_name: str
    contact_title: str
    stage: str
    value: float
    last_touch_at: datetime
    last_prospect_action_at: datetime | None
    champion_id: str | None
    notes: str
    is_executive_sponsor: bool = False
    is_starred: bool = False
    is_snoozed_until: datetime | None = None
    source_flags: list[str] | None = None  # e.g. ["protected-employer"] — must be filtered out


@dataclass
class StallSignal:
    deal: Deal
    reason: str  # one of: silent_decline, missing_next_step, proposal_drift, ...
    days_silent: int
    risk_score: float
    suggested_template: str
    personal_signal: str | None  # if None, flag "needs personal angle"


@dataclass
class DailyQuota:
    cold_outbound: int
    follow_ups: int
    call_books: int
    math_explanation: str


# ─── Configuration ──────────────────────────────────────────────────────────


def load_config() -> dict[str, Any]:
    with CONFIG_PATH.open() as f:
        return json.load(f)


# ─── Source loaders (stubs — implementations depend on Mark's actual stack) ──


def load_open_deals(cfg: dict) -> list[Deal]:
    """
    Pull open opportunities from MAB Prospector.

    Fallback chain (per Mark's defaults):
      1. Direct API if endpoint configured
      2. Google Sheets export pull
      3. CSV in /tmp/mab_prospector_export.csv
      4. Empty list + flag in brief
    """
    if cfg["guardrails"]["block_protected-employer_paths"]:
        # protected-employer firewall — confirmed in user preferences
        pass
    raise NotImplementedError(
        "Wire to MAB Prospector here. Until wired, run with CSV export at "
        "/tmp/mab_prospector_export.csv"
    )


def load_recent_email_threads(deal: Deal, days: int = 30) -> list[dict]:
    """Pull threaded conversations via Gmail MCP."""
    raise NotImplementedError("Connect Gmail MCP")


def load_calendar_events(deal: Deal, days_back: int = 14, days_forward: int = 14) -> list[dict]:
    """Pull discovery/demo/proposal calls from Google Calendar MCP."""
    raise NotImplementedError("Connect Calendar MCP")


# ─── Stall detection ────────────────────────────────────────────────────────


def detect_stall_signals(deal: Deal, threads: list[dict], events: list[dict],
                         cfg: dict) -> StallSignal | None:
    """Apply the six stall-reason rules from SKILL.md. Returns highest-priority match."""
    now = datetime.now(timezone.utc)
    thresholds = cfg["stall_thresholds_days"]

    days_since_prospect = (
        (now - deal.last_prospect_action_at).days
        if deal.last_prospect_action_at else 999
    )

    # Order matters — first match wins, more severe first
    if events_no_show_unrescheduled(events):
        return _build_signal(deal, "calendar_ghost", days_since_prospect,
                              "template_no_show_recover")
    if deal.stage == "proposal" and days_since_prospect >= thresholds["proposal_drift"]:
        return _build_signal(deal, "proposal_drift", days_since_prospect,
                              "template_proposal_followup_with_value_add")
    if had_recent_replies_then_silence(threads, thresholds["silent_decline"]):
        return _build_signal(deal, "silent_decline", days_since_prospect,
                              "template_breakup_v2")
    if champion_disengaged(deal, threads, thresholds["champion_silence"]):
        return _build_signal(deal, "champion_silence", days_since_prospect,
                              "template_champion_check_in")
    if last_email_lacks_next_step(threads):
        return _build_signal(deal, "missing_next_step", days_since_prospect,
                              "template_specific_ask")
    if stage_mismatch_with_activity(deal, threads, thresholds["stage_mismatch"]):
        return _build_signal(deal, "stage_mismatch", days_since_prospect,
                              "template_value_anchor")
    return None


def _build_signal(deal: Deal, reason: str, days: int, template: str) -> StallSignal:
    return StallSignal(
        deal=deal,
        reason=reason,
        days_silent=days,
        risk_score=score_risk(deal, days, reason),
        suggested_template=template,
        personal_signal=find_personal_signal(deal),
    )


# ─── Scoring (per references/pipeline_signals.md) ───────────────────────────


def score_risk(deal: Deal, days_silent: int, reason: str) -> float:
    """Composite risk score 0.0–1.0. See references/pipeline_signals.md."""
    value_w = _value_weight(deal)
    days_w = _days_weight(days_silent, deal.stage)
    stage_w = _stage_weight(deal)
    champ_w = _champion_weight(deal)
    score = (value_w * 0.4) + (days_w * 0.3) + (stage_w * 0.2) + (champ_w * 0.1)

    # Override flags
    if deal.is_executive_sponsor:
        score = max(score, 0.95)
    if deal.is_starred:
        score = max(score, 0.90)
    return min(score, 1.0)


def _value_weight(deal: Deal) -> float:
    # TODO: percentile against full open pipeline. Stub returns midpoint.
    return 0.5


def _days_weight(days: int, stage: str) -> float:
    if days <= 2: return 0.0
    if days <= 5: return 0.3
    if days <= 9: return 0.6
    if days <= 14: return 0.85
    base = 1.0
    if stage == "proposal":
        base = min(base * 1.2, 1.0)
    return base


def _stage_weight(deal: Deal) -> float:
    # TODO: compare to median days in stage for won deals. Stub returns 0.5.
    return 0.5


def _champion_weight(deal: Deal) -> float:
    # TODO: read champion engagement signals. Stub returns 0.3.
    return 0.3


# ─── Helpers (stubs to be wired) ────────────────────────────────────────────

def events_no_show_unrescheduled(events: list[dict]) -> bool: return False
def had_recent_replies_then_silence(threads: list[dict], days: int) -> bool: return False
def champion_disengaged(deal: Deal, threads: list[dict], days: int) -> bool: return False
def last_email_lacks_next_step(threads: list[dict]) -> bool: return False
def stage_mismatch_with_activity(deal: Deal, threads: list[dict], days: int) -> bool: return False
def find_personal_signal(deal: Deal) -> str | None: return None


# ─── Quota math ──────────────────────────────────────────────────────────────


def compute_daily_quota(cfg: dict, current_mrr: float, stalled_count: int) -> DailyQuota:
    t = cfg["targets"]
    mrr_gap = max(t["mrr_goal"] - current_mrr, 0)
    avg_deal = t["avg_deal_mrr_default"]
    close_rate = t["close_rate_default"]
    reply_rate = t["reply_rate_default"]

    target_date = datetime.fromisoformat(t["mrr_goal_date"]).date()
    runway_days = max((target_date - datetime.now(timezone.utc).date()).days, 1)

    deals_to_close = max(1, -(-int(mrr_gap // avg_deal)))  # ceil
    qualified_needed = deals_to_close / max(close_rate, 0.001)
    qualified_per_day = qualified_needed / runway_days
    sends_per_day = max(1, -(-int(qualified_per_day // reply_rate)))

    cold = min(sends_per_day, cfg["brief_settings"]["max_quota_cold_per_day"])
    fu = max(stalled_count, cfg["brief_settings"]["min_quota_followups_per_day"])
    cb = max(1, -(-cold // 5))

    explanation = (
        f"${mrr_gap:,.0f} gap / ${avg_deal:,.0f} avg deal = {deals_to_close} closes; "
        f"{close_rate:.0%} close rate × {reply_rate:.0%} reply rate × "
        f"{runway_days}d runway → {cold} cold/day"
    )
    return DailyQuota(cold, fu, cb, explanation)


# ─── Brief renderer ──────────────────────────────────────────────────────────


def render_brief(signals: list[StallSignal], quota: DailyQuota,
                 one_thing: str | None, green_lights: list[str],
                 flags: list[str], snapshot: dict) -> str:
    today = datetime.now().strftime("%a, %b %d, %Y")
    lines = [
        "═══════════════════════════════════════",
        f"MAB REVENUE PULSE — {today}",
        "═══════════════════════════════════════",
        "",
        "PIPELINE SNAPSHOT",
        f"  Open Opps:        {snapshot.get('open_opps', '—')}      "
        f"MRR Target:    ${snapshot.get('mrr_target', 50000):,}",
        f"  Pipeline Value:   ${snapshot.get('pipeline_value', 0):,}     "
        f"Current MRR:   ${snapshot.get('current_mrr', 0):,}",
        f"  Win Rate (T12M):  {snapshot.get('win_rate', 0):.0%}     "
        f"Days to Goal:  {snapshot.get('days_to_goal', '—')}",
        "",
        f"🔴 AT RISK ({len(signals)} deals)",
    ]
    for s in signals[:5]:
        lines.append(_render_signal_block(s))

    lines += [
        "",
        "📋 TODAY'S QUOTA",
        f"  Cold Outbound:    [ ] 0 / {quota.cold_outbound}",
        f"  Follow-ups:       [ ] 0 / {quota.follow_ups}",
        f"  Call Books:       [ ] 0 / {quota.call_books}",
        "",
        f"  → Quota math: {quota.math_explanation}",
        "",
        "🎯 THE ONE THING",
        f"  {one_thing or '— No insight surfaced today; data sparse.'}",
        "",
        f"🟢 GREEN LIGHTS (last 24hr)",
    ]
    for g in green_lights or ["  — none yet"]:
        lines.append(f"  {g}")
    if flags:
        lines += ["", "⚠ FLAGS"] + [f"  {f}" for f in flags]
    lines += [
        "═══════════════════════════════════════",
        "NEXT: Hit quota before any build work.",
    ]
    return "\n".join(lines)


def _render_signal_block(s: StallSignal) -> str:
    needs_angle = " ⚠ Needs personal angle" if not s.personal_signal else ""
    return (
        f"\n  ─────────────────────────────────\n"
        f"  DEAL: {s.deal.company} — {s.deal.contact_name}, {s.deal.contact_title}\n"
        f"  STAGE: {s.deal.stage} | VALUE: ${s.deal.value:,.0f} | "
        f"DAYS STALLED: {s.days_silent}\n"
        f"  RISK SCORE: {s.risk_score:.2f}\n"
        f"  SIGNAL: {s.personal_signal or 'TBD'}{needs_angle}\n"
        f"  TEMPLATE: {s.suggested_template}\n"
        f"  ─────────────────────────────────"
    )


# ─── Main ────────────────────────────────────────────────────────────────────


def main(first_run: bool = False, show_all: bool = False, skip_vault: bool = False) -> None:
    cfg = load_config()
    try:
        deals = load_open_deals(cfg)
    except NotImplementedError as e:
        logger.warning("Source not wired: %s", e)
        deals = []

    signals: list[StallSignal] = []
    for d in deals:
        if d.source_flags and "protected-employer" in d.source_flags:
            continue  # Firewalled per user prefs
        threads = load_recent_email_threads(d)
        events = load_calendar_events(d)
        sig = detect_stall_signals(d, threads, events, cfg)
        if sig:
            signals.append(sig)

    signals.sort(key=lambda s: s.risk_score, reverse=True)
    if not show_all:
        signals = signals[: cfg["brief_settings"]["max_at_risk_in_brief"]]

    quota = compute_daily_quota(cfg, cfg["targets"]["current_mrr"], len(signals))
    snapshot = {
        "open_opps": len(deals),
        "mrr_target": cfg["targets"]["mrr_goal"],
        "current_mrr": cfg["targets"]["current_mrr"],
        "pipeline_value": sum(d.value for d in deals),
        "win_rate": cfg["targets"]["close_rate_default"],
        "days_to_goal": (
            datetime.fromisoformat(cfg["targets"]["mrr_goal_date"]).date()
            - datetime.now(timezone.utc).date()
        ).days,
    }

    brief = render_brief(
        signals=signals,
        quota=quota,
        one_thing=None if first_run else "TBD — wire vault first",
        green_lights=[],
        flags=["First run — sources not wired yet"] if first_run else [],
        snapshot=snapshot,
    )
    print(brief)

    if not skip_vault:
        log_to_vault(signals, quota, cfg)


def log_to_vault(signals: list[StallSignal], quota: DailyQuota, cfg: dict) -> None:
    """Append a row to the Strategy Intelligence Vault pulse_runs sheet."""
    # TODO: implement Sheets append. Stub for now.
    logger.info("Would log %d signals to vault", len(signals))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--first-run", action="store_true")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--skip-vault", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    main(first_run=args.first_run, show_all=args.all, skip_vault=args.skip_vault)
