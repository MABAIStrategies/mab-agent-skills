# Message Templates — Stall-Reason Library

Voice rules: direct, ≤120 words, one specific signal, one clear next step. No "circling back," "touching base," "hope this finds you well," "wanted to follow up."

Always include: a specific signal, a value beat, an ask. In that order.

---

## template_breakup_v2 — Silent Decline

Use when: prospect previously replied within 48hr cadence, now 7+ days silent.

```
Subject: Should I close the loop on this?

[First name],

Haven't heard back, which usually means one of three things:
1. Not the right time
2. Not the right priority
3. Not the right fit

If it's #1, when should I check in? If #2 or #3, no hard feelings — I'll get out of your inbox.

Either way, [one specific signal — e.g., "your team's recent expansion in [city]" or "the [product launch] you posted about"] tells me there's something here. Worth 15 minutes if you tell me when.

— Mark
```

Why it works: assumptive close, low-friction reply, gives them dignity to say no. Higher reply rate than soft "just checking in" emails.

---

## template_specific_ask — Missing Next Step

Use when: most recent Mark email had no calendar link or specific ask.

```
Subject: [Topic] — 15 min next week?

[First name],

Last note didn't have a clear next step from me, which is on me. Here's the simple ask:

15 minutes next [Tue or Thu], 10am or 2pm ET — calendar link below. We'd cover [one specific deliverable: e.g., "the workflow audit results from your team's intake form" or "the three automation candidates I scoped"].

If those times don't fit, reply with two that do.

[Calendar link]

— Mark
```

---

## template_proposal_followup_with_value_add — Proposal Drift

Use when: proposal sent 5+ business days ago, no acknowledgment.

```
Subject: One thing I'd add to the proposal

[First name],

Re: the proposal from [date] — while you're reviewing, one update worth flagging:

[Specific value-add: e.g., "since we sent it, [competitor X] announced [news], which strengthens the [specific section] case in section 3" or "I built a quick ROI calculator specific to [their industry] — attached"].

Doesn't change the structure. Sharpens the case.

What questions do you have? Happy to walk through it live this week.

— Mark
```

Never re-send the proposal as an attachment. Send a value-add. The proposal is already in their inbox.

---

## template_no_show_recover — Calendar Ghost

Use when: scheduled call missed, no reschedule thread.

```
Subject: Caught you at a bad time

[First name],

Looked like the [day] call didn't connect — happens. No follow-up shame email coming, just two reschedule slots:

[Day], [time] ET
[Day], [time] ET

Either work? If neither, send me two that do.

— Mark
```

Tone is forgiving, not passive-aggressive. Most no-shows are calendar mishaps, not signal of disinterest. Treat them that way until proven otherwise.

---

## template_champion_check_in — Champion Silence

Use when: identified champion last engaged 10+ days ago.

```
Subject: Quick pulse check

[First name],

It's been a couple weeks — checking in on what's happening on your side, not pushing.

Two questions:
1. Is [project name] still moving forward this quarter?
2. Has the decision-making group changed at all?

Either answer is useful. I'd rather know where things stand than guess.

— Mark
```

Champions go silent for legitimate reasons (priorities shift, they got pulled into something else). Asking about the project state, not your deal, gets a higher response rate.

---

## template_value_anchor — Stage Mismatch

Use when: deal is past Discovery but no recent activity, and you need to re-anchor value.

```
Subject: One number worth reconsidering

[First name],

Pulled together one figure I should have led with:

[Specific quantified outcome relevant to their stage — e.g., "automating [process X] saved [client name] roughly 22 hours/week per AE — call it $190K/year at fully-loaded cost"].

If that number is interesting, we should re-engage. If it's not, tell me what would be — I'll come back with that instead.

— Mark
```

---

## template_post_demo_silence — After demo, no response

```
Subject: After the demo — what's missing?

[First name],

After the [day] demo, expected we'd be on next steps by now. Two possibilities:
- It didn't address the actual problem
- It did, but something else is in the way

Honest answer either way is useful. What's blocking?

— Mark
```

---

## template_executive_intro_request — Need to escalate

```
Subject: Worth a 15-min intro to [exec name]?

[First name],

Based on where this is heading, an intro to [exec title — e.g., "your COO"] earlier rather than later would save us a round of approvals.

Happy to do a 15-minute three-way next week. Easier to bring them in now than to re-pitch later.

Possible? If not, who else should be in the loop before we go further?

— Mark
```

---

## template_competitor_signal — Lost momentum + competitor signal

```
Subject: Saw [competitor] in [their] shop

[First name],

Noticed [signal — e.g., "your team posted a JD mentioning [competitor tool]" or "[competitor] press release about [their company]"].

Two reads on that:
1. You're evaluating alternatives — happy to be one of them
2. You picked someone — tell me who, I'll move on

Either way, an honest answer beats a long silence.

— Mark
```

---

## template_long_cycle_nurture — Genuine slow-cycle deal

Use when: prospect has explicitly said "not this quarter" but is high-value.

```
Subject: Saving you time in [quarter]

[First name],

You said [quarter] was the right window — not pushing that. Two things to make [quarter] easier when it lands:

1. [Specific resource: a benchmark, a calculator, a checklist they'd actually use]
2. A 20-min prep call 2 weeks before kickoff so we hit the ground running

Reply with which one is more useful (or both).

— Mark
```

---

## template_referral_ask — Stalled deal, ask for referral instead

Use when: deal is functionally dead but relationship is warm.

```
Subject: One small ask before I move on

[First name],

Looks like the timing isn't lining up on this one — no problem.

One ask: who in your network would actually find [specific MAB capability] useful right now? One name is enough. I'll handle the intro from there.

Owe you one.

— Mark
```

---

## template_status_check_specific — Generic check-in, but specific

Use when: nothing else fits and you genuinely need a status read.

```
Subject: Where does [project name] stand?

[First name],

Not asking about our conversation — asking about [their internal project name]. Three states:

A) Still moving, just not now
B) Killed or deprioritized
C) Moved to someone else

A letter is enough. I'll calibrate from there.

— Mark
```

Always asks about THEIR project, not YOUR deal. Higher response rate.

---

## Voice Calibration Notes

- "Mark" not "Mark B." or "M. Bockrath" or "Best regards"
- Em dashes welcome. Semicolons rare. Three-word sentences fine.
- Numbered lists when binary or trinary choices. Avoid bullets in body.
- Subject lines under 50 chars, lowercase except names.
- Never "I hope this email finds you well." Ever.
- Never apologize for following up. Following up is the job.
