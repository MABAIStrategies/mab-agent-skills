# Pipeline Signals — Risk Scoring Rubric

Reference loaded by `mab-revenue-pulse` when scoring stalled deals. Each component returns 0.0–1.0.

## deal_value_weight (0.4 of total)

Weighted by ARR potential, normalized against the largest open deal.

| Deal value | Weight |
|---|---|
| Top 10% of pipeline by value | 1.0 |
| 75th–89th percentile | 0.8 |
| 50th–74th percentile | 0.5 |
| 25th–49th percentile | 0.3 |
| Bottom 25% | 0.1 |

Rationale: A stalled $80K deal beats a stalled $5K deal every time, all else equal.

---

## days_since_touch_weight (0.3 of total)

Days since any meaningful prospect-side action (not just Mark sending).

| Days silent | Weight |
|---|---|
| 0–2 | 0.0 (not stalled yet) |
| 3–5 | 0.3 |
| 6–9 | 0.6 |
| 10–14 | 0.85 |
| 15–21 | 1.0 |
| 22+ | 1.0 + flag for "consider closed-lost" |

Adjust by stage: a Discovery silence is more recoverable than a Proposal silence at the same day count. Multiply Proposal-stage silence by 1.2 (cap at 1.0).

---

## stage_advancement_weight (0.2 of total)

How much the deal has stalled vs. expected stage velocity.

Calculate: `actual_days_in_stage / median_days_in_stage_for_won_deals`

| Ratio | Weight |
|---|---|
| < 0.8 (faster than median) | 0.0 |
| 0.8–1.2 (on pace) | 0.2 |
| 1.21–1.8 | 0.6 |
| 1.81–2.5 | 0.85 |
| > 2.5 | 1.0 |

If insufficient historical data (< 5 won deals in that stage), default to 0.5.

---

## champion_engagement_weight (0.1 of total)

Has the identified champion engaged recently?

| Champion behavior | Weight |
|---|---|
| Replied within 7 days, positive tone | 0.0 |
| Replied within 14 days, neutral tone | 0.3 |
| No reply 14+ days, but still opens emails | 0.6 |
| No opens, no clicks, 14+ days | 0.9 |
| Out of office / role change detected | 1.0 |

Detect role changes via LinkedIn signal if available. Out-of-office detection via auto-reply parsing.

---

## Composite Score Examples

**Example 1: $40K deal, 6 days silent, Proposal stage 1.4× median, champion last replied 12 days ago**
- value: 0.8 (top quartile) → 0.32
- days: 0.6 × 1.2 (proposal multiplier) = 0.72 → capped at 1.0 → 0.30
- stage: 0.6 → 0.12
- champion: 0.3 → 0.03
- **Total: 0.77 → HIGH PRIORITY**

**Example 2: $4K deal, 18 days silent, Discovery stage 2.1× median, champion no engagement**
- value: 0.1 → 0.04
- days: 1.0 → 0.30
- stage: 0.85 → 0.17
- champion: 0.9 → 0.09
- **Total: 0.60 → MEDIUM PRIORITY**

Despite the longer silence, the smaller deal scores lower than the larger fresher one. This is correct behavior — focus on what moves the number.

---

## Override Flags

Force a deal to TOP of the brief regardless of score if:

- Deal is flagged `executive_sponsor` in MAB Prospector
- Deal is the largest in pipeline by 2× the next largest
- Mark manually starred it within the last 7 days
- Champion sent a question still unanswered

Force a deal OFF the brief if:

- Status is `closed_lost` or `closed_won`
- Status is `nurture_long_cycle` and last-touch is within the agreed cadence
- Mark manually snoozed it within the last 14 days
