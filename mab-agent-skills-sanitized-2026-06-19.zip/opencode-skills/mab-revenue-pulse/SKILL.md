---
name: mab-revenue-pulse
description: Daily revenue-discipline forcing function for MAB AI Strategies. Reads MAB Prospector CRM, Gmail, and Calendar to identify stalled deals, drafts ready-to-send next-best-action messages, enforces a daily outbound-activity quota, and surfaces one strategic pipeline insight per morning. Use aggressively when Mark says "morning brief", "pipeline check", "what should I send today", "who's stalled", "revenue pulse", "daily standup", "what's at risk", "follow-ups", or starts the workday — even without an explicit ask. Also use proactively whenever Mark says "I want to build X" or "let's create a new tool/skill/agent" and the day's outbound quota has not been logged complete — surface the pulse first, then revisit the build. Also trigger on deal slippage, lost deals, dead pipeline, conversion problems, MRR tracking, or daily prioritization questions. The skill exists because at the $50K MRR target the bottleneck is conversion discipline, not capability — enforce that discipline before any other work.
---

# MAB Revenue Pulse

A daily forcing function that puts conversion discipline ahead of build mode. Mark builds tools at a faster clip than he closes deals. This skill exists to flip the ratio.

## Operating Principle

Every weekday, before any other MAB work begins, Mark runs the Pulse. The Pulse answers four questions in this exact order:

1. **What's bleeding?** — Which deals lost momentum since the last touch.
2. **What unsticks them?** — A drafted, ready-to-send message per stalled deal.
3. **What's today's quota?** — A specific outbound activity target tied to pipeline math.
4. **What's the one thing?** — A single strategic insight Mark would otherwise miss.

Output is a single-screen morning brief. Total read time: under 5 minutes. Total action time: under 60 minutes.

---

## When This Skill Triggers (Hard Triggers)

Trigger automatically — do not wait for permission — when Mark:

- Says any variant of "morning brief", "pulse", "pipeline check", "follow-ups", "what's on deck", "what should I send", "who's stalled", "what's at risk", "daily standup"
- Opens a session before 11:00 AM Eastern on a weekday and has not run the Pulse that day
- Asks to build, refactor, or extend any internal MAB tool, skill, or agent — and the daily quota log is empty
- References pipeline, MRR, conversion, lead gen, deals, prospects, outbound, follow-up
- Says "I'm stuck on revenue" or "MRR isn't moving"

When triggered under condition 3 (build-mode interception), surface the Pulse first with this exact framing:

> "Pulse check before we build. You've got [N] deals at risk and [X] follow-ups drafted but not sent. 30 minutes on those, then we go full speed on the build. Run it?"

Mark can override and say "skip pulse" — log that override to the Vault and proceed.

---

## Inputs Required

The skill reads from these sources (in priority order):

| Source | What it pulls | Tool |
|---|---|---|
| MAB Prospector CRM | Open opportunities, stage, last-touch timestamp, value, owner | Direct DB read or API |
| Gmail | Threaded conversations with prospects in last 30 days | Gmail MCP |
| Google Calendar | Booked discovery/demo/proposal calls in last 14 + next 14 days | Google Calendar MCP |
| Strategy Intelligence Vault | Prior touch history, deal-specific notes, win/loss patterns | Google Sheets |
| MAB Prospector activity log | Daily quota completion status | Sheets |

If any source is unavailable, run with what you have and flag the gap in the brief. Do not block.

---

## Stalled-Deal Detection Logic

A deal is "stalled" if **any** of these are true:

- **Stage Mismatch**: deal stage is past Discovery but no email or calendar event in the last 5 business days
- **Silent Decline**: prospect previously replied within 48hr cadence, but no reply in 7+ days
- **Missing Next Step**: most recent email from Mark did not contain a calendar link, ask, or specific next action
- **Calendar Ghost**: scheduled call no-showed and no rescheduling thread exists
- **Proposal Drift**: proposal sent 5+ business days ago with no acknowledgment
- **Champion Silence**: previously identified champion has not engaged in 10+ days

Score each stalled deal:

```
risk_score = (deal_value_weight × 0.4) +
             (days_since_touch_weight × 0.3) +
             (stage_advancement_weight × 0.2) +
             (champion_engagement_weight × 0.1)
```

Where each weight is 0.0–1.0 based on the rubric in `references/pipeline_signals.md`. Sort descending. Top 5 go in the brief by default. Mark can pass `--all` to see the full list.

---

## Drafted-Message Generation

For each stalled deal in the brief, draft the **exact** next-best-action message. No placeholders. No "[insert prospect name]". The message must be sendable in one click.

Use the message template library in `references/message_templates.md`. Pick the template based on the stall reason:

| Stall reason | Default template |
|---|---|
| Silent Decline | `template_breakup_v2` (assumptive close + door-open) |
| Missing Next Step | `template_specific_ask` |
| Proposal Drift | `template_proposal_followup_with_value_add` |
| Calendar Ghost | `template_no_show_recover` |
| Champion Silence | `template_champion_check_in` |
| Stage Mismatch | `template_value_anchor` |

Personalize each message with **at least one specific signal** from the prospect's recent activity (LinkedIn post, company news, prior conversation). If the signal is missing, do not invent one — flag it as `⚠ Needs personal angle` and suggest where to look.

Match Mark's voice: direct, sales-trained, no corporate fluff. Reference the Brand Bible voice section. No "circling back" or "touching base."

Format every drafted message as:

```
─────────────────────────────────
DEAL: [Company] — [Contact Name, Title]
STAGE: [Stage] | VALUE: $[X] | DAYS STALLED: [N]
RISK SCORE: [0.0–1.0]
SIGNAL: [the personal angle used]
─────────────────────────────────
SUBJECT: [drafted subject line]

[drafted body, 50–120 words, sendable as-is]

─────────────────────────────────
ACTION: Send via Gmail → [thread link]
ALT ACTION: [LinkedIn DM if email cold] → [profile link]
```

---

## Daily Quota Math

Quota is derived from pipeline arithmetic, not gut feel.

```
target_mrr        = 50000  (configurable in scripts/config.json)
runway_days       = days_between(today, target_mrr_date)
avg_deal_mrr      = average of last 5 closed deals or 4500 default
deals_to_close    = max(1, ceil((target_mrr - current_mrr) / avg_deal_mrr))
close_rate        = closed_won / qualified_opps  (12-month trailing or 0.18 default)
qualified_needed  = deals_to_close / close_rate
qualified_per_day = qualified_needed / runway_days

reply_rate        = qualified_replies / sent_messages  (or 0.08 default)
sends_per_day     = ceil(qualified_per_day / reply_rate)

daily_quota = {
  cold_outbound: sends_per_day,
  follow_ups: count(stalled_deals_in_brief),
  call_book_attempts: ceil(daily_quota_cold_outbound / 5)
}
```

Display the quota in the brief with progress bars. Track completion via a row appended to the MAB Prospector daily activity sheet. Quota is "met" only when all three counters hit target.

If quota math returns absurdly high numbers (>50 cold sends/day), flag it: "Your funnel math says you need to send [X] cold/day. That's a volume problem AND a conversion problem. Want to recalibrate close rate or reply rate?"

---

## The "One Thing" Insight

The hardest section. Each morning, surface **one** non-obvious pipeline observation. Categories:

- **Pattern**: "3 of your last 4 lost deals were against [competitor] at the proposal stage. Worth a battlecard refresh?"
- **Asymmetry**: "Your reply rate on Tuesdays is 3.2× Thursdays. Reweight sequences."
- **Compound**: "[Prospect Co.] has had 2 senior hires in your ICP since your last touch — re-warm now."
- **Decay**: "[Deal X] has aged past your typical win-curve median by 11 days. Either call to revive or move to closed-lost."
- **Unowned**: "You have 7 inbound replies sitting unprocessed older than 48hr."

Pull the insight from the Strategy Intelligence Vault if it has 30+ logged data points. Otherwise pull from Gmail + Calendar pattern analysis. If genuinely no insight is available, say so — do not manufacture one. Manufactured insights destroy trust in the brief.

---

## Output Format — Morning Brief Template

Always output this exact structure:

```
═══════════════════════════════════════
MAB REVENUE PULSE — [Day, Mon DD, YYYY]
═══════════════════════════════════════

PIPELINE SNAPSHOT
  Open Opps:        [N]      MRR Target:    $50,000
  Pipeline Value:   $[X]     Current MRR:   $[Y]
  Win Rate (T12M):  [Z]%     Days to Goal:  [N]

🔴 AT RISK ([N] deals)
  [Top 5 stalled deals, ranked, each with drafted message block]

📋 TODAY'S QUOTA
  Cold Outbound:    [ ] [X] / [target]
  Follow-ups:       [ ] [Y] / [target]
  Call Books:       [ ] [Z] / [target]

  → Quota math: [one-line explanation]

🎯 THE ONE THING
  [Single insight, 1-2 sentences, with action verb]

🟢 GREEN LIGHTS (last 24hr)
  [Wins, replies, booked calls, advances — keep it short]

⚠ FLAGS
  [Data gaps, stale sources, anything off]
═══════════════════════════════════════
NEXT: Hit quota before any build work.
```

Brief must fit in roughly one mobile screen. Compress mercilessly.

---

## Logging & The Vault

After every Pulse run, log to the Strategy Intelligence Vault sheet `pulse_runs`:

- timestamp
- deals_at_risk_count
- top_3_at_risk_companies
- quota_targets (cold, fu, cb)
- quota_actuals (filled at end-of-day)
- one_thing_category
- one_thing_used (boolean — did Mark act on it)
- override_used (boolean — did Mark say "skip pulse")

End-of-day, prompt Mark with: "How'd the quota land? Cold: __ / Follow-ups: __ / Call books: __." Append to the row.

This data feeds back into the math and the One Thing insight engine. After 30 days, the Pulse should know more about Mark's pipeline than Mark does.

---

## What This Skill Refuses To Do

- Draft generic templates with placeholder names. If a personal angle isn't available, flag it.
- Lecture about discipline. Show the data once, move on.
- Run on weekends unless Mark asks. Sundays at 7pm ET it can prep Monday's brief silently.
- Touch any deal flagged with `protected-employer` in the source field. That's a different domain.
- Manufacture the One Thing insight when the data isn't there.

---

## Integration Points

| System | Integration | Fallback |
|---|---|---|
| MAB Prospector | Direct API or Sheets export | CSV pull |
| Gmail | Gmail MCP | Apps Script |
| Google Calendar | Calendar MCP | Apps Script |
| Strategy Vault | Sheets append | Local JSON cache |
| Slack/Notification | Daily DM at 7:30 AM ET | Email |
| Apollo / Outreach | Pull last sequence performance | Skip if unavailable |

---

## Reference Files

- `references/pipeline_signals.md` — Full risk-scoring rubric with examples
- `references/message_templates.md` — All 12 stall-reason templates with voice samples
- `scripts/config.json` — Quota targets, default rates, schedule
- `scripts/run_pulse.py` — Orchestration script (skeleton)

---

## Quick Start for First Run

1. Confirm MAB Prospector credentials are accessible
2. Confirm Gmail + Calendar MCPs are connected
3. Open or create the Vault `pulse_runs` sheet (script will create if missing)
4. Run: `python -m scripts.run_pulse --first-run`
5. Review the brief, send the messages, log the quota at end of day
6. Repeat tomorrow at 7:30 AM ET. The brief will be waiting.
