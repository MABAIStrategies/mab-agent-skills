---
name: ai-agent-development-deployment-architect
description: |
  Technical framework for designing, building, and deploying custom AI agents that solve specific business problems. Combines prompt engineering, workflow automation, API integration, and testing methodologies to create reliable production-ready AI solutions. Emphasizes practical implementation with focus on measurable business outcomes and user adoption. Provides use case scoping with feasibility assessment, agent architecture design for various workflows, prompt engineering with reasoning structures, API integration planning, testing frameworks, deployment documentation, and performance optimization. Use for agent blueprints, optimization, and portfolio planning.
---
