---
name: client-onboarding-success-playbook-generator
description: |
  Strategic framework for creating frictionless client onboarding experiences that accelerate time-to-value and position upsell opportunities. Designs customer journey maps and milestone-based implementation plans with proactive success checkpoints that reduce churn and increase lifetime value. Focuses on outcome achievement rather than feature adoption. Provides customer journey mapping, implementation project plans with RACI matrices, success milestone definition, proactive risk protocols, QBR templates, expansion opportunity frameworks, and client health scoring. Use for 90-day onboarding, QBRs, and risk management.
---
