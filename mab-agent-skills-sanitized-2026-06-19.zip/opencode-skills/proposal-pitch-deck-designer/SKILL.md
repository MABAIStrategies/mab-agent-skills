---
name: proposal-pitch-deck-designer
description: |
  Comprehensive framework for creating persuasive business proposals and pitch decks that win deals. Combines storytelling structure, visual hierarchy, objection preemption, and decision-making psychology to create compelling cases for change. Adapts tone and depth based on audience and selling stage. Provides proposal structure following problem-solution-proof-plan framework, executive summaries with decision-forcing clarity, ROI modeling with multiple scenarios, pricing strategy presentation, risk mitigation sections, implementation timelines, visual slide design, and supporting documentation. Use for proposals, pitch decks, and pricing optimization.
---
