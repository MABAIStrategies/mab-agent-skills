---
name: mab-conversion-engine
description: |
  MAB AI Strategies' sales asset generation engine. Takes strategy engine output and produces six tailored, MAB-branded conversion assets: two prospecting one-pagers (different angles), a customer-specific promotional flyer, a visual workflow infographic, a high-level client-facing proposal PDF, a milestone-based "setting expectations" timeline, and a final customizable single-page HTML proposal with dropdown fields and legal disclaimers. Triggers on any of: "convert this strategy to assets", "generate sales materials", "build the proposal", "make a one-pager for [prospect]", "create the conversion package", "generate the [pdf/flyer/infographic/proposal]". Also triggers automatically as the recommended next step after mab-vertical-strategy-engine completes. This is the skill that turns strategy intelligence into closed deals.
---

# MAB Conversion Engine
## Strategy → Sales Asset Production System

> A strategy that doesn't get presented is a strategy that doesn't get sold. The conversion engine is the bridge between intelligence and revenue.

---

## DESIGN PRINCIPLE

Every prospect interaction has a different optimal conversion vehicle. A cold prospect needs a one-pager that earns 90 seconds of attention. A warm prospect ready to evaluate needs a structured proposal. A signed client needs a milestone framework that builds confidence in execution. The conversion engine produces all six in the format and tone matched to where the prospect actually is in the buying journey — not where MAB wishes they were.

The strategy engine generates the substrate. The conversion engine generates the surfaces. Both are necessary. Neither is sufficient.

---

## THE SIX CONVERSION ASSETS

| # | Asset | Format | Use Case | Time to Generate |
|---|-------|--------|----------|------------------|
| 1A | One-Pager: ROI Angle | PDF | Cold prospecting (financial decision-makers) | 5 min |
| 1B | One-Pager: Pain Angle | PDF | Cold prospecting (operational leaders) | 5 min |
| 2 | Promotional Flyer | PDF | Warm outreach with specific offer | 8 min |
| 3 | Workflow Infographic | PDF/PNG | Visual prospects, complex decision teams | 10 min |
| 4 | High-Level Proposal | PDF | First formal evaluation conversation | 15 min |
| 5 | Expectations Timeline | PDF | Post-signature confidence-building | 10 min |
| 6 | Final HTML Proposal | HTML | Customizable proposal with dropdowns + disclaimers | 20 min |

Each asset draws data from the same strategy engine output but emphasizes different elements to match the buyer's stage and persona.

---

## EXECUTION SEQUENCE

```
INPUT REQUIRED:
└─ Strategy engine output (or strategy reference from vault)

STEP 1: Asset Selection
├─ Ask user which asset(s) to generate, OR
└─ Generate full conversion package (all 6) when explicitly requested

STEP 2: Prospect Customization
├─ If specific prospect: Pull profile from vault or request from user
├─ If generic template: Use vertical-level positioning
└─ Tone calibration (financial vs. operational decision-maker)

STEP 3: Asset Generation
├─ Load relevant reference module (01-06 below)
├─ Apply MAB brand standards (logos, colors, fonts)
├─ Inject specific numbers from strategy output
└─ Generate file in target format

STEP 4: Output Delivery
├─ Save to user's local outputs directory
├─ Provide download link via present_files
├─ Offer to iterate on tone, length, or emphasis
└─ Recommend logging the conversion event in the vault
```

---

## REFERENCE MODULE INDEX

Each asset has its own reference module with complete templates, branding rules, and content frameworks.

```
references/01-one-pagers.md       → ROI angle + Pain angle templates
references/02-promotional-flyer.md → Customer-specific offer flyer
references/03-workflow-infographic.md → Visual workflow + outcome design
references/04-proposal-pdf.md      → High-level client proposal
references/05-expectations-timeline.md → Milestone framework
references/06-html-proposal.md     → Final dropdowns + disclaimers
references/07-stack-extensions.md  → Additional assets to consider
assets/brand-standards.md          → Colors, fonts, logo placement
assets/legal-disclaimers.md        → Standard language library
```

---

## THE BRAND STANDARDS LAYER

Every asset must pass through brand validation before delivery:

```
LOGO PLACEMENT:
└─ OfficialCompanyLogo.jpg, top-left, sized appropriately for medium

COLOR PALETTE:
├─ Primary: [As defined in Brand Files artifact]
├─ Secondary: [As defined in Brand Files artifact]
└─ Accent: [As defined in Brand Files artifact]

TYPOGRAPHY:
├─ Headlines: [As defined in Brand Files artifact]
├─ Body: [As defined in Brand Files artifact]
└─ Data callouts: [As defined in Brand Files artifact]

CREDIBILITY ANCHORS (use sparingly, 1 per asset):
├─ "$12M+ ARR generated"
├─ "#2 national ranking at protected-employer"
├─ "750+ enterprise accounts"
├─ "100% coaching success rate"
└─ "5,000+ professional network"

ROI POSITIONING:
└─ Always frame implementation cost as investment, never expense.
   Always pair with quantified annual benefit.
```

See `assets/brand-standards.md` for complete specifications.

---

## ASSET-SPECIFIC TONE CALIBRATION

The same strategy data should sound different across assets:

```
ONE-PAGER (cold prospect):
└─ Direct, claim-heavy, easy to skim. Lead with the strongest single number. 
   Goal: earn the next 5 minutes of attention.

FLYER (warm prospect, specific offer):
└─ Visual, energetic, time-bounded. Lead with the offer, support with credibility.
   Goal: trigger immediate response (call, email, click).

INFOGRAPHIC (visual learner, decision team):
└─ Sequential, illustrative, outcome-focused. Show the journey, not just the destination.
   Goal: enable a champion to forward this to a skeptic.

PROPOSAL PDF (active evaluation):
└─ Confident, comprehensive, evidence-anchored. Build the full case methodically.
   Goal: become the document referenced in the buying decision meeting.

EXPECTATIONS TIMELINE (signed client):
└─ Reassuring, structured, accountability-focused. Show what they signed up for.
   Goal: reduce post-purchase doubt and build implementation momentum.

HTML PROPOSAL (final negotiation):
└─ Collaborative, customizable, legally complete. Both parties can fill it in.
   Goal: become the artifact that gets signed.
```

---

## STACK EXTENSION RECOMMENDATIONS

The six core assets cover the conversion journey, but the broader stack benefits from additional elements. See `references/07-stack-extensions.md` for the seven highest-leverage additions:

```
Extension 1: Interactive ROI Calculator (HTML widget)
Extension 2: Discovery Call Agenda + Script
Extension 3: Email Nurture Sequence (5-7 touches)
Extension 4: Voicemail / Cold Call Script Library
Extension 5: LinkedIn Outreach Templates
Extension 6: Internal Kickoff Checklist (post-signature)
Extension 7: Anonymized Case Study Generator
```

Each extension is independently valuable. Combined with the six core assets, they form a complete prospect-to-implementation pipeline that requires minimal manual effort to maintain.

---

## QUALITY GATES (Before Delivery)

Every asset must pass:

- [ ] Brand standards applied (logo, colors, typography)
- [ ] All numbers traceable to strategy engine source data
- [ ] Tone matched to asset type and prospect stage
- [ ] No copy-paste artifacts from strategy document (rewritten for asset)
- [ ] One quantified differentiator surfaced as primary headline
- [ ] Call-to-action specific and time-bounded
- [ ] Legal disclaimers included where required (proposals, HTML)
- [ ] File saved to outputs directory and presented to user

---

## INTEGRATION WITH OTHER MAB SKILLS

The conversion engine is the third skill in the MAB stack:

```
mab-vertical-strategy-engine 
    └─ Generates the strategic substrate
    
mab-strategy-intelligence-vault
    └─ Captures the strategy + tracks outcomes
    └─ Provides historical pattern data for credibility anchors
    
mab-conversion-engine ← THIS SKILL
    └─ Converts strategy into prospect-facing assets
    └─ Logs conversion events back to vault (e.g., "Proposal sent: 3/14/26")
    └─ Tracks asset-to-outcome attribution over time
```

The combined system creates a closed loop: research generates strategy, strategy generates assets, assets generate outcomes, outcomes feed back into vault, vault makes next strategy smarter.

---

## TRIGGER PROTOCOL

This skill activates on:

```
EXPLICIT TRIGGERS:
├─ "convert this strategy to assets"
├─ "generate sales materials"  
├─ "build the proposal"
├─ "create the conversion package"
├─ "generate [specific asset] for [prospect]"
├─ "make a one-pager"
├─ "create a flyer for [offer]"
├─ "build the expectations timeline"
├─ "draft the final proposal"

IMPLICIT TRIGGERS:
├─ Following any mab-vertical-strategy-engine completion 
   (offers conversion package as natural next step)
├─ When user mentions sending materials to a prospect 
   (offers to generate the right asset)
├─ When user is preparing for a sales meeting
```
