# Module 07: Delivery & Output Architecture

> Load when finalizing strategy output, creating Google Docs, writing executive summaries,
> and designing the engagement loop that converts a delivered strategy into ongoing work.

---

## DESIGN PRINCIPLE: DELIVERY IS STRATEGY

The most brilliant strategy delivered poorly becomes a forgettable document. The delivery architecture — how the work is organized, introduced, and followed up — determines whether a strategy becomes a reference standard or a slide deck nobody reads after the meeting.

Every deliverable from MAB should be built to outlive the meeting it was presented in.

---

## DOCUMENT ARCHITECTURE

Every strategy output follows this structure precisely. Section order, heading style, and length ratios are not suggestions — they're the format that produces business-presentation-grade deliverables.

```
DOCUMENT STRUCTURE:

[COVER PAGE]
├─ Title: [Industry/Company] AI & Automation Strategy
├─ Subtitle: "[Punchy one-line framing]"
├─ Prepared for: [Company or prospect]
├─ Prepared by: MAB AI Strategies
└─ Date + version number

[EXECUTIVE SUMMARY] (1 page, 400–500 words)
[See below for exact format]

[TABLE OF CONTENTS]

[SECTION I: STRATEGIC CONTEXT & POSITIONING] (~2,000 words)
[SECTION II: PHASE-BY-PHASE EXECUTION PLAN] (~15,000 words)
  └── 11 phases, each fully detailed with Agentic Deployment Spec
[SECTION III: INDUSTRY-SPECIFIC CUSTOMIZATION] (~4,000 words)
  └── Personas, objections, scripts, benchmarks, regulatory notes
[SECTION IV: FINANCIAL MODELING] (~2,500 words)
  └── Unit economics, ROI synthesis, valuation impact, revenue projection
[SECTION V: BUSINESS SCALING STRATEGY] (~3,000 words)
  └── Productization path, Year 1–5 projections, exit optionality

[APPENDIX]
├─ Tool stack reference
├─ Regulatory checklist (if applicable)
├─ Quick-reference KPI dashboard layout
└─ Sample templates referenced in text
```

Total target length: 25,000–35,000 words for full-vertical strategies.

---

## EXECUTIVE SUMMARY FORMAT

The executive summary is the most-read page in the document. Write it last. Structure it this way:

```
THE SITUATION (2–3 sentences)
State the specific operational reality — not "this industry has challenges" 
but "a 65-person HVAC contractor running exclusively on paper processes 
is losing an estimated $1.2M annually in billing leakage, inventory waste, 
and labor inefficiency."

THE OPPORTUNITY (2–3 sentences)
Quantify what's available. "An 11-phase automation implementation addresses 
each of these systematically. The first five phases alone deliver $385K in 
annual benefit at a total Year 1 investment of $42K — a 917% ROI."

THE STRATEGIC WINDOW (1–2 sentences)
Why now. "The succession timeline creates a 12–18 month window to install 
modern operating infrastructure before the business transitions to new 
leadership. Acting within that window produces both operational and 
valuation benefits."

THE APPROACH (3–4 sentences)
Phase-sequenced, risk-managed, relationship-anchored. "The engagement begins 
with a 2-week discovery and Phase 1 proof of concept — building one 
automation end-to-end before committing to the broader roadmap. Each phase 
is designed to generate standalone ROI, so the engagement can pause or 
accelerate based on results."

THE OUTCOME (2–3 sentences)
Paint the 3-year picture in numbers. "A fully implemented system positions 
the business for $15–18M in revenue (from $10M today), a 16–20% net margin 
(from 10%), and a valuation of $12–18M — compared to the current $3–4M. 
The automation infrastructure becomes the business's primary competitive moat."

IMMEDIATE NEXT STEPS (3 bullets, specific)
• [Action 1: Date, person responsible, deliverable]
• [Action 2: Date, person responsible, deliverable]  
• [Action 3: Date, person responsible, deliverable]
```

---

## GOOGLE DOC CREATION PROTOCOL

Attempt Google Doc creation via MCP before any other delivery format.

**Step 1:** Check if Google Drive MCP is connected and authenticated.

**Step 2:** If connected, use the `Google Drive:create_file` tool:
```
File name: "[Industry/Company] AI & Automation Strategy — MAB AI Strategies"
Content: Full markdown content of strategy
Parent folder: "MAB Strategy Documents" (create if doesn't exist)
```

**Step 3:** Retrieve shareable link and present to user.

**Step 4:** Always deliver executive summary in chat alongside the Google Doc link.

**If Google Drive is unavailable:**
1. Deliver full strategy in chat (do not abbreviate)
2. Note at the top: "Full strategy below — copy this into a Google Doc using Ctrl+A → Ctrl+C → New Doc → Ctrl+V"
3. Offer to retry Google Doc creation when MCP is reconnected

---

## IN-CHAT DELIVERY FORMAT

When delivering strategy in chat (whether Google Doc fails or user prefers chat):

**Opening frame:**
```
# [INDUSTRY/COMPANY] AI & AUTOMATION STRATEGY
## MAB AI Strategies | [Date]

> **The bottom line up front:** [One sentence on the core financial opportunity]

---
[EXECUTIVE SUMMARY]

---
[Full strategy follows]
```

**Section dividers** (use consistently for navigation):
```
═══════════════════════════════════════════════════════
SECTION I: STRATEGIC CONTEXT & POSITIONING
═══════════════════════════════════════════════════════
```

**Phase headers:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PHASE 1: [PHASE NAME] — Weeks [X–X]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## ENGAGEMENT LOOP DESIGN

The engagement loop closes the strategy delivery and opens the next conversation. It should always appear at the end of every output.

**Format:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT WOULD MAKE THIS MOST ACTIONABLE RIGHT NOW?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

A) [Specific offer tied to their situation]
   Example: "Build Phase 1 automation live in this chat — Jotform form 
   configured for your job types, Make.com scenario drafted, QB integration 
   spec written. Ready to deploy in 2 hours."

B) [Financial modeling with their specific numbers]
   Example: "Run the financial model against your actual revenue, margin, 
   and headcount to get your real ROI numbers — not the industry estimates 
   in this strategy."

C) [Proposal or pitch deck for a specific prospect]
   Example: "Convert this strategy into a client-facing proposal for [Company] 
   with their specific pain points, their numbers, and a clear ask."

D) [Specific module deep-dive]
   Example: "Expand the stakeholder section with conversation scripts for 
   the CEO approval conversation you're planning this week."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Rules for the engagement loop:**
- All four options must be genuinely useful and contextually specific to this strategy
- Option A should always be something that can be executed immediately in this chat
- Option C should surface a named prospect opportunity where relevant
- Never generic ("more information") — always specific ("Phase 1 form built live")

---

## VERSION CONTROL & ITERATION PROTOCOL

Every strategy document should include a version header:

```
Version: 1.0 — Initial strategy
Version: 1.1 — Updated [specific section] based on [market feedback / discovery finding]
Version: 2.0 — Major revision incorporating [90 days of implementation learnings]
```

When a user returns with market learning ("here's what we found in the field"):

1. Search project knowledge for prior strategy version
2. Create a "Strategy Update Brief" (3–5 pages, not a full rewrite):
   ```
   What's validating: [Specific sections proven correct]
   What's not: [Specific sections to revise]
   New intelligence: [What the market is telling us]
   Recommended updates: [Specific phase/section changes]
   Updated financial model: [Revised numbers if applicable]
   ```
3. Append to original document as Version 1.1
4. Note: "The original strategy stands. These refinements sharpen it."

---

## QUALITY STANDARD: THE BUSINESS PRESENTATION TEST

Before delivering any strategy, ask: "Could this be presented, unedited, in a business meeting to a sophisticated operator, and hold up to scrutiny?"

If the answer is no, identify what's missing:

- **Missing numbers:** Generic claims without quantification don't hold up. Add real numbers or clearly mark estimates as estimates with methodology shown.
- **Missing specificity:** "Use a scheduling tool" fails. "Skedulo at $X/month because [specific reason]" passes.
- **Missing scripts:** Telling someone to "have the conversation" without giving them the words is a gap. Provide verbatim language for every important conversation.
- **Missing risks:** Strategies without risk acknowledgment look naive. Naming what could go wrong — and how to prevent or recover — builds credibility.
- **Missing next steps:** A strategy that ends without specific, calendar-driven immediate actions is complete as a document but incomplete as a tool.

The MAB standard: someone receiving this strategy should be able to take a specific action tomorrow that follows directly from what's written.

---

## CONFIDENTIALITY & ATTRIBUTION FOOTER

All strategy documents should close with:

```
---
Prepared by: MAB AI Strategies LLC
Contact: [Mark Bockrath contact]
Confidential — For intended recipient only

This strategy was developed based on industry research, operational 
observation, and MAB's proprietary implementation methodology. 
Specific financial projections are estimates based on industry 
benchmarks and operational analysis. Actual results depend on 
implementation quality, adoption rate, and market conditions.

MAB AI Strategies specializes in AI automation implementation for 
mid-market service businesses. This document may be used as a 
reference for internal planning. Reproduction for competitive 
purposes is prohibited.
---
```
