# Module 01: Market Intelligence & Strategic Context

> Load this module when building Section I (Strategic Context & Positioning).
> Also used to enrich Section III (Industry Customization) with current data.

---

## PURPOSE

This module governs how to turn raw web search results + industry knowledge into a **Strategic Context** section that creates urgency without manipulation. The goal: by the end of this section, the reader should feel that NOT acting is the riskier choice — and the data should prove it, not assert it.

---

## STRUCTURAL FORMULA FOR SECTION I

Every Strategic Context section follows this architecture:

```
1. THE INFLECTION POINT (Why now, not 3 years ago, not 3 years from now)
2. THE ECONOMICS BREAKING DOWN (What worked before that is failing now)
3. THE BURNING PLATFORM (Quantified cost of inaction)
4. THE TECH GAP MAP (Where AI/automation is missing in this vertical)
5. THE COMPETITIVE PRESSURE (What's changing the market structure)
6. THE WINDOW (Why this moment is uniquely actionable)
```

Never lead with "AI is transforming X industry." That's the most overused sentence in business writing. Lead with the specific economic or operational stress that is making the status quo untenable.

---

## INFLECTION POINT TRIGGERS (by vertical type)

Use these as diagnostic lenses when analyzing any industry. Each trigger creates a different strategic entry angle.

**Labor Shortage / Wage Inflation:**
Craft angle: "The workforce model that built this industry is collapsing. Automation isn't optional anymore — it's the only way to maintain margins as labor costs outpace pricing power."

**Regulatory Tightening:**
Craft angle: "New compliance requirements are creating documentation overhead that paper-based operations simply cannot absorb. The companies that automate compliance first will win the regulated contracts."

**Private Equity Consolidation:**
Craft angle: "PE rollups are installing modern operating systems in your target customers' competitors. The family-owned operator has 18-24 months to modernize before the valuation gap becomes a market share gap."

**Consumer Expectation Shift:**
Craft angle: "The Amazon Prime effect has reached B2B. Decision-makers now expect real-time updates, transparent pricing, and instant communication from every vendor — including ones that have never provided it before."

**Supply Chain Complexity:**
Craft angle: "Three-year supply disruptions have exposed every company that was 'managing' inventory by feel. The ones that survived have a digital backbone. The ones that didn't are still catching up."

**Succession / Generational Transfer:**
Craft angle: "The largest transfer of privately-held business ownership in US history is happening right now. New owners inherit a choice: modernize or sell. That choice is MAB's market."

**Commoditization Pressure:**
Craft angle: "When price becomes the primary differentiator, the only escape is operational efficiency. Automation enables lower-cost delivery at the same (or better) quality — the only sustainable moat against commoditization."

---

## ECONOMICS BREAKDOWN FRAMEWORK

For any mid-market service business (the core MAB target), use this model:

```
Pre-Automation Economics (50–150 employees, paper/manual operations):

Revenue ceiling: $8–20M (plateaus here without systems)
Gross margin: 35–45% (theoretical)
Net margin: 8–12% (actual, after operational waste)
Owner hours/week: 70–80 (unsustainable)
Admin FTE ratio: 1:8 (1 admin per 8 field/production staff)
Revenue per employee: $120–180K (below potential)
Billing cycle: 25–45 days from delivery to invoice
Collection cycle: 45–65 days from invoice to payment

Hidden operational costs (quantify per industry):
├─ Billing leakage: 8–15% of revenue
├─ Inventory/materials waste: 10–20% of materials spend
├─ Labor inefficiency: 15–25% of labor hours
├─ Admin redundancy: 3–5 FTEs doing automatable work
└─ Cash flow gap cost: 1.5–3% of revenue in financing costs
```

**Instruction:** Replace these ranges with industry-specific numbers from web search. The ranges above are defensible defaults if you can't find better data.

---

## TECH GAP MAP TEMPLATE

For every vertical, identify the gap between what enterprise software offers, what mid-market uses, and what AI can now bridge:

```
Tech Gap Map — [Industry]

Enterprise-level (what Fortune 500 uses):
├─ [System 1]: Full ERP integration, AI-powered, $50K+/year
├─ [System 2]: Predictive analytics, real-time reporting
└─ [System 3]: Automated compliance + documentation

Mid-market reality (what your target uses):
├─ QuickBooks + Excel + paper (most common)
├─ One legacy software used at 20% capacity
└─ WhatsApp/text for internal communication

The gap AI now bridges (MAB's opportunity):
├─ Intelligent document processing (replace manual data entry)
├─ Automated workflow orchestration (replace human coordination)
├─ Predictive operations (replace reactive decision-making)
├─ Real-time financial visibility (replace weekly/monthly reports)
└─ Customer communication automation (replace phone-based updates)

Time to close gap with agents: 6–12 weeks
Cost: $3,000–15,000 implementation + $500–2,000/month
Enterprise alternative cost: $100,000–500,000/year
```

---

## COMPETITIVE PRESSURE ANALYSIS

Research and document:

1. **Software incumbents** — Who are the ServiceTitans of this vertical? What do they do well and leave undone?
2. **PE-backed operators** — Who is consolidating this space? What operational advantages are they installing?
3. **Adjacent disruptors** — Who is attacking from adjacent industries (e.g., Amazon Home Services in HVAC)?
4. **Labor market substitutes** — Where are companies replacing headcount with automation, and at what scale?

Frame this as: "Your prospect is already under competitive pressure from these forces. MAB is the counterpunch."

---

## WHY NOW — THE WINDOW FRAMEWORK

Every strategy needs a time-bounded reason to act. Use one of these frames:

**The Season Window:**
"Q4/Q1 is the only time this business can implement without disrupting peak operations. That window opens in [month] and closes in [month]."

**The Regulation Window:**
"[Regulation] takes effect [date]. Companies that build compliant systems before enforcement have a structural advantage. Companies that scramble afterward pay penalties and premium implementation costs."

**The Labor Window:**
"Hiring qualified [role] is currently [% harder / % more expensive] than 3 years ago. The companies that automate now lock in a structural cost advantage before wages normalize (if they ever do)."

**The PE Window:**
"Once a PE firm acquires [competitor], they will install [system] across their portfolio within 18 months. That creates an expectation shift in the market. Independent operators who can match that capability will hold market position. Those who can't will lose."

**The Relationship Window:**
"[Decision-maker] is in a succession transition. New leaders need quick wins to establish credibility. MAB's timeline of [X weeks to first visible result] maps perfectly to their political calendar."

---

## OUTPUT REQUIREMENTS FOR SECTION I

Minimum content:
- [ ] Named inflection point (not generic "AI is transforming...")
- [ ] Quantified economics of current state (with numbers, not ranges of ranges)
- [ ] Tech gap map (3 columns: enterprise / current reality / AI bridge)
- [ ] Named competitive pressures (specific companies or categories)
- [ ] Time-bounded window argument
- [ ] 1 "burning platform" statement with a specific dollar figure

Tone: Confident, not alarmist. The goal is clarity, not fear. The data should speak; the analysis should interpret.
