# Module 03: Opportunity Architecture

> Load this module when building Phases 1–11 of Section II (Execution Plan).
> This module governs phase sequencing logic, dependency mapping, implementation
> design, and the structural rules that make each phase earn the next one.

---

## DESIGN PRINCIPLE: STRUCTURAL INEVITABILITY

The most important property of the phase sequence is that each phase must *logically require* the previous one. Not just benefit from it — require it. When Phase 2 depends on data generated in Phase 1, and Phase 3 depends on infrastructure built in Phase 2, the sequence becomes self-reinforcing. Clients don't stall between phases because stopping midway would mean the completed work can't reach its full value.

This is the difference between a project roadmap and an investment thesis.

---

## THE UNIVERSAL PHASE ARCHITECTURE

Every vertical uses this 11-phase spine. Customize content within phases, never restructure the spine.

```
PHASE 0:  Foundation & Alignment (Weeks 1–2)
PHASE 1:  Revenue Data Infrastructure (Weeks 3–6)
          [Billing / Invoicing / Financial Data Capture]
PHASE 2:  Resource Visibility (Weeks 7–10)
          [Inventory / Assets / Materials / Capacity]
PHASE 3:  Operations Intelligence (Weeks 11–14)
          [Scheduling / Dispatch / Routing / Allocation]
PHASE 4:  Labor & Compliance Automation (Weeks 15–17)
          [Payroll / Time Tracking / Certification / HR]
PHASE 5:  Cash Flow Engine (Weeks 18–20)
          [Collections / AR / Payment / Forecasting]
PHASE 6:  Customer Experience Layer (Weeks 21–23)
          [Communications / Portals / Reviews / Retention]
PHASE 7:  Recurring Revenue Architecture (Weeks 24–26)
          [Contracts / Subscriptions / Renewals / Upsells]
PHASE 8:  Predictive Intelligence (Weeks 27–30)
          [IoT / Sensors / Failure Prediction / Proactive Service]
PHASE 9:  Knowledge & Training Systems (Weeks 31–33)
          [SOPs / AI Assistants / Onboarding / Quality Control]
PHASE 10: Business Intelligence (Weeks 34–36)
          [Unified Analytics / Executive Dashboard / Forecasting]
PHASE 11: Scale & Systematize (Weeks 37–40)
          [Playbook / SOPs / Growth Infrastructure / Exit Readiness]
```

**Dependency Chain (never violate):**
- Phase 1 must precede Phase 5 (can't automate collections without automated invoicing)
- Phase 2 must precede Phase 3 (can't optimize routing without knowing what resources are available)
- Phase 3 must precede Phase 4 (scheduling data becomes the foundation for time tracking)
- Phases 1–5 must precede Phase 10 (no BI without clean underlying data)

---

## PHASE ANATOMY (Apply to every phase)

Each phase requires all 10 of these components. Incomplete phases become stalled projects.

### 1. OBJECTIVE (1 paragraph)
What specific operational problem does this phase solve? What is the measurable state change?

### 2. STRATEGIC RATIONALE (5 bullets)
Why does this phase come now, not before or after? Include dependency logic, momentum logic, and stakeholder readiness logic.

### 3. CURRENT STATE (Code block format)
Document the broken process exactly as it exists today. Include:
- Process steps in sequence
- Time spent at each step
- Error rates and frequencies
- The people involved
- The downstream consequences of each failure point

### 4. TARGET STATE (Code block format)
Document the automated future state with equal specificity:
- Which steps are eliminated entirely
- Which steps are transformed (human decision → system decision)
- Which steps remain human (and why)
- What the new time/error/cost profile looks like

### 5. IMPLEMENTATION ACTIONS (Numbered, week-by-week)
Specific, calendar-driven actions. Not "set up the system" — "Day 1: import customer list from QB. Day 2: build form. Day 3: test with 3 pilot users. Day 5: fix bugs from test. Week 2: train full team."

### 6. AGENTIC DEPLOYMENT SPEC (See Module 04)
What agents can execute autonomously vs. what requires human judgment.

### 7. TOOL STACK (Decision matrix)
For each tool selection, provide 3 options with honest tradeoffs:
- Budget option (lowest cost, what you sacrifice)
- Recommended option (best fit for this scale, why)
- Enterprise option (if growth demands it, when to consider)

### 8. KEY QUESTIONS (10–20, grouped by week)
Not generic discovery questions. Phase-specific diagnostic questions that reveal whether this implementation is on track.

### 9. SUCCESS METRICS (Quantitative, measurable)
3 primary KPIs + 4–6 secondary KPIs. All must have a "before" baseline and a "target" number. No vanity metrics.

### 10. STANDALONE ROI CALCULATION
```
Annual Benefit:
├─ [Benefit 1]: [Calculation with real numbers]
├─ [Benefit 2]: [Calculation with real numbers]
└─ [Benefit 3]: [Calculation with real numbers]
Total Annual Benefit: $[X]

Investment:
├─ Software: $[X]/year
├─ Implementation: $[X] (one-time)
└─ Total Year 1: $[X]

ROI: [X]%
Payback Period: [X] weeks/months
```

---

## TOOL SELECTION DECISION FRAMEWORK

When recommending tools for any phase, evaluate across 5 dimensions:

```
1. Adoption Probability (1–10)
   Can field staff actually use this without a CS degree?
   
2. Integration Potential (1–10)
   Can this tool talk to QuickBooks, existing CRM, and whatever 
   we build in adjacent phases?
   
3. Agentic Extensibility (1–10)
   Can AI agents be deployed on top of this tool via API/webhook?
   Does it have a Make.com / Zapier / n8n connector?
   
4. Data Quality Output (1–10)
   Does the data this tool generates meet the quality threshold 
   for Phase 10 (Business Intelligence)?
   
5. Productization Potential (1–10)
   If MAB builds a standardized offering for this vertical, 
   can we deploy this tool at scale without full custom work?
```

**MAB Default Stack (use unless there's a compelling reason not to):**

| Layer | Default Tool | Fallback |
|-------|-------------|---------|
| Automation engine | Zapier (AI steps) | Gumloop → n8n |
| Database/backend | Airtable | Google Sheets → Supabase |
| Mobile forms | Jotform | Google Forms → custom |
| Communication | Twilio (SMS) + SendGrid (email) | — |
| Payment processing | Stripe | Square |
| Scheduling | Skedulo | Google Calendar + Zapier |
| Time tracking | TSheets / QuickBooks Time | Clockify |
| Inventory | Sortly | Airtable |
| Analytics | Airtable Interfaces + Google Looker Studio | Power BI |
| Document generation | DocuPilot | Google Docs API |
| AI/LLM layer | Claude via API | — |

---

## THE PHASE 1 IMPERATIVE

Phase 1 is always the billing/invoicing/financial data capture layer, regardless of vertical. Here's why this is non-negotiable:

**1. Fastest visible ROI** — Billing automation delivers measurable time savings in week 1. This creates proof that the project is working before anyone gets fatigued.

**2. Cash flow impact is immediately felt** — Faster invoicing = faster payment = the business can literally feel the difference in their bank account within 30 days.

**3. Creates the data foundation** — Every downstream phase (inventory costing, labor allocation, profitability analytics) requires clean transaction-level data. Phase 1 generates it.

**4. Builds team trust** — When field staff submit job completion digitally and see their work instantly in the system (not sitting in a paper pile), they become automation believers. That belief carries every subsequent training session.

**5. The "wow moment" is fast** — Office staff who've spent 20+ hours/week on manual invoicing suddenly have their afternoons back. That emotional shift is the most powerful adoption driver in the engagement.

**Adapting Phase 1 by vertical:**

| Vertical | Phase 1 Equivalent |
|----------|-------------------|
| HVAC / Field Service | Job completion form → auto invoice → QB sync |
| Healthcare / Clinical | Patient encounter documentation → auto billing → insurance coding |
| Legal | Matter time entry → auto billing → client portal delivery |
| Retail / Inventory Business | POS transaction → auto reconciliation → inventory adjustment |
| Staffing / Labor | Timesheet capture → auto invoice → payroll sync |
| Restaurant / Hospitality | Order capture → reservation management → automated follow-up |
| Construction | Progress billing → lien waiver automation → draw request |
| Logistics / Transportation | Load confirmation → auto invoice → carrier payment |

---

## ADOPTION RISK MANAGEMENT

The technology almost never fails. Adoption does. For every phase, assess and address:

**Adoption Threat 1: "This takes longer than what I do now" (first week only)**
Mitigation: Over-train, over-support in week 1. Be physically present. The learning curve flattens by week 2, but perception is set by week 1.

**Adoption Threat 2: "Nobody told me this was happening"**
Mitigation: Announce changes 2 weeks before going live. Frame in "what this does for you" language, not "what this requires from you" language.

**Adoption Threat 3: "What if it breaks?"**
Mitigation: Build and communicate a visible fallback process (not a secret one). The fact that there's a backup makes people more willing to try the new system.

**Adoption Threat 4: "I don't trust the data it generates"**
Mitigation: Show side-by-side comparisons (paper ticket next to auto-generated invoice for first 2 weeks). Let them verify. Trust is earned through transparency.

**Adoption Threat 5: "My boss said to do it this way"**
Mitigation: Get visible endorsement from the highest authority figure before training begins. CEO/owner says "this is how we do it now" — that closes most adoption gaps.

---

## PHASE TIMING CALIBRATION

Adjust timeline based on company size and existing tech sophistication:

```
Company Size: 15–40 employees
├─ Phase 0: 1 week (faster trust, simpler org)
├─ Phases 1–5: Compress to 3 weeks each (less complexity)
└─ Phases 6–11: Optional or accelerated
Timeline: 5–8 months total

Company Size: 40–100 employees (core MAB target)
├─ Phase 0: 2 weeks
├─ Phases 1–5: 3–4 weeks each
└─ Phases 6–11: 3 weeks each
Timeline: 10–14 months total

Company Size: 100–300 employees
├─ Phase 0: 3–4 weeks (more stakeholders, more complexity)
├─ Phases 1–5: 5–6 weeks each (more training, more rollout)
└─ Phases 6–11: 4–6 weeks each
Timeline: 18–24 months total
```

---

## THE "PROOF OF CONCEPT ACCELERATOR" PATH

When MAB has a trusted insider relationship (like the HVAC VP/COO scenario), compress Phase 0 and Phase 1 into a 2-week sprint:

**Week 1:** Shadow operations, map processes, identify #1 pain point
**Week 2:** Build, test, and launch Phase 1 automation (minimum viable version)

The goal of the POC Sprint: Generate one measurable win before the first full strategy presentation. Presenting a strategy alongside evidence it works is exponentially more persuasive than presenting a strategy alone.

**POC Sprint success criteria:**
- At least one process automated end-to-end
- At least one quantified time or cost saving documented
- At least one team member saying "I don't want to go back to the old way"

That third criterion — a team member who won't go back — is your most valuable sales tool for phase 2 approval.
