# Module 05: Financial Intelligence

> Load when building Section IV (Financial Modeling) and the per-phase ROI calculations.
> Every number in this module should be replaced with industry-specific research.
> These are structural formulas and representative defaults, not citations.

---

## DESIGN PRINCIPLE: NUMBERS AS ARCHITECTURE

Most strategy documents treat financial projections as an appendix — something you read after the main argument, if you read it at all. That's backwards. The financial model should be woven through every phase as a running argument that builds in persuasive force.

By the time the reader reaches Section IV, the cumulative ROI of Phases 1–5 should already feel inevitable, and Section IV exists to synthesize it into strategic business modeling.

The goal is not to make numbers impressive. The goal is to make numbers inescapable.

---

## UNIT ECONOMICS FRAMEWORK (by engagement type)

### Mid-Market Service Business (Core MAB Target: 40–150 employees)

**Revenue profile:**
```
Annual revenue: $5–20M
Gross margin: 35–50% (depends on labor vs. materials mix)
Net margin: 8–15% (pre-automation)
Revenue per employee: $100–200K
Admin FTE: 1:8 to 1:12 ratio
Payroll as % of revenue: 35–45%
Materials/COGS as % of revenue: 20–35%
```

**Operational waste profile (quantified automation opportunity):**
```
Billing leakage (late invoicing, errors, lost tickets): 8–15% of revenue
Inventory waste (shrinkage, over-ordering, stockouts): 10–20% of materials spend
Labor inefficiency (scheduling gaps, drive time, downtime): 15–25% of labor budget
Admin redundancy (automatable tasks done by humans): 25–35% of admin cost
Collection delays (cash tied up in slow AR): 1.5–3% of revenue in capital cost
Total operational waste range: 18–35% of gross revenue
```

**Translation at $10M revenue:**
```
Billing leakage: $800K–$1.5M
Inventory waste: $200K–$700K  
Labor inefficiency: $400K–$900K
Admin redundancy: $125K–$250K
Collection delays: $150K–$300K
Total annual waste: $1.675M–$3.65M
```

This is "The Number" — the quantified cost of the status quo that makes inaction economically irrational.

---

## PER-PHASE ROI STRUCTURE

Every phase requires a standalone ROI box that proves this investment pays off even if the engagement stops here.

### Template (customize numbers per industry):

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ROI ANALYSIS — Phase [N]: [Phase Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ANNUAL BENEFITS:

[Benefit Category 1]:
Calculation: [Specific formula with real numbers]
Annual value: $[X]

[Benefit Category 2]:
Calculation: [Specific formula with real numbers]
Annual value: $[X]

[Benefit Category 3]:
Calculation: [Specific formula with real numbers]
Annual value: $[X]

Total Annual Benefit: $[X]

INVESTMENT:
├─ Software/tools: $[X]/year ([tool name(s)])
├─ Implementation: $[X] one-time
├─ Training: $[X] one-time
└─ Total Year 1: $[X]

RETURNS:
├─ Net Year 1 Benefit: $[Total - Investment]
├─ ROI: [X]%
├─ Payback Period: [X] weeks
└─ Year 2+ Annual Return: $[Total - software only]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## CASH FLOW IMPACT MODEL

This is often the most emotionally resonant financial argument because business owners feel cash flow problems daily, whereas "ROI" is an abstraction.

```
Cash Flow Improvement — 5-Phase Analysis

Before Automation:
├─ Days from service delivery to invoice: 4–7
├─ Days from invoice to payment: 45–65
└─ Total cash cycle: 49–72 days

After Automation (Phases 1–5):
├─ Days from service delivery to invoice: Same day (<2 hours)
├─ Days from invoice to payment: 28–35 (automated reminders + payment convenience)
└─ Total cash cycle: 28–37 days

Cash Cycle Improvement: 12–35 days faster

Working Capital Freed:
= (Daily revenue) × (Days saved)
= ($10M / 365) × 20 days average
= $547,945 freed from AR

This working capital was previously financing itself through:
- Credit line draws (cost: 7–12% annually)
- Delayed vendor payments (cost: relationship + potential penalties)
- Owner salary delays (cost: stress + credibility)

Annual interest/opportunity cost eliminated: $38K–$66K
```

---

## FINANCIAL MODELING — SECTION IV STRUCTURE

Section IV synthesizes phase-level ROI into three models.

### Model 1: Implementation Investment Summary

```
Phase-by-Phase Investment and Return:

Phase | Investment | Annual Benefit | Payback | ROI
------|------------|----------------|---------|----
0     | $X         | Foundation only | N/A    | N/A
1     | $X         | $X              | X wks  | X%
2     | $X         | $X              | X wks  | X%
3     | $X         | $X              | X wks  | X%
4     | $X         | $X              | X wks  | X%
5     | $X         | $X              | X wks  | X%
6–11  | $X         | $X              | X mo   | X%

Cumulative Investment (Phases 0–5): $X
Cumulative Annual Benefit (Phases 0–5): $X
Blended 5-Phase ROI: X%
```

### Model 2: Business Valuation Impact

This is the strategic argument that separates MAB from any other automation vendor — connecting operational efficiency to enterprise value.

```
Business Valuation Before Automation:
├─ EBITDA: $X (10–12% net margin on $10M)
├─ Valuation multiple: 3–4x (paper-based, owner-dependent, no systems)
└─ Estimated value: $3–4M

Business Valuation After Full Implementation:
├─ Revenue: $X (growth enabled by capacity freed)
├─ EBITDA margin: X% (efficiency + growth leverage)
├─ EBITDA: $X
├─ Valuation multiple: 6–8x (systemized, recurring revenue, tech-enabled)
└─ Estimated value: $X

Value created: $X (the "hidden ROI" most vendors never discuss)

Why the multiple expands:
✓ Recurring maintenance contract revenue (predictable cash flow)
✓ Documented, replicable systems (not owner-dependent)
✓ Technology infrastructure (buyer sees scalable platform)
✓ Clean financial data (audit-ready, bankable)
✓ Growth capacity (can scale without linear headcount increase)
```

### Model 3: Revenue Growth Projection (Years 1–5)

```
Year 1 (Current State → Foundation Built):
├─ Revenue: [Current × 1.0 to 1.15] (efficiency gains, reduced churn)
├─ EBITDA margin: +3–5 pp (waste eliminated)
└─ Net benefit: $X above baseline

Year 2 (Systems Operational → Capacity Freed):
├─ Revenue: [Current × 1.2 to 1.35] (capacity freed enables growth)
├─ EBITDA margin: +5–8 pp (scale leverage)
└─ Net benefit: $X above baseline

Year 3 (Growth Mode → Market Expansion):
├─ Revenue: [Current × 1.4 to 1.7] (with maintenance contracts + geographic expansion)
├─ EBITDA margin: +8–12 pp (recurring revenue operating leverage)
└─ Net benefit: $X above baseline

Year 4–5 (Strategic Position → Exit Optionality):
├─ Revenue: [Current × 1.8 to 2.5]
├─ EBITDA margin: 18–22%
└─ Enterprise value: $X (3–5x what it was at year 0)
```

---

## MAB PRICING STRATEGY

Structure MAB's commercial model to mirror the value delivery.

### Engagement Model Tiers

**Tier 1: Proof of Concept Sprint ($15–25K flat fee)**
- 2-week discovery + Phase 1 build
- Deliverable: One fully automated workflow live
- Goal: Create undeniable evidence before asking for full engagement commitment
- Target: Companies where trust isn't established yet

**Tier 2: Full Phase Implementation ($75–150K for Phases 0–5)**
- 5-month structured engagement
- Deliverable: Core automation stack (billing, inventory, scheduling, payroll, collections)
- Goal: Transform the operational backbone
- Target: Companies with clear pain and decision-maker access

**Tier 3: Managed Optimization ($5–12K/month retainer)**
- Ongoing after implementation
- Deliverable: Agent monitoring, system iteration, reporting, QBRs
- Goal: Recurring revenue + deepening relationship + Phase 6–11 opportunities
- Target: All completed Phase 0–5 implementations

**Tier 4: Vertical Productization (SaaS licensing, Year 2+)**
- Standardized platform built from proof-of-concept
- Deliverable: Subscription platform per vertical (e.g., HVAC-in-a-Box)
- Goal: Leverage one deep implementation into a repeatable product
- Pricing: $2–5K/month per client at scale

### Value-Based Pricing Anchor

Never price based on hours. Price based on value delivered.

```
Standard pricing anchor calculation:

Annual benefit delivered: $X (from financial model)
Value capture rate: 15–25% (MAB captures this % of client's benefit)
Implied MAB fee: $X × 20% = $X

Example: $300K annual benefit × 20% = $60K MAB fee
This is both fair to client (80% ROI they keep) and defensible to MAB.
```

---

## FINANCIAL CONVERSATION SCRIPTS

These are the exact words to use when presenting financial models to decision-makers.

**Opening the financial conversation:**
"Before we talk about what we're building, let me show you what the current system is costing you. Not what it might cost — what it is costing right now, every week."

**Presenting "The Number":**
"Based on what we observed, the status quo is running you approximately $[X] per year in operational waste. That's not a conservative estimate. That's math against your own operational data. Here's how we calculated it..."

**Handling "We don't have budget for this":**
"I want to make sure I'm hearing this correctly. You're telling me you can't afford [investment] to eliminate [X × investment in annual waste]? That's not a budget question — that's an ROI question. Let me show you the cash flow model and you tell me if this makes financial sense or not."

**The valuation argument (for succession situations):**
"Here's a number most HVAC consultants never put in front of you. If we do this work together and increase your EBITDA by 6 percentage points and put modern systems in place, comparable businesses in your market sell at 6–8x EBITDA. That's [calculated value]. You're currently building toward a [lower] number. This engagement is not an expense. It's a capital investment in your exit."

**Closing the financial case:**
"The question isn't whether this investment is worth it — the math is clear. The question is how fast you want to close the gap between where you are and where you could be."
