# Module 02: Discovery & Current-State Assessment

> Load this module when building Phase 0 of Section II (Execution Plan).
> This module governs how to design the observation, audit, and alignment 
> protocols that make every subsequent phase succeed.

---

## DESIGN PRINCIPLE

Most implementation projects fail not because the technology is wrong, but because the problem statement was built on assumptions instead of observation. Phase 0 exists to eliminate assumption. It is the most undervalued phase in any engagement and the one most consultants skip.

The deliverable is not a report. The deliverable is shared reality — the client and MAB both seeing the same operational truth at the same time. Once that exists, everything else is just engineering.

---

## THE THREE DISCOVERY MODES

Match the discovery protocol to the engagement type:

### Mode A: Embedded Discovery (Trusted Relationship)
Used when: Direct relationship with decision-maker, access granted freely
Method: Shadow operations, interview all levels, photograph everything
Duration: 3–5 days
Deliverable: 15–20 page observation report + technology audit + prioritization matrix

### Mode B: Remote Discovery (New Prospect, Pre-Sale)
Used when: No existing relationship, discovery is part of the sales process
Method: Structured interview (video call), technology audit questionnaire, publicly available operational data
Duration: 1–2 hours
Deliverable: 5–8 page discovery summary + opportunity hypothesis + ROI estimate
Note: Frame as "diagnostic" not "audit" — less threatening language

### Mode C: Autonomous Discovery (Agent-Led, New in Agentic Era)
Used when: Enough public/available data exists to build a baseline before first human conversation
Method: Web research on company, industry benchmarks, tech stack inference from job postings, review analysis, LinkedIn org chart mapping
Duration: 30–60 minutes (agent-executed)
Deliverable: Pre-meeting intelligence brief + hypothesis set + conversation guide
Note: Always disclose to client that you researched them. Transparency creates trust.

---

## THE OBSERVATION FRAMEWORK

When shadowing operations (Mode A), use this structured observation protocol.

### Day 1: The Office Brain (Scheduling, Dispatch, Billing)

**Morning (6:30am–8:30am):** The coordination window
- Document morning routine in 15-minute increments
- Count: phone calls received, text messages sent/received, decisions made
- Identify: what information is being looked for but hard to find
- Photograph: whiteboards, paper stacks, Excel screens (with permission)
- Note: where does the "I'll deal with it later" pile grow?

**Midday (8:30am–12:00pm):** The interrupt landscape
- Tally every interruption by type (tech question / customer call / vendor / internal)
- Document each schedule change: what triggered it, how long it took to resolve
- Watch for workarounds — every workaround is an automation opportunity

**Afternoon (12:00pm–5:00pm):** The administrative grind
- Observe billing/invoicing process end-to-end (time each step)
- Watch collections follow-up (is it happening? how?)
- Observe end-of-day close-out (what's left undone and why?)

### Day 2: The Field Reality (Technicians, Crew, Field Staff)

**Morning (6:00am–8:00am):** Departure protocol
- What do field staff do before leaving?
- What information do they have vs. what do they wish they had?
- What's in their truck/kit and how was it organized?

**On-site (8:00am–4:00pm):** Operational truth
- Ride along with one senior field staff member for full day
- Document every moment of "waiting" (for information, for parts, for approval)
- Observe customer interactions (communication style, questions customers ask)
- Document paperwork completion process (what gets written, what gets skipped)

**Return (4:00pm–5:30pm):** End-of-day flow
- Where does completed work documentation go?
- How long until it reaches billing? (the gap is cash flow)
- What information gets lost in the handoff?

### Day 3: The Financial Engine (Admin, Bookkeeping, Reports)

**Morning (9:00am–12:00pm):** Data entry reality
- Watch data entry process — count keystrokes, identify rework
- Observe reconciliation attempts (how often does data not match?)
- Document every system being used (including unofficial Excel files)

**Afternoon (12:00pm–5:00pm):** Reporting and decisions
- Observe how management gets information (do they ask for reports or just look?)
- Document decision-making with incomplete information ("I think we have enough margin on that job...")
- Count how many times someone says "I'm not sure, let me check"

---

## THE TECHNOLOGY AUDIT PROTOCOL

For every system discovered, capture:

```
System Name: _______________
Purpose: _______________
Who uses it: _______________
Usage level: 0-25% / 25-50% / 50-75% / 75-100% of capability
Data quality: Poor / Fair / Good / Excellent
Integration capability: None / Manual export / API available / Native integration
Primary pain point with this system: _______________
Would they abandon it? Y / N
Cost: _______________
```

**Key systems to probe for (many won't know they exist):**
- Accounting (QuickBooks, Sage, Xero, spreadsheet)
- CRM or customer database (often just QB contacts)
- Scheduling / dispatch (often just phone + whiteboard)
- Field documentation (often just paper)
- Inventory (often nothing formal)
- Payroll (ADP, Paychex, Gusto, or manual QB)
- Communication (email, WhatsApp, group text, radio)
- Estimating / quoting (paper, Excel, industry-specific tool)

---

## THE PAIN POINT QUANTIFICATION ENGINE

For every pain point identified, calculate its annual cost. This transforms observations into business case material.

### Time-Cost Formula
```
Annual Cost = (Minutes per occurrence × Frequency per week × 50 weeks × Hourly rate) / 60

Example:
"Office manager deciphers handwritten job tickets"
= (8 min × 45 tickets/week × 50 weeks × $25/hr) / 60
= $7,500/year just for this one micro-task
```

### Error-Cost Formula
```
Annual Cost = (Error rate × Volume × Cost per correction)

Example:
"Invoice errors requiring correction"
= (12% error rate × 2,500 invoices/year × $35 avg correction cost)
= $10,500/year
```

### Cash Flow Gap Formula
```
Annual Opportunity Cost = (Avg invoice value × Weekly volume × Days delayed / 7) × Capital cost rate

Example:
"Invoices sent 5 days late due to paperwork delay"
= ($425 avg × 50/week × 5 days / 7) × 8% annual rate
= $12,143/year in financing cost (or the equivalent in working capital trapped)
```

**Instruction:** Build a table of 8–12 pain points with calculated annual costs. Sum them. This is "The Number" — the total cost of the status quo. It becomes the denominator in every ROI calculation in the strategy.

---

## STAKEHOLDER MAPPING PROTOCOL

Map every stakeholder on two axes: **decision authority** (low → high) and **change resistance** (low → high).

```
High Authority / Low Resistance = CHAMPION → Protect and empower
High Authority / High Resistance = BLOCKER → Understand and address first
Low Authority / Low Resistance = EARLY ADOPTER → Use to generate evidence
Low Authority / High Resistance = SKEPTIC → Include in design, give small wins
```

For each stakeholder, document:
1. What does success look like to them personally?
2. What does failure look like to them personally?
3. What is their biggest current frustration?
4. What would make them publicly endorse this project?
5. What would make them quietly sabotage it?

---

## AGENTIC DISCOVERY — THE NEW LAYER

In the agentic era, discovery has a pre-work phase that agents can execute before the first human conversation.

**Agent-executable discovery tasks:**

```
Company Research Agent:
├─ Search: [Company name] [city] employees revenue
├─ Search: [Company name] reviews complaints (Google, BBB, Yelp)
├─ Search: [Company name] job postings → infer current software stack
├─ Search: [Owner/decision-maker name] LinkedIn → infer background, tenure
└─ Output: 2-page intelligence brief before first meeting

Industry Benchmark Agent:
├─ Search: [Industry] operational benchmarks [year]
├─ Search: Average [billing cycle / inventory accuracy / utilization] [industry]
├─ Search: [Industry] automation adoption statistics
└─ Output: Benchmark table (current state comparison data)

Competitor Intelligence Agent:
├─ Search: [Industry] companies [city/region] technology reviews
├─ Search: [Competitor] software OR system OR technology
├─ Search: [Industry] AI automation case studies ROI
└─ Output: Competitive context section for strategy
```

**What agents cannot replace in discovery:**
- Walking the physical operation (seeing the actual chaos)
- Building rapport with field staff (trust is not automatable)
- Reading body language during stakeholder interviews
- Understanding the informal power structure (who really runs things day-to-day)

---

## PRIORITIZATION MATRIX

After discovery, score each automation opportunity:

| Pain Point | Annual Cost | Frequency | Build Difficulty | Adoption Risk | Priority Score |
|------------|-------------|-----------|------------------|---------------|----------------|
| [Pain 1] | $X | Daily | Easy | Low | [1-10] |
| [Pain 2] | $X | Weekly | Medium | Medium | [1-10] |

Scoring formula: `Priority = (Annual Cost × Frequency Score) / (Build Difficulty × Adoption Risk)`

The top 3–5 scores become your Phase 1–5 targets in Section II.

---

## PHASE 0 DELIVERABLES CHECKLIST

- [ ] Written project charter (scope, timeline, success metrics, commercial terms)
- [ ] CEO/owner stakeholder alignment (verbal blessing minimum)
- [ ] Stakeholder map with engagement strategy per person
- [ ] Operations observation report (what actually happens, time-stamped)
- [ ] Technology audit spreadsheet (all systems, integration potential)
- [ ] Pain point quantification table (annual cost per pain point)
- [ ] Top 5 automation priorities (scored, sequenced, rationale documented)
- [ ] Baseline metrics (the "before" numbers every future report will compare against)
- [ ] 6-phase roadmap draft (what gets built when, and why in that order)
- [ ] Agent-executable discovery brief (for any research that can be automated)
