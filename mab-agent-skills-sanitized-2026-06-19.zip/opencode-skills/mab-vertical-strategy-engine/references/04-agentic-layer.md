# Module 04: Agentic Deployment Layer

> This module is the primary architectural upgrade from the original framework.
> Load when adding Agentic Deployment Specs to each phase, and when designing
> the autonomous execution architecture for a client engagement.

---

## THE FUNDAMENTAL SHIFT

The original HVAC thread was a masterclass in *what to build* and *in what order*. What it couldn't account for — because the world wasn't there yet — is *who builds it*.

That answer has changed.

In the original framework, every implementation step required a human to execute: set up Jotform, configure Make.com, train the techs, monitor the rollout. Each phase consumed 3–6 weeks because humans have calendars, competing priorities, learning curves, and decision fatigue.

In the agentic framework, autonomous agents execute the deterministic components of each phase — the setup, the configuration, the data migration, the testing — while humans handle the irreducibly human components: stakeholder alignment, final approval, change management, relationship decisions.

**The result:** Phase 1 (automated billing) that took 6 weeks in 2024 takes 72 hours in 2026.

This is not marketing language. This is operational reality for anyone with access to computer-use agents, Claude's API, and the MAB tool stack.

---

## THE HUMAN-AGENT BOUNDARY PRINCIPLE

The single most important design decision in any agentic deployment is where the human-agent boundary sits. Draw it wrong and you get either:
- **Over-automation**: Agents making decisions that damage relationships, miss context, or create compliance exposure
- **Under-automation**: Humans doing work that agents could execute perfectly, destroying the ROI case

**Rule of thumb for boundary placement:**

An agent should handle any task where:
1. The input can be formally specified (data format, system, trigger)
2. The output is objectively evaluable (correct/incorrect, complete/incomplete)
3. A mistake is recoverable without relationship damage
4. The task repeats at sufficient frequency to justify agent investment

A human must handle any task where:
1. The decision requires relationship context or emotional intelligence
2. A mistake is not recoverable (can't un-send, un-fire, un-commit)
3. The output requires subjective judgment that the principal hasn't yet encoded
4. Legal, financial, or compliance exposure exists without human accountability

---

## AGENTIC DEPLOYMENT TAXONOMY

Use these four tiers when specifying deployment for each phase:

### Tier 1: Fully Autonomous
Agent executes, monitors, and reports. No human touchpoint in the workflow.

*Examples:*
- Generating and sending invoices from completed job forms
- Inventory reorder alerts when threshold crossed
- Payment reminders at days 3, 7, 23, 31
- Tech schedule push notifications the night before
- Daily analytics digest email to management

### Tier 2: Human-Approved
Agent drafts, stages, or queues. Human reviews and releases.

*Examples:*
- Payroll submission (agent calculates, manager clicks approve)
- Collection escalation to legal/collections agency (agent flags, owner decides)
- Large purchase orders over threshold (agent creates PO, manager approves)
- Customer communication for service failures (agent drafts, manager sends)
- New employee onboarding workflow (agent provisions access, HR confirms)

### Tier 3: Agent-Assisted
Human leads; agent provides real-time support, data, or documentation.

*Examples:*
- Sales call: agent surfaces customer history, past invoices, open items
- Job estimate: agent calculates materials cost, suggests labor hours from history
- Hiring interview: agent provides role scorecard, suggested questions
- Strategy meeting: agent populates dashboard with current KPIs before meeting

### Tier 4: Fully Human
Agent excluded by design.

*Examples:*
- CEO succession conversations
- Employee terminations
- Major contract negotiations
- Customer dispute resolution with relationship at stake
- Any decision requiring legal attestation

---

## THE AGENTIC DEPLOYMENT SPEC FORMAT

Insert this block at the end of every phase in the strategy:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AGENTIC DEPLOYMENT SPEC — Phase [N]: [Phase Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TIER 1 — Fully Autonomous:
├─ [Task]: [Tool/API] | Trigger: [Event] | Monitor: [Dashboard view]
├─ [Task]: [Tool/API] | Trigger: [Event] | Monitor: [Dashboard view]
└─ [Task]: [Tool/API] | Trigger: [Event] | Monitor: [Dashboard view]

TIER 2 — Human-Approved:
├─ [Task]: Agent: [Tool] → Human: [Approval action] | Threshold: [When escalated]
└─ [Task]: Agent: [Tool] → Human: [Approval action] | Threshold: [When escalated]

TIER 3 — Agent-Assisted:
└─ [Task]: Agent provides [support type] during [human activity]

TIER 4 — Fully Human:
└─ [Task]: [Reason for human exclusivity]

DEPLOYMENT TIME:
├─ With agents: [X hours/days]
├─ Without agents (original estimate): [X weeks]
└─ Compression factor: [X]x faster

AGENT STACK FOR THIS PHASE:
├─ Orchestration: [Zapier / Gumloop / n8n]
├─ AI layer: [Claude API / GPT / Gemini] for [specific task]
├─ Data store: [Airtable / Supabase / Google Sheets]
└─ Notification: [Twilio / SendGrid / Slack]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## PHASE-BY-PHASE AGENTIC TRANSFORMATION

### Phase 0 (Foundation): 40% Automatable

**What agents now handle:**
- Pre-meeting company research and intelligence brief
- Competitive landscape mapping
- Technology stack inference from public data
- Stakeholder identification from LinkedIn/website
- Baseline benchmark data gathering

**What remains human:**
- The actual relationship conversations
- Gaining trust and psychological safety with the team
- The observation shadowings
- Negotiating commercial terms

---

### Phase 1 (Billing/Invoicing): 85% Automatable

**Fully autonomous:**
- Invoice generation from job completion form
- PDF creation and storage to Google Drive
- Customer email delivery with payment link
- QuickBooks sync
- Payment reminder sequences (days 3, 7, 23, 31, 45)
- Payment status monitoring and reminder suppression upon payment
- Daily AR aging report generation and delivery

**Human-approved:**
- Invoices above a threshold amount (e.g., >$5,000 until trust established)
- Invoices flagged for unusual job types or first-time customers

**Fully human:**
- Disputed invoice resolution
- Customer relationship conversations about billing concerns

---

### Phase 2 (Inventory): 75% Automatable

**Fully autonomous:**
- Low-stock alert generation and delivery to warehouse manager
- Usage logging from barcode scans
- Van restocking list generation (weekly)
- Supplier order drafts triggered by reorder point thresholds
- Inventory shrinkage flagging (system vs. physical count variance)

**Human-approved:**
- Supplier orders above threshold
- New supplier onboarding
- Inventory write-off decisions

**Fully human:**
- Physical cycle counts (agents can schedule, humans must count)
- Theft investigation

---

### Phase 3 (Scheduling): 80% Automatable

**Fully autonomous:**
- Daily schedule optimization (skills-based, route-optimized)
- Tech schedule push notification (night before)
- Customer appointment reminder (SMS + email, 24 hours prior)
- "Tech en route" notification (triggered by GPS departure event)
- "Job complete" customer notification
- Schedule conflict detection and alert
- Utilization reporting (daily, weekly, monthly)

**Human-approved:**
- Schedule changes that affect more than 3 techs simultaneously
- Emergency dispatch overrides
- Customer-requested tech reassignments

**Fully human:**
- Customer complaints about tech
- Termination of tech from schedule

---

### Phase 4 (Payroll/Time): 90% Automatable

**Fully autonomous:**
- GPS-triggered clock-in/clock-out events
- Job-level time allocation
- OT calculation and alert when approaching threshold
- Payroll data export to provider on approval
- Certified payroll report generation (government jobs)
- Missed punch detection and alert

**Human-approved:**
- Final payroll submission (agent calculates, manager approves)
- Manual time corrections
- OT approval above threshold

**Fully human:**
- Pay disputes
- HR conversations about attendance patterns

---

### Phase 5 (Collections): 80% Automatable

**Fully autonomous:**
- Entire payment reminder sequence (all 6 stages)
- Payment link generation per invoice
- Payment status monitoring and sequence suppression
- AR aging report generation
- Cash flow forecast update (rolling 30/60/90 days)
- Accounts past 60 days flagged for human escalation

**Human-approved:**
- Collections agency referral
- Payment plan agreements
- Write-off decisions

**Fully human:**
- Dispute resolution
- Relationship-preservation conversations with high-value accounts

---

### Phase 6 (Customer Experience): 70% Automatable

**Fully autonomous:**
- Appointment confirmation and reminder sequences
- "Meet your tech" pre-arrival messages
- GPS-based arrival notifications
- Job completion summaries with photos
- Review request sequences
- Automated sentiment routing (happy → Google review; unhappy → private feedback)

**Human-approved:**
- Responses to negative reviews
- Service recovery offers above threshold value

**Fully human:**
- Complex complaint resolution
- High-value account relationship management

---

### Phase 7 (Maintenance Contracts): 75% Automatable

**Fully autonomous:**
- Maintenance schedule creation from contract enrollment
- Appointment calendar invites and reminders
- Renewal notice sequences (60/30/14/7 days before expiry)
- Auto-renewal processing (with payment on file)
- Lapsed contract re-engagement sequences

**Human-approved:**
- Contract pricing exceptions
- New contract upsell calls

**Fully human:**
- Contract negotiation for large commercial accounts
- Cancellation retention conversations

---

### Phases 8–11: Progressive Autonomy

As the data foundation matures through Phases 1–7, agentic capability compounds:

**Phase 8 (Predictive):** Agents monitor IoT sensor streams, detect anomaly patterns, auto-create service orders, stage parts at warehouse. Human approves dispatches, interprets novel failure patterns.

**Phase 9 (Knowledge):** Agents surface relevant documentation, troubleshooting guides, and historical job data during field work. Agents run onboarding module completion tracking. Humans create content, resolve novel situations.

**Phase 10 (BI):** Agents generate daily executive digests, weekly performance reports, monthly board decks — all populated automatically from the data infrastructure built in Phases 1–7. Humans interpret, decide, and act.

**Phase 11 (Scale):** Agents power the new-engagement onboarding — pre-populating discovery briefs, drafting proposals, setting up tech stacks from playbook templates. Humans do relationships, negotiations, and judgment calls.

---

## MONITORING ARCHITECTURE

Every autonomous workflow requires a monitoring layer. Without it, "autonomous" becomes "unaccountable."

**The Four Monitoring Principles:**

1. **Every agent action creates a log entry** — Who/what triggered it, what it did, outcome
2. **Anomalies surface to humans within 15 minutes** — Not end-of-day, not weekly report
3. **Thresholds create automatic pause points** — Agent escalates rather than guesses when encountering unusual conditions
4. **Weekly audit review** — Human reviews agent activity summary to catch drift

**Standard monitoring stack:**
- Airtable (log store + anomaly view)
- Slack or email (real-time alerts)
- Weekly automated digest (agent generates, manager reviews)
- Monthly accuracy audit (agent accuracy vs. human spot-check)

---

## THE TRUST CURVE

Agentic deployment follows a predictable adoption curve:

```
Week 1–2: Skepticism ("Will it work? What if it breaks?")
Week 3–4: Parallel running (agent + human both do the task)
Week 5–6: Tentative trust (human spot-checks but doesn't redo)
Week 7–8: Active trust (human only reviews exceptions)
Month 3+: Deep trust (human sets rules, agent executes, human governs)
```

Never try to compress the trust curve through argument. Compress it through evidence — each correct agent action builds trust faster than any sales pitch.

**The single best trust accelerator:** Show them the agent working in real time during the first training session. Not a slide about what the agent does. The agent, doing it.
