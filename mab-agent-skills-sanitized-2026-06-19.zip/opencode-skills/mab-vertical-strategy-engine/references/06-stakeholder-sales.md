# Module 06: Stakeholder Intelligence & Sales Architecture

> Load when building Section III (Industry Customization — Personas, Objections, Scripts).
> Also used to design Phase 0 stakeholder engagement plans and change management strategy.
> This module governs the human side of automation — which is always the harder side.

---

## DESIGN PRINCIPLE: EMPATHY IS ARCHITECTURE

Automation strategies fail at the human layer more often than the technical layer. The systems work. The people don't adopt. The reason is almost never resistance to technology — it's resistance to what the technology implies about the current way of doing things.

An invoice automation system doesn't just save time. It implicitly says: "The way you've been doing invoices is wasteful." An inventory system doesn't just track parts. It implicitly says: "You've been losing money you couldn't see." A scheduling optimizer doesn't just route techs efficiently. It implicitly says: "The dispatcher's expertise is now partially replaceable."

Understanding what each stakeholder hears when they see your system determines whether they become a champion or a blocker.

---

## THE FIVE UNIVERSAL STAKEHOLDER ARCHETYPES

These archetypes appear in every mid-market service business, regardless of industry. Map real people to these types during Phase 0 discovery.

---

### Archetype 1: The Succession Leader

**Who they are:** The next-generation owner, heir apparent, or incoming executive. Usually 30–50 years old. Educated (often first college degree in the family). Technically literate but not technical. Trying to prove they're ready to lead while not overstepping the founder's authority.

**What they want:** Credibility. They need to demonstrate that the business is better under their influence than it was. The moment they can point to a system and say "I built that" — even if MAB built it — is the moment they stop being the founder's kid and start being the CEO.

**What they fear:** Making a costly mistake that proves they weren't ready. Disrupting the family business in a way the founder never forgives. Alienating the old guard (long-tenured employees who remember "when things worked fine").

**Engagement strategy:**
- Position MAB as their strategic partner, not a vendor the company hired
- Frame each phase as "you're building this" — your design decisions, your system
- Give them data they can present to the founder: "We're 47% faster at billing"
- Make them the internal champion at every milestone
- Share credit publicly, keep them informed privately
- Never embarrass them in front of their team or their parent

**Language that resonates:**
*"This gives you visibility that no one in this company has ever had."*
*"When your dad retires, you'll hand him a business worth 3x what he built."*
*"Let me give you the data so you can present this to him."*

---

### Archetype 2: The Founder/Owner

**Who they are:** Built the company. Often 55–70 years old. Deep industry expertise. Minimal formal technology exposure. Has survived every economic downturn, competitor threat, and operational crisis through instinct and relationships. Deeply proud of what they've built. Worried about what happens after they're gone.

**What they want:** Legacy. To know the company they built will outlast them, grow, and reflect their values. They want their successor to succeed. They also want their lifetime of expertise to be respected, not discarded.

**What they fear:** Technology that makes them look obsolete. A "system" that doesn't understand the nuances they've spent 30 years developing. The company losing the personal touch that made it successful. Being replaced before they're ready.

**Engagement strategy:**
- Ask for their expertise, not their buy-in. "How did you handle this situation?" not "Do you support this change?"
- Frame automation as "capturing what you know so it doesn't leave when you do"
- Never introduce a system in a meeting where the founder hasn't been briefed privately first
- Show them data that validates their instincts (automation rarely proves them wrong; it usually proves them right)
- Give them a way to "bless" each phase — even a simple "this looks right to me" gives them agency

**Language that resonates:**
*"This is about making sure your way of doing things survives your retirement."*
*"Everything you've figured out over 35 years — we're encoding it so the next generation can use it."*
*"Nothing changes about how the business treats customers. We're just removing the manual overhead underneath."*

---

### Archetype 3: The Operational Gatekeeper

**Who they are:** Office manager, operations coordinator, dispatch manager, or senior admin. Often has been with the company 8–20 years. Knows where every body is buried. De facto keeper of process knowledge. Often not on the org chart at decision-making level, but functionally controls whether any change succeeds.

**What they want:** To be valued for what they know. Recognition that the current system works as well as it does *because of them*. To not be replaced. To have a less stressful job without losing their importance.

**What they fear:** That automation means their job disappears. That a machine will do what they do and they'll be made redundant. That their 15 years of "knowing how things work here" will suddenly be worthless.

**Engagement strategy:**
- Interview them deeply in Phase 0. Not for information alone — to signal that their expertise is the foundation of whatever gets built.
- Include them in design decisions. "This is how we were thinking about the billing form — what would you change?" Their input improves the product AND buys their loyalty.
- Explicitly reframe their job: "You're going from doing this manually to managing a system that does it automatically. That's a promotion, not a replacement."
- Give them early access before anyone else. The operational gatekeeper who gets a preview becomes an evangelist; one who finds out from the announcement becomes a critic.
- Never roll out over their head. If they feel bypassed, they will passively undermine adoption.

**Language that resonates:**
*"You're the one who actually knows how this works. We need you to help design it."*
*"Instead of spending 20 hours a week on data entry, you'll be the person who makes sure the system runs right."*
*"When this is working, your job becomes managing the exception instead of doing the routine. That's a better job."*

---

### Archetype 4: The Field Staff (Skeptics)

**Who they are:** Technicians, drivers, installers, field reps. Likely 25–55 years old. Broad range of tech sophistication. Many have been doing the job "the same way for years" and that's worked fine. Their primary loyalty is to getting their work done, not to any management initiative.

**What they want:** To not add steps to their day. To be trusted. To be paid accurately. To have the information they need to do their jobs without having to chase it down.

**What they fear:** Being monitored or tracked. Having their autonomy reduced. Being disciplined based on data they don't understand or trust. Looking incompetent in front of peers.

**Engagement strategy:**
- Lead with "what this does for you" not "what this requires from you"
- GPS tracking: Frame as protection, not surveillance. "If a customer disputes that you were there, the GPS proves you were."
- Form submission: Frame as "no more end-of-day paperwork." That's the win they care about.
- Payroll accuracy: "You'll know exactly what you're getting paid every week before payday."
- Give them 1:1 training, not group-only. Field staff adopt when they're comfortable, not when they're observed.
- Find 1–2 tech-positive field staff early (the "early adopters") and make them internal heroes. Others follow.

**Language that resonates:**
*"You won't have to fill out paper tickets anymore."*
*"Your route will be optimized — less driving, same pay."*
*"If there's ever a dispute about what you did or where you were, the system backs you up."*

---

### Archetype 5: The Financial Controller

**Who they are:** Controller, bookkeeper, accountant, or CFO (title varies widely). Handles all financial recording, reporting, and reconciliation. May be internal or external (CPA firm on retainer). Risk-averse by nature. Deeply protective of data integrity.

**What they want:** Clean, accurate, audit-ready data. To not redo work because someone upstream made an error. Predictable, reliable processes that hold up under scrutiny.

**What they fear:** Systems that introduce errors into the financial record. Integration failures that create reconciliation nightmares. Any change that creates compliance exposure. Data loss.

**Engagement strategy:**
- Involve them in Phase 1 design specifically for the QuickBooks/accounting integration
- Build the integration to match how they expect data to flow, not how MAB thinks it should flow
- Provide full audit trails for every automated transaction
- Show them the error rate improvement (automation almost always produces cleaner data than manual entry)
- Give them an easy "undo" or correction path for edge cases

**Language that resonates:**
*"Every automated transaction creates a complete audit trail."*
*"Error rates drop from 12% to under 2% — your reconciliation time goes down significantly."*
*"Nothing posts to QuickBooks without matching your existing chart of accounts."*
*"You'll have a data quality dashboard, not just more data."*

---

## OBJECTION HANDLING ARCHITECTURE

Every objection lives in one of four categories. Diagnosing the category determines the response strategy.

```
Category 1: VALUE OBJECTION ("I don't see why this is worth it")
Strategy: More data, not more talking. Show the financial model.

Category 2: RISK OBJECTION ("What if it breaks / goes wrong?")
Strategy: Reduce perceived risk. Show safeguards, rollbacks, and support.

Category 3: TIMING OBJECTION ("Not right now")
Strategy: Uncover real objection. "Not right now" almost always means something else.

Category 4: AUTHORITY OBJECTION ("I need to check with...")
Strategy: Accelerate to decision-maker. Enable the champion, don't wait passively.
```

---

## UNIVERSAL OBJECTION SCRIPTS

### "This is too expensive."
*Category: Value Objection*

"I want to make sure we're comparing the right things. The cost of this system is [X]. The cost of the current system — the one that's already running — is [The Number from discovery]. That's not hypothetical; we calculated it from your operations. The question isn't whether you can afford this investment. The question is whether you can afford to keep paying for what you already have."

*If they push further:*
"Let me show you the payback model. If Phase 1 alone delivers [X] in annual benefit, and costs [Y] to implement, you've recovered the investment in [Z] weeks. Everything after that is profit recovery. What specifically about the number concerns you?"

---

### "We've tried technology before and it didn't work."
*Category: Risk Objection*

"Tell me what happened. Specifically, what broke down — was it the technology itself, the rollout, the training, or the adoption?"

*After they explain:*
"That's important context. [Specific response to their specific failure]. What's different here is [specific structural difference]. But here's my bigger point: the reason I start with Phase 1 and not a full system deployment is exactly because of situations like what you described. We build one automation, prove it works with your specific team, measure the result, and then earn the right to build the next one. You're not committing to a transformation. You're committing to a test."

---

### "I need to think about it."
*Category: Timing (hidden)*

"Absolutely. I want to make sure you have everything you need to think it through clearly. Can I ask — is there a specific aspect you're uncertain about, or is it more that you want to run it by someone else before deciding?"

*If there's a real concern:* Address it directly.
*If it's someone else:* "Who would need to be part of this conversation? I'd rather we both be there than play telephone."
*If it's genuine hesitation:* "What would need to be true for this to be an easy yes?"

---

### "We don't have time for a big implementation."
*Category: Timing Objection*

"The most common reason companies wait until they have time is that the current system is consuming all of it. That's the trap. I'm not proposing a big implementation. I'm proposing a 2-week sprint where you and I build one automation together. Your time investment: 3 hours in week one, 2 hours in week two. Everything else is my work. If it doesn't save more time than you invested within 30 days, we stop. Does that feel like something you have time for?"

---

### "My team won't use it."
*Category: Risk Objection*

"You're right that adoption is the most common failure point. That's exactly why the first automation we build is the one your team will use because it makes their job easier — not harder. [Specific example: 'Instead of dropping paper tickets at the office, techs submit a 4-minute form and they're done. No more driving across town to drop paperwork.'] Resistance drops dramatically when the new system removes a step rather than adding one. Which team members do you think would be easiest to start with?"

---

### "Can you just give me a price?"
*Category: Authority/Readiness*

"I can give you a range, but here's the challenge — giving you a number before I understand your situation is how contractors get into trouble with clients. If I quote [low number] and it turns out to be [high number], you're upset. If I quote [high number] and it turns out to be [low number], you've already moved on. What I can tell you is that for a company your size, Phase 1 alone typically runs [range], and pays back in [range] weeks. Can I spend 30 minutes learning enough about your situation to give you a number I'll stand behind?"

---

### "We're not ready for AI."
*Category: Value + Risk*

"I hear that a lot, and I want to reframe what I'm actually proposing. I'm not talking about replacing anyone with AI. I'm talking about automating a process your team already does manually every day — generating invoices, sending reminders, tracking inventory. The 'AI' part is mostly invisible. What your team experiences is: the invoice creates itself, the reminder sends itself, the reorder triggers itself. It looks less like science fiction and more like 'the system handles the boring stuff.' Would it help to walk through one specific example in your business?"

---

## CHANGE MANAGEMENT TIMING PROTOCOL

Announcement sequencing matters as much as the announcement content:

```
T-3 weeks: Inform key stakeholders privately (CEO, champion, operational gatekeeper)
T-2 weeks: Department heads briefed (what's changing, why, what's not changing)
T-1 week: Full team announcement (framing: benefit to them, not requirement from them)
Launch day: Champion makes the announcement, not outside consultant
Week 1: Daily visible support (you're physically present or readily available)
Week 2: Proactive check-ins with resistors
Week 4: First success story shared internally (the "this is working" moment)
Month 2: Recognition for early adopters
Month 3: Normalized — new system IS the system
```

**Never:** Announce a technology change and then leave the company to figure out adoption. That's the single most common implementation failure pattern.

**Always:** Find 1–2 internal evangelists before launch. One enthusiastic early adopter from inside the team is worth a hundred expert presentations.
