---
name: mab-vertical-strategy-engine
description: |
  MAB AI Strategies' end-to-end vertical intelligence and go-to-market strategy engine. Triggers on ANY of these inputs: a named industry ("HVAC contractors", "dental practices", "logistics"), a company name or names, a geographic input (zip code, city, state, region), a market trend or disruption signal, or a sales promotion scenario. Produces a complete, agentic-era strategy document covering market intelligence, stakeholder mapping, phase-by-phase implementation with autonomous agent deployment specs, financial modeling, and a productization roadmap. Always use this skill when the user provides an industry vertical, company target, geographic market, trend to analyze, or promotional angle — even if they don't say "strategy" or "plan." This is the primary revenue generation tool for MAB AI Strategies. When in doubt, trigger it.
---

# MAB Vertical Strategy Engine
## The Agentic-Era Go-To-Market Intelligence System

> **Design philosophy:** This plugin replicates the structural properties that made the MAB HVAC strategy exceptional — quantified pain before solutions, multi-voice stakeholder architecture, verbatim execution collapsing, per-phase standalone ROI — while updating the deployment layer for autonomous agents. What previously took 6-12 months to implement now takes 6-12 weeks. The framework was always right. The clock speed changed.

---

## STEP 0: INPUT CLASSIFICATION

Identify which input type the user provided, then route to the correct intelligence-gathering protocol before executing the strategy stack.

| Input Type | Example | Route To |
|------------|---------|----------|
| **Industry vertical** | "HVAC contractors", "skilled nursing" | Full strategy (all 7 modules) |
| **Company name(s)** | "Acme Plumbing", "XYZ Medical Group" | Company-specific strategy (modules 1, 2, 3, 4, 5, 6, 7 with company context injected) |
| **Geographic input** | "19701", "Sussex County DE", "Mid-Atlantic region" | Market landscape + vertical opportunity mapping |
| **Market trend** | "heat pump adoption", "AI in diagnostics" | Trend analysis + first-mover positioning strategy |
| **Sales promotion** | "summer AC tune-up special", "launch offer for new clients" | Campaign strategy + channel + sequence design |

**For ambiguous inputs:** Default to Industry Vertical routing. A user typing "roofing companies" without further context gets the full strategy treatment.

**For compound inputs:** e.g., "commercial HVAC in Wilmington DE" = Industry + Geography. Run both intelligence streams and merge. The geographic context becomes Section III customization.

---

## STEP 1: PRE-STRATEGY CLARIFICATION (2 questions max)

Before generating, ask the two most strategically levered questions. Do not ask five. Do not ask what you can infer.

**For Industry input:**
1. "Company size focus: SMB (1–20 employees), mid-market (20–150), or enterprise (150+)?"
2. "Do you have an existing relationship in this vertical — a contact, client, or insider — or are you entering cold?"

**For Company input:**
1. "Is this a prospect you're targeting, a client you're already working with, or a case study you're building from?"
2. "What do you know about their current tech stack or biggest operational pain?"

**For Geographic input:**
1. "Which industry verticals are you targeting in this market, or do you want me to identify the highest-opportunity ones?"
2. "Are you looking to win business here, or map competitors and partners?"

**For Trend input:**
1. "Are you building a service offering around this trend, or positioning MAB as the thought leader in front of clients experiencing it?"
2. "Which industry vertical(s) does this trend most affect for you right now?"

**For Promotion input:**
1. "Who is this promotion targeting — new prospects, existing clients, or a specific segment?"
2. "What outcome defines success — booked calls, closed deals, renewals, upsells?"

**If the user has already provided answers in context (prior messages, memory), skip asking and state your inference.**

---

## STEP 2: INTELLIGENCE GATHERING

Use `web_search` to gather current, specific market intelligence before writing a word of strategy. Do not rely on training data for market sizing, competitive landscape, or regulatory specifics.

**Minimum required searches:**

```
For Industry input (run all 4):
1. "[industry] market size US 2025 2026"
2. "[industry] technology adoption gaps automation challenges"
3. "[industry] private equity consolidation OR software landscape 2025"
4. "[industry] regulatory requirements compliance [state if geographic]"

For Company input (run all 3):
1. "[company name] [city/state] revenue employees"
2. "[company name] technology stack software reviews"
3. "[company name industry] competitors [region]"

For Geographic input (run all 3):
1. "top industries [city/region] small business density 2025"
2. "AI automation adoption [state] SMB market 2025"
3. "[region] economic outlook growth sectors 2025 2026"

For Trend input (run all 3):
1. "[trend] adoption rate statistics 2025"
2. "[trend] impact on [relevant industry] operations"  
3. "[trend] AI automation opportunity vendors"

For Promotion input (run all 2):
1. "[industry] seasonal demand patterns [relevant season]"
2. "[service type] promotion response rates B2B"
```

**Read project knowledge first.** Always call `project_knowledge_search` before web search for any vertical or company the user has previously worked on.

---

## STEP 3: STRATEGY GENERATION — MODULE SEQUENCE

Execute modules in order. Do not skip. Do not compress phases to save tokens — this is a premium deliverable.

**Load references as needed:**

```
references/01-intel-module.md      → Sections I (Strategic Context) 
references/02-discovery-module.md  → Phase 0 of execution plan
references/03-opportunity-arch.md  → Phases 1-5 (core automation stack)
references/04-agentic-layer.md     → Agentic deployment specs per phase
references/05-financial-intel.md   → Section IV (Financial Modeling)
references/06-stakeholder-sales.md → Section III (Personas, Objections, Scripts)
references/07-delivery-module.md   → Output formatting, Google Doc, executive summary
```

### REQUIRED OUTPUT STRUCTURE

Deliver all five sections. Section II is the longest (60-70% of total output).

```
I.   STRATEGIC CONTEXT & POSITIONING         (~2,000 words)
II.  PHASE-BY-PHASE EXECUTION PLAN           (~15,000 words, 11 phases)
     └── Each phase includes Agentic Deployment Spec (NEW)
III. INDUSTRY-SPECIFIC CUSTOMIZATION         (~4,000 words)
IV.  FINANCIAL MODELING                      (~2,500 words)
V.   BUSINESS SCALING STRATEGY              (~3,000 words)
```

---

## STEP 4: AGENTIC DEPLOYMENT SPEC (per phase)

This is the key update from the original framework. Every phase now includes a subsection:

```
## AGENTIC DEPLOYMENT SPEC — Phase [N]

Autonomous (Agent handles, no human required):
├─ [Task]: [Agent type] using [Tool/API]
├─ [Task]: [Agent type] using [Tool/API]
└─ [Task]: [Agent type] using [Tool/API]

Human-in-Loop (Agent drafts, human approves):
├─ [Task]: Reason for human touch
└─ [Task]: Reason for human touch

Fully Human (Agent cannot safely handle):
└─ [Task]: Reason (relationship, legal, judgment call)

Time to Deploy: [X hours/days with agents vs. X weeks manual]
Agent Stack: [Tools in MAB default stack: Zapier/Gumloop → Apps Script]
```

This spec transforms each phase from a "planning document" into a "deployment checklist."

---

## STEP 5: QUALITY GATES

Before delivering, verify:

- [ ] All 11 phases covered — no summarizing or collapsing
- [ ] Every phase has a standalone ROI calculation
- [ ] Every phase has an Agentic Deployment Spec
- [ ] Industry-specific language used throughout (not generic "field service")
- [ ] At least 3 verbatim scripts or templates included
- [ ] Financial modeling uses real numbers (not ranges of ranges)
- [ ] Stakeholder section covers at least 3 distinct personas
- [ ] At least 8 objections with full rebuttals
- [ ] Geographic/regulatory context woven in if provided
- [ ] Output delivery protocol followed (see references/07-delivery-module.md)

---

## STEP 6: OUTPUT DELIVERY

See `references/07-delivery-module.md` for full protocol.

**Summary:**
1. Attempt Google Doc creation via Google Drive MCP
2. If unavailable, output full strategy in chat
3. Always provide executive summary (300-400 words) in chat regardless
4. Always close with "Engagement Loop" — 3 specific follow-up offers

**Engagement Loop template:**
```
What would make this most actionable right now?

A) [Specific Phase X deep-dive based on their situation]
B) [Financial model with their actual numbers]  
C) [First 3 agentic automations built live in this chat]
D) [Proposal/pitch deck for a specific prospect]
```

---

## TONE & EXECUTION STANDARDS

- Write like someone who has operated in this industry, not studied it from outside
- Every number should be defensible (cite source or clearly mark as "estimated")
- Acknowledge when something is risky — it builds more credibility than false certainty
- Match the user's language and pain vocabulary, not industry analyst jargon
- Provide bold options AND conservative options — let the user choose their risk tolerance
- If you spot a flaw in their premise, say it in one sentence before building the strategy
- Never pad. If a section is strong in 500 words, don't stretch it to 1,000

---

## ITERATION PROTOCOL

If the user returns with "here's what we're learning in market":
1. Pull prior strategy from project knowledge or conversation history
2. Log what's validating vs. what's not
3. Update 2-3 specific phases based on signal
4. Document the delta explicitly: "Updated from [X] to [Y] because [Z]"
5. Re-run financial modeling with new assumptions

This turns the strategy from a static document into a living system.
