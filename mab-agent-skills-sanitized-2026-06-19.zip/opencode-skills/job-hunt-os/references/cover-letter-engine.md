# Cover Letter Engine

## Objective
Produce a concise, company-specific cover letter that sounds like the user and materially improves interview odds.

## Requirements
- final file must be PDF unless user overrides
- company-specific opening
- connect 2–3 verified achievements to the target role
- demonstrate awareness of current company priorities
- end with a direct, credible close
- avoid generic openings and AI-sounding filler

## Tone
- practical
- high-conviction
- commercially fluent
- AI-forward where relevant
- concise
