# Interview Prep Engine

Return:
- company brief
- role brief
- current company themes
- likely objections
- tailored value proposition
- 10 to 15 likely interview questions
- best answer angles based on the user's record
- story bank mapped to competencies
- smart questions for recruiter, hiring manager, and peers
- optional 30 / 60 / 90 day framing
