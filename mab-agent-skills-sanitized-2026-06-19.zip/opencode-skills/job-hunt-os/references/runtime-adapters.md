# Runtime Adapter Notes

This skill package is production-oriented but runtime-agnostic.

Recommended adapters:
- Web research adapter for current-day verification
- PDF renderer for resume / cover letter outputs
- Spreadsheet adapter for dashboard logging
- Email / messaging adapter for follow-up drafts or sends
- Calendar adapter for reminders
- Design adapter for optional Figma / Canva branded outputs
- Repository adapter for GitHub evidence retrieval

Never assume a connector exists unless explicitly enabled.
