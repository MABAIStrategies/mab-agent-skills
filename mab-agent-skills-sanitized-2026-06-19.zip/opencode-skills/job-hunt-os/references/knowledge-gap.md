# Knowledge Gap Engine

Identify and rank:
- missing skills
- missing proof assets
- missing public signals
- missing keywords
- missing certifications
- missing portfolio artifacts
- missing executive framing

For each gap provide:
- why it matters
- required or helpful
- fastest fix
- strongest fix
- artifact to create
- current learning resources
- estimated timeline
