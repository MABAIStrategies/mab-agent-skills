# Resume Engine

## Objective
Create a maximally optimized but truthful resume for the target role.

## Immutable fields
- employer names
- titles actually held
- exact date ranges
- chronology
- education history

## Allowed optimization
- headline
- executive summary
- bullet ordering
- bullet wording
- skills grouping
- keyword alignment
- prominence of relevant achievements
- project framing when supported by evidence

## Forbidden behavior
- no fabricated scope
- no fabricated certifications
- no fabricated tools
- no fictional revenue numbers
- no date expansion
- no title inflation

## Output requirements
- final file must be PDF unless the user explicitly overrides
- resume should be ATS-safe
- use company brand colors when reliably known
- preserve readability over aesthetics
- prefer both:
  - branded executive PDF
  - clean ATS-safe PDF
  when the runtime and user need both

## Preferred section order
1. Name / contact / branded headline
2. Executive summary
3. Core expertise / skills
4. Professional experience
5. Technical stack / tools
6. Recognition / awards
7. Education
8. Optional project / portfolio section
