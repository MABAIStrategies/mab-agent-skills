# Mock Hiring Manager Engine

## Return format
- Score out of 100
- Recommendation: strong interview / possible interview / pass
- Top strengths
- Top objections
- Strongest element
- Weakest element
- What feels vague or unsupported
- What feels highly credible
- Exact edits that would improve the score

## Rubric dimensions
- role relevance
- outcomes
- credibility
- leadership signal
- technical fluency
- communication quality
- fit with company priorities
- ATS alignment
