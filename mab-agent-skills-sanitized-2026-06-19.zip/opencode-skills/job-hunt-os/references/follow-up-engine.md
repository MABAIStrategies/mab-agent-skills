# Follow-Up Engine

## Default sequence
- T0: recruiter outreach after application submission
- T+1 day: hiring manager outreach if no recruiter response
- T+3 days: peer discovery and outreach if no recruiter or hiring manager response

## Message objective
Ask for 15 minutes to ask a few preparatory questions.

If the contact declines a call, ask:
- What's the main thing you hope to see the person in this role focus on or build?
- What's the biggest bottleneck or challenge in the role today?

## Messaging rules
- personalized, never generic
- warm, low-friction, specific
- clearly tied to the role
- avoid desperation or over-selling
- log all messages in the dashboard if tracking exists
