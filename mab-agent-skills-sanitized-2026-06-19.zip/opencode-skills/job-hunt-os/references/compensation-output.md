# Compensation Output Contract

Return compensation in this exact order:

1. Quick answer — most likely total annual compensation
2. Base range
3. Bonus range — percentage and dollar range
4. Other comp — equity / LTI / deferred estimate
5. Most-likely total cash
6. Most-likely total comp
7. Three scenarios — Conservative / Typical / Stretch
8. Percentiles — 25th / Median / 75th
9. Top 5 factors that push pay up or down
10. Negotiation guidance — exact phrasing and target ask
11. Confidence — Low / Medium / High with reason
12. Next steps — 2 to 3 actions

Rules:
- Use current-day information whenever market signals may have changed.
- Use narrower ranges and one suggested base / total-comp ask.
- Round ranges to nearest $1,000 and targets to nearest $100.
- Always keep the estimate evidence-based.
