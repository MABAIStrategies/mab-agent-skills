# Quick Start

## Inputs supported
- job URL
- screenshot
- pasted job description
- title only

## Default outputs
- compensation estimate
- tailored resume PDF
- tailored cover letter PDF
- application path
- follow-up plan
- interview prep
- mock hiring-manager review
- knowledge-gap guide
- dashboard payload

## Standing default
Resumes and cover letters are PDF-only unless the user explicitly says otherwise.
