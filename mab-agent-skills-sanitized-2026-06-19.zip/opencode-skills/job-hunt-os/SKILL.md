---
name: job-hunt-os
description: >
  End-to-end job hunt operating system for compensation estimation, truthful role-specific
  resume and cover letter generation, PDF-only application assets, post-application follow-up,
  interview preparation, mock hiring-manager review, knowledge-gap analysis, and dashboard tracking.
  Use this skill whenever a user provides a job URL, screenshot, pasted job description, or job title
  and wants a full application package or job-search workflow support.
---

# Job Hunt OS Skill

## Purpose

This skill converts a job opportunity into a current, role-specific application package and
operational follow-through system.

It is designed to accept:
- a job URL
- a screenshot
- a pasted job description
- or a title-only target

And return:
- current compensation estimate
- tailored resume PDF
- tailored cover letter PDF
- application route detection
- recruiter / hiring-manager / peer follow-up plan
- interview prep pack
- mock hiring-manager review
- knowledge-gap study guide
- dashboard-ready tracking record

---

## Standing Rules

### 1. Freshness rule
Any information that may have changed must be checked using current research on the day of generation.

Always verify, when relevant:
- current job posting availability
- current application URL
- salary / compensation signals
- current company priorities, AI initiatives, culture signals, and hiring themes
- current role location / remote status
- current ATS or application path

### 2. Resume and cover letter output format
Resumes and cover letters must be delivered in **PDF format by default**.
Do not deliver DOCX unless the user explicitly overrides this rule.

### 3. Truth constraints
The following fields are immutable unless the user explicitly corrects them:
- employer names
- titles actually held
- date ranges / tenure
- chronology / role order
- education history

You may optimize:
- summaries
- bullet phrasing
- sequencing
- keyword alignment
- skill grouping
- headline / positioning language
- inferred business framing, only when rooted in the user’s source material

You may not:
- invent employers, dates, titles, certifications, awards, or revenue numbers
- materially exaggerate scope without evidence
- claim implementation of systems or tools not supported by the record

### 4. Source-of-truth hierarchy
Use this evidence order:
1. user-approved master resume
2. uploaded resume variants
3. user-provided accomplishments, projects, awards, and documented build work
4. prior approved application materials
5. current public research
6. cautious inference consistent with items 1–5

### 5. Tone and brand
Default tone:
- commercially fluent
- AI-forward
- practical
- confident
- operator-minded
- concise
- high-credibility

### 6. PDF design rule
When producing a branded executive resume, prefer:
- company brand colors when reliably identified
- ATS-safe typography and structure
- clean visual hierarchy
- a professional headshot when the user wants the branded version

If headshot usage is part of the user’s established workflow, include it unless the user asks not to.

---

## Workflow

## Phase 1 — Intake classification

Classify the input:
- URL
- screenshot
- pasted job description
- title only

### URL
- fetch the current listing
- determine if it is a direct company posting or aggregator
- extract title, company, location, work mode, responsibilities, requirements, preferred skills, and apply path

### Screenshot
- extract visible signals from the image
- identify title, company, location, work mode, posted date, Easy Apply indicators, and visible keywords
- supplement with current research when needed

### Pasted job description
- parse directly
- extract responsibilities, qualifications, language, tools, and culture signals

### Title only
- build a composite current role profile using research
- mark lower confidence until company-specific context exists

---

## Phase 2 — Current research pass

Research must produce:
- official job title
- company name
- company business context
- current application path
- current compensation signals
- current company themes / hot-button topics
- keywords and phrases that “speak the language” of the company
- likely culture and organizational context
- current ATS / application method classification

Classify application path as one of:
- LinkedIn Easy Apply
- direct company site
- Workday
- Greenhouse
- Lever
- Ashby
- other ATS
- unclear

Prefer the direct company application route when available.

---

## Phase 3 — Compensation engine

Follow the structure in `references/compensation-output.md`.

Required order:
1. Quick answer
2. Base range
3. Bonus range
4. Other comp / LTI estimate
5. Total cash range
6. Total comp range
7. Three scenarios
8. Percentiles
9. Top pay factors
10. Negotiation guidance
11. Confidence
12. Next steps

Rules:
- use current-day information when any signal may have changed
- produce a narrower best estimate instead of a vague wide band
- use role, company, location, level, scope, and industry context
- explicitly state uncertainty when evidence is incomplete

---

## Phase 4 — Resume engine

Follow `references/resume-engine.md`.

Objective:
Produce the strongest truthful resume possible for the target role.

Hard rules:
- final resume output must be PDF unless the user explicitly says otherwise
- preserve dates exactly
- preserve employer sequence exactly
- preserve roles and tenure exactly
- do not fabricate experience

Allowed optimization:
- rewrite headline and summary
- reorder bullets by relevance
- highlight the strongest verified accomplishments
- mirror exact job language when truthful
- sharpen bullets into stronger impact statements
- add derived bullets only when directly supported by evidence

Required checks:
- chronology preserved
- claims grounded
- role fit obvious
- ATS-safe wording
- target-company language reflected
- final delivery is PDF

---

## Phase 5 — Cover letter engine

Follow `references/cover-letter-engine.md`.

Objective:
Produce a concise, company-specific, role-specific cover letter that sounds like the user.

Hard rules:
- final cover letter output must be PDF unless the user explicitly says otherwise
- must not sound generic
- must reflect current company context when available
- must remain truthful to the user’s background

Preferred structure:
- hook tied to company / role
- 2–3 matching achievements
- understanding of what the company cares about now
- direct close and call to action

---

## Phase 6 — Follow-up engine

Follow `references/follow-up-engine.md`.

Default sequence after application submission:
1. same-day recruiter outreach
2. if no recruiter response after 1 day, hiring-manager outreach
3. if no recruiter or hiring-manager response after 3 days, peer discovery and outreach

Message goal:
Request a brief 15-minute phone call for preparatory context.
If they are not open to a call, ask:
- what is the one main thing you hope the person in this role will focus on or build?
- what is the biggest bottleneck facing the role or team?

All follow-up drafts should feel:
- specific
- warm
- low-friction
- prepared
- not transactional

---

## Phase 7 — Interview prep engine

Follow `references/interview-prep.md`.

Return:
- company brief
- role brief
- likely themes and objections
- tailored value proposition
- likely interview questions
- best answer angles
- story bank mapped to competencies
- recruiter questions
- hiring-manager questions
- peer questions
- optional 30 / 60 / 90 framing

---

## Phase 8 — Mock hiring-manager engine

Follow `references/mock-hiring-manager.md`.

Return:
- score out of 100
- recommendation
- top strengths
- top objections
- strongest elements
- weakest elements
- what looks vague
- what looks highly credible
- exact edits that would improve the score

---

## Phase 9 — Knowledge-gap engine

Follow `references/knowledge-gap.md`.

Identify:
- missing skills
- missing proof assets
- missing keywords
- missing public signals
- missing certifications
- missing portfolio artifacts
- missing executive framing

For each gap, provide:
- why it matters
- whether it is required or helpful
- fastest fix
- strongest fix
- artifact to create
- current learning resources
- timeline to close

May include:
- diagrams
- infographics
- study plans
- research-backed summaries

---

## Phase 10 — Dashboard agent handoff

Follow `schemas/dashboard-schema.yaml`.

Each opportunity should be able to produce a structured record for:
- opportunity metadata
- compensation
- contact discovery
- application status
- outreach history
- next follow-up
- generated assets
- interview stage
- notes

---

## Required final package

Unless the user narrows scope, aim to return:
- compensation estimate
- resume PDF
- cover letter PDF
- direct application path
- follow-up plan
- interview prep pack
- mock hiring-manager review
- knowledge-gap guide
- dashboard row payload

---

## QA checklist before delivery

- Are employer names unchanged?
- Are dates unchanged?
- Is chronology unchanged?
- Are claims grounded in evidence?
- Is current research reflected where needed?
- Is the application path current?
- Is the compensation estimate current?
- Are resume and cover letter delivered as PDF?

---

## Runtime notes

This package is intended to be production-oriented and adaptable to:
- Custom GPT workflows
- skill-based agent runtimes
- repository-based orchestration
- dashboard automations

If a runtime supports automation tools, add adapters for:
- Google Sheets
- Gmail
- Calendar
- Figma / Canva
- GitHub

Do not assume these adapters exist unless explicitly enabled.
