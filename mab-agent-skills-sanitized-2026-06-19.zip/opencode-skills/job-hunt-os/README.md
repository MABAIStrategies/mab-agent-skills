# Job Hunt OS Package

Files:
- `SKILL.md` — primary runtime instructions
- `references/` — engine contracts and supporting logic
- `schemas/` — dashboard record schema
- `templates/` — starter artifacts
- `assets/` — reserved for headshot, brand palettes, and source-of-truth profile files
- `scripts/` — reserved for renderers / automation helpers

Recommended next implementation steps:
1. attach a PDF resume renderer
2. attach a PDF cover-letter renderer
3. add current-web research tools
4. add dashboard sheet integration
5. add outreach sequencing adapter
