---
name: resume-optimizer
description: >
  AI-powered resume and cover letter optimizer. Use when a user wants to: tailor a resume
  to a job posting, create a cover letter, run an ATS gap analysis, get a keyword match
  score, optimize a LinkedIn profile, or get interview prep from a JD. Triggers on:
  "optimize my resume", "tailor my resume to", "create a cover letter for", "ATS-friendly
  resume", "resume for [job title]", "what keywords am I missing", "LinkedIn summary",
  "interview questions for this job", or any job application request. Maintains a master
  profile so users submit their resume once and generate unlimited tailored versions.
  Supports job URLs, pasted job descriptions, or target role/title inputs. Delivers:
  designed resume PDF, cover letter PDF, plain-text ATS version, before/after ATS match
  score, keyword gap table, LinkedIn headline and About section, and interview prep.
---

# Resume & Cover Letter Optimizer Skill — v2

## What This Skill Does

Transforms a user's existing resume into an unlimited number of beautifully designed,
strategically ATS-optimized, role-specific resume + cover letter pairs — AND delivers a
full intelligence package: ATS match score (before/after), keyword gap table, tailoring
transparency report, LinkedIn optimization, and likely interview questions.

The user submits their master resume **once**. Every subsequent request only needs a job
URL, pasted job description, or target role name.

---

## ⚠️ MANDATORY RULES — NEVER SKIP, NEVER REORDER

### RULE 1 — Headshot
Every resume PDF **must** include the user's professional headshot located at:
`/mnt/skills/user/resume-optimizer/assets/headshot.png`

Copy it to the working directory at the start of every generation run:
```bash
mkdir -p /home/claude/resume-optimizer-skill/assets
cp /mnt/skills/user/resume-optimizer/assets/headshot.png \
   /home/claude/resume-optimizer-skill/assets/headshot.png
```

If the file is missing from the skill bundle, check `/mnt/user-data/uploads/` for any
image file. If no headshot can be located: **stop and ask the user to provide one.**
Never generate a resume without the headshot.

### RULE 2 — Smart Brand Color Logic

Before selecting colors, determine the **submission method**:

| Submission Method | Color Strategy |
|---|---|
| Applying via ATS portal (Workday, Greenhouse, Lever, iCIMS, Taleo) | Use industry-default scheme — brand colors are irrelevant; ATS strips design |
| Applying directly (email to HM, hiring manager referral, warm outreach) | Research company brand colors and apply them |
| Unknown / generic role title | Use industry-default scheme |

**Only when direct submission is confirmed:**
1. Use `web_search` to find the company's official brand colors or homepage.
2. Use `web_fetch` to extract their primary/secondary hex values.
3. Apply those exact brand colors as the resume's PRIMARY/SECONDARY.
4. If extraction fails, fall back to industry defaults (see Phase 5).

### RULE 3 — Always Produce Pre/Post ATS Score
Before generating any PDF, run Phase 3 (Gap Analysis) and display the scores in chat.
Never skip to design without showing the user their match score and keyword gaps first.

### RULE 4 — Master Profile Session Handling
`/home/claude/` resets between conversations. **Always check for the profile file at
session start.** If it doesn't exist, trigger Phase 1. Instruct users to save their
profile JSON externally and paste it back if they want continuity across sessions, OR
ask them to re-upload their resume at the start of each new conversation.

---

## Workflow Overview

```
SESSION START
     │
     ▼
[Phase 0]  Check for master_profile.json
     │
     ├── Found ──────────────────────────────────────────┐
     │                                                    │
     └── Missing → [Phase 1] Build Master Profile ───────┤
                                                          ▼
                                                [Phase 2]  Analyze Job Target
                                                          │
                                                          ▼
                                                [Phase 3]  ATS Gap Analysis
                                                          │ (show score + gaps in chat)
                                                          ▼
                                                [Phase 4]  Optimize Content
                                                          │ (build optimized_content dict)
                                                          ▼
                                                [Phase 5]  Generate PDFs + Plain Text
                                                          │
                                                          ▼
                                                [Phase 6]  Deliver Intelligence Package
```

---

## Phase 0: Session Initialization

On every invocation:

```python
import os, json

PROFILE_PATH = '/home/claude/resume-optimizer-skill/assets/master_profile.json'

if os.path.exists(PROFILE_PATH):
    with open(PROFILE_PATH) as f:
        master_profile = json.load(f)
    # Silently loaded — proceed to Phase 2
else:
    # Trigger Phase 1
    print("No profile found. Please provide your resume to get started.")
```

If a profile is loaded, silently confirm in chat:
> "✓ Profile loaded for **[Name]** — [N] roles, [X] years experience."

---

## Phase 1: Master Profile Capture

**Trigger:** No profile on disk, OR user says "update my resume" / "start fresh."

### Accepted Input Formats
- Upload `.docx`, `.pdf`, or `.txt`
- Paste resume text directly
- Describe background verbally (Claude will interview to fill gaps)

### Step 1: Extract Master Profile

Parse all resume content into this exact JSON structure:

```json
{
  "personal": {
    "name": "",
    "email": "",
    "phone": "",
    "location": "",
    "linkedin": "",
    "website": "",
    "tagline": ""
  },
  "summary": "",
  "experience": [
    {
      "title": "",
      "company": "",
      "dates": "",
      "location": "",
      "bullets": [],
      "raw_impact": [],
      "industry": ""
    }
  ],
  "education": [
    {
      "degree": "",
      "institution": "",
      "year": "",
      "honors": ""
    }
  ],
  "skills": {
    "technical": [],
    "soft": [],
    "tools": [],
    "certifications": [],
    "languages": []
  },
  "achievements": [],
  "keywords_bank": [],
  "career_level": "entry | mid | senior | director | executive",
  "primary_industry": "",
  "photo_path": "/home/claude/resume-optimizer-skill/assets/headshot.png",
  "date_gaps": [],
  "linkedin_headline": "",
  "linkedin_about": ""
}
```

### Step 2: Identify Career Level
Auto-detect from years of experience and title history:
- < 3 years → `entry`
- 3–8 years → `mid`
- 8–15 years → `senior`
- 15+ years or VP/Director titles → `director` or `executive`

### Step 3: Flag Date Gaps
Identify any employment gaps > 3 months. Flag them in `date_gaps` array with:
```json
{ "start": "YYYY-MM", "end": "YYYY-MM", "duration_months": N }
```
These will be surfaced in the Red Flags section of Phase 3.

### Step 4: Save & Confirm
Save to `PROFILE_PATH`. Show user:

```
✅ Master profile built for [Name]
   Roles detected: [N]
   Career level: [level]
   Top skills: [skill 1], [skill 2], [skill 3]
   Date gaps flagged: [N] (we'll address these in tailoring)

Ready to optimize. Give me a job URL, paste a job description, or name a target role.
```

---

## Phase 2: Job Target Analysis

### Input Methods

| Method | Instructions |
|---|---|
| **URL** | `web_fetch` the full job posting. If blocked, ask user to paste the JD. |
| **Paste** | Parse the provided text directly. |
| **Title only** | Ask for target industry/company. Use `web_search` to build a composite requirement profile. |

### Extract This From Every Job Posting:

```json
{
  "job_title": "",
  "company": "",
  "industry": "",
  "location": "",
  "remote_policy": "onsite | hybrid | remote",
  "seniority_level": "",
  "required_skills": [],
  "preferred_skills": [],
  "key_responsibilities": [],
  "culture_signals": [],
  "ats_keywords": [],
  "years_experience_required": 0,
  "reports_to": "",
  "team_size": "",
  "ats_platform": "",
  "application_method": "ats_portal | direct | referral | unknown",
  "req_number": "",
  "hiring_manager": ""
}
```

### ATS Platform Detection

Identify the ATS from the URL or job board domain:

| URL Pattern / Signal | ATS Platform |
|---|---|
| `myworkdayjobs.com`, `wd1.myworkdayjobs.com` | Workday |
| `greenhouse.io`, `boards.greenhouse.io` | Greenhouse |
| `lever.co`, `jobs.lever.co` | Lever |
| `icims.com` | iCIMS |
| `taleo.net` | Taleo |
| `smartrecruiters.com` | SmartRecruiters |
| `jobvite.com` | Jobvite |
| LinkedIn Easy Apply | LinkedIn (PDF + parsed) |
| Company careers page (no known ATS) | Unknown |

Apply ATS-platform-specific format rules from `references/ats-strategy.md`.

### Company Intelligence Research (for cover letter personalization)

When a specific company is named, run a quick intel sweep:

```
web_search: "[Company Name] news 2024 2025"
web_search: "[Company Name] funding | acquisition | product launch"
web_search: "[Company Name] [department] hiring growth"
```

Extract: recent milestones, growth signals, strategic priorities. Use these in the cover
letter opening hook and the "why this company" paragraph.

---

## Phase 3: ATS Gap Analysis (ALWAYS SHOW BEFORE GENERATING PDFs)

This phase runs silently and then **displays a structured report in chat** before any
PDF is generated. It is the competitive differentiator — it's what Chrome extension tools
charge for.

### Step 1: Calculate Pre-Optimization Match Score

Compare master_profile keywords_bank against job's `ats_keywords` + `required_skills`:

```
MATCH SCORE = (keywords_matched / total_keywords_in_jd) × 100
```

Display as: **Current Match: 47%** (or whatever the score is)

### Step 2: Build Keyword Gap Table

Identify all JD keywords NOT currently in the master profile. Categorize and rank:

| Priority | Missing Keyword | Category | Where to Add |
|---|---|---|---|
| 🔴 Critical | [exact JD term] | Required Skill | Summary + Skills section + Bullet |
| 🟡 High | [exact JD term] | Preferred Skill | Skills section + 1 bullet |
| 🟢 Nice-to-Have | [exact JD term] | Culture signal | Summary or cover letter |

**Display this table in chat.** Do not hide it inside a PDF.

### Step 3: Red Flag Identification

Surface any risks that could auto-reject the resume:

| Flag | Severity | Detail |
|---|---|---|
| Title mismatch | 🔴 | User's title "[X]" vs JD target "[Y]" — address in summary |
| Seniority gap | 🔴 | JD requires [N] years, profile shows [M] |
| Date gap | 🟡 | [Month YYYY – Month YYYY] ([N] months) — consider brief note |
| Missing required cert | 🔴 | JD requires [cert], not in profile |
| Location mismatch | 🟡 | JD is [location], profile shows [different location] |

### Step 4: Show Summary Before Proceeding

```
── ATS Analysis: [Company] — [Role Title] ───────────────────────
Current Match Score:   47%  ████████░░░░░░░░░░░░
Projected After Opt:   83%  ████████████████░░░░

Critical Missing Keywords: [N]   (must add to hit 80%+)
Red Flags Detected:        [N]
Hard Skills Gap:           [list top 2-3]

Proceeding to generate optimized documents...
─────────────────────────────────────────────
```

Then proceed directly to Phase 4. (No need to wait for user confirmation unless red
flags are severe — in that case, note the flags and ask if they want to proceed.)

---

## Phase 4: ATS Content Optimization

Read the full reference guide: `references/ats-strategy.md`

Build the `optimized_content` dict that gets passed to the PDF generator:

```python
optimized_content = {
    "target_role": str,           # Exact JD title
    "summary": str,               # 3-sentence tailored summary
    "skills": {
        "technical": list[str],   # Mirror JD exact terms
        "tools": list[str],
        "certifications": list[str],
        "core_competencies": list[str]  # 6-8 keyword-loaded phrases
    },
    "experience": [
        {
            "title": str,
            "company": str,
            "dates": str,
            "location": str,
            "bullets": list[str], # Optimized, quantified, verb-first
        }
    ],
    "education": list[dict],
    "cover_letter": {
        "paragraphs": list[str],  # 4 paragraphs
        "closing": str
    },
    "linkedin": {
        "headline": str,          # ≤120 chars, keyword-rich
        "about": str,             # 3-paragraph About section
        "featured_bullets": list[str]  # Top 3 role bullet rewrites
    },
    "interview_prep": list[dict], # 5 Q&A pairs
    "changes_log": list[dict]     # Tailoring transparency
}
```

### Summary Formula
```
[Target Title mirror] with [X]+ years [core activity] in [industry context].
[Skill 1], [Skill 2], and [Skill 3] with a track record of [quantified achievement].
Seeking to bring [specific value] to [Company]'s [team/mission/goal].
```

### Bullet Optimization Rules
1. **Verb-first, JD-language-first**: Mirror the JD's exact action verbs
2. **STAR-Q method**: Situation (scope) + Task + Action + Result + Quantifier
3. **Relevance ranking**: Reorder bullets — most JD-relevant first
4. **Numbers over adjectives**: Always prefer `$2.4M` over `significant revenue`
5. **Active tense**: "Managed" not "Responsible for managing"
6. **Length discipline**: 1 page < 10 yrs; 2 pages max for senior; never over 2

### Cover Letter Formula
- **Para 1 (Hook)**: Company-specific intel from Phase 2 research + why THIS role
  - NOT: "I am writing to apply for..."
  - YES: "[Company] just [recent milestone] — that's the kind of [growth/mission] I want to contribute to. With [X] years of [core skill], I'm ready to [specific contribution]."
- **Para 2 (Proof)**: 2-3 specific achievements tied to JD requirements
- **Para 3 (Company Fit)**: Show you understand their industry challenge/mission
- **Para 4 (Close)**: Confident, specific, clear call to action

### LinkedIn Optimization
Generate three LinkedIn-optimized outputs:
1. **Headline** (≤120 chars): `[Target Title] | [Top Skill] | [Differentiator]`
2. **About Section** (3 short paragraphs): keyword-rich, first-person, ATS-aware
3. **Top 3 Role Bullets**: Rewrites of the most important experience bullets for LinkedIn

### Interview Question Preview
Generate 5 likely interview questions based on the JD requirements:

```json
[
  {
    "question": "Tell me about a time you [JD requirement]...",
    "why_asked": "JD flags [X] as required — expect behavioral Q on this",
    "suggested_answer_hook": "[Relevant experience from profile to reference]"
  }
]
```

### Tailoring Transparency Log
Build a changes log to show the user what was optimized:

```json
[
  {
    "section": "Summary",
    "change_type": "Rewrite",
    "original": "Results-driven professional with 10+ years...",
    "optimized": "Enterprise Sales Manager with 15+ years...",
    "reason": "Mirrored JD title; added 'enterprise' qualifier; removed generic opener"
  }
]
```

---

## Phase 5: Design Generation

Read the full design reference: `references/design-templates.md`
Copy script: `scripts/pdf_generator.py` → `/home/claude/resume-optimizer-skill/scripts/`

### Install Dependencies (run once per session)
```bash
# bash
pip install reportlab pypdf --break-system-packages --quiet
```

### Color Scheme Selection (Smart Logic)

```
IF application_method == "ats_portal":
    → Use industry default (see table below)
ELIF application_method == "direct" OR "referral":
    → Research and apply company brand colors
ELSE:
    → Use industry default
```

**Industry Defaults:**
| Industry | Scheme Key |
|---|---|
| Technology / Engineering / Data / Product | `tech_navy` |
| Finance / Banking / Legal / Consulting | `finance_gold` |
| Healthcare / Medical / Clinical | `healthcare_teal` |
| Government / Nonprofit / Education | `government_navy` |
| Sales / Business Dev / Operations | `executive_red` |
| Creative / Marketing / Design | `creative_purple` |

### Layout Selection (Auto-selected by career level + role type)

| Role Type | Career Level | Layout |
|---|---|---|
| Sales / Business Dev / Operations | Any | Power Sidebar (Layout A) |
| Engineering / Data / Product | Any | Tech Clean (Layout C) |
| Any | Director / Executive | Executive Classic (Layout B) |
| Any | Entry | Clean Single Column (Layout C variant) |

### PDF Generation Execution

```python
# bash — run this block
import sys
sys.path.insert(0, '/home/claude/resume-optimizer-skill')

from scripts.pdf_generator import (
    generate_resume, generate_cover_letter, 
    COLOR_SCHEMES, get_scheme_for_industry, sanitize_filename
)
import os

# Set paths
os.makedirs('/mnt/user-data/outputs', exist_ok=True)

# Select scheme
scheme = get_scheme_for_industry(job_data['industry'])
# Override with company brand if applicable:
# scheme['PRIMARY'] = '#HEX1'; scheme['SECONDARY'] = '#HEX2'

# Set names
first = master_profile['personal']['name'].split()[0]
last = master_profile['personal']['name'].split()[-1]
role_safe = sanitize_filename(job_data['job_title'])
base = f"/mnt/user-data/outputs/{first}_{last}_{role_safe}"

# Generate resume
resume_path = generate_resume(
    profile=master_profile,
    job_data=job_data,
    optimized_content=optimized_content,
    scheme=scheme,
    layout='sidebar',   # or 'topbar' or 'header'
    output_path=f"{base}_Resume.pdf"
)

# Generate cover letter
cl_path = generate_cover_letter(
    profile=master_profile,
    job_data=job_data,
    cl_content=optimized_content['cover_letter'],
    scheme=scheme,
    output_path=f"{base}_CoverLetter.pdf"
)
```

### Plain Text ATS Version (Always Generate)

After PDFs are built, always produce a plain-text `.txt` version of the resume for
users who need to paste into online ATS portals:

```python
# Generate plain text version
txt_path = f"{base}_Resume_ATS.txt"
with open(txt_path, 'w') as f:
    p = master_profile['personal']
    f.write(f"{master_profile['personal']['name'].upper()}\n")
    f.write(f"{p.get('email','')} | {p.get('phone','')} | {p.get('location','')}\n")
    if p.get('linkedin'): f.write(f"{p['linkedin']}\n")
    f.write("\n")
    f.write("PROFESSIONAL SUMMARY\n")
    f.write("─" * 60 + "\n")
    f.write(optimized_content['summary'] + "\n\n")
    
    f.write("CORE COMPETENCIES\n")
    f.write("─" * 60 + "\n")
    skills = optimized_content['skills']
    all_skills = skills.get('technical',[]) + skills.get('tools',[]) + skills.get('core_competencies',[])
    f.write(" | ".join(all_skills) + "\n\n")
    
    f.write("PROFESSIONAL EXPERIENCE\n")
    f.write("─" * 60 + "\n")
    for job in optimized_content['experience']:
        f.write(f"{job['title']} — {job['company']}  ({job['dates']})\n")
        if job.get('location'): f.write(f"{job['location']}\n")
        for bullet in job['bullets']:
            f.write(f"• {bullet}\n")
        f.write("\n")
    
    f.write("EDUCATION\n")
    f.write("─" * 60 + "\n")
    for edu in master_profile['education']:
        f.write(f"{edu['degree']} — {edu['institution']}  {edu.get('year','')}\n")
        if edu.get('honors'): f.write(f"{edu['honors']}\n")
```

---

## Phase 6: Output & Delivery

### Present All Files

```python
present_files([resume_path, cl_path, txt_path])
```

### Intelligence Package (Display in Chat)

After file links, always display the full intelligence package:

```
══════════════════════════════════════════════════════
  [FirstName]_[LastName]_[Role] — Application Package
══════════════════════════════════════════════════════

📊 ATS MATCH SCORE
   Before optimization:  47%  ████████░░░░░░░░░░░░
   After optimization:   84%  █████████████████░░░
   Improvement:         +37 points

📁 FILES READY
   ✅ [Name]_[Role]_Resume.pdf       — Designed resume
   ✅ [Name]_[Role]_CoverLetter.pdf  — Cover letter
   ✅ [Name]_[Role]_Resume_ATS.txt   — Plain text for portal copy-paste

🔑 KEYWORDS ADDED ([N] total)
   Critical: [keyword 1], [keyword 2], [keyword 3]
   High:     [keyword 4], [keyword 5]

💼 LINKEDIN UPDATES
   Headline: [generated headline — copy-paste ready]
   
   (Full About section and bullet rewrites available — ask for them)

🎯 LIKELY INTERVIEW QUESTIONS
   1. [Question 1]
   2. [Question 2]
   3. [Question 3]
   (Full prep answers available — ask for them)

⚠️ RED FLAGS ADDRESSED
   [List each flag and how it was handled, or "None detected"]

──────────────────────────────────────────────────────
Options:
  A) Regenerate with different colors or layout
  B) Generate for another role
  C) Get full LinkedIn About section
  D) Get full interview prep (5 Q&As with suggested answers)
  E) Build a resume repository (multiple roles at once)
  F) Export tailoring transparency report
```

---

## Phase 7: Repository Mode (Batch Generation)

**Trigger:** "Build me a repository" / "Generate for multiple roles" / list of roles provided.

1. Ask for a list of target roles/companies if not provided.
2. For each role, run Phases 2–6 sequentially.
3. Skip Phase 3 display between roles (show a progress indicator instead).
4. Organize all outputs:

```
[Name]_Resume_Repository/
├── [Role1]/
│   ├── [Name]_[Role1]_Resume.pdf
│   ├── [Name]_[Role1]_CoverLetter.pdf
│   └── [Name]_[Role1]_Resume_ATS.txt
├── [Role2]/
│   └── ...
└── ATS_Scores_Summary.txt
```

5. Create a summary text file showing ATS match scores for all roles.
6. Zip the folder and present for download.

---

## Phase 8: Profile Updates

**Trigger:** "Update my resume", "I got a new cert", "Add my new job", "Update my photo"

Handle partial updates without re-running the full Phase 1:

```
"Add AWS Certified Cloud Practitioner"
→ Append to profile['skills']['certifications']

"I moved to a new job as [title] at [company]"
→ Prepend new role to profile['experience']

"My phone changed to [number]"
→ Update profile['personal']['phone']

"Update my photo" + file attachment
→ Copy new image to assets/headshot.png; update profile['photo_path']

"Add my LinkedIn: linkedin.com/in/[handle]"
→ Update profile['personal']['linkedin']
```

Always confirm the update and re-save the profile.

---

## Error Handling

| Situation | Action |
|---|---|
| No headshot found | Check skill bundle → check uploads → ask user; never proceed without it |
| URL unreachable / blocked | Ask user to paste the JD text |
| Resume too sparse (< 3 bullets per role) | Ask targeted questions to fill gaps before scoring |
| No master profile on file | Trigger Phase 1; remind user profile resets each session |
| reportlab / pypdf not installed | Run `pip install reportlab pypdf --break-system-packages` |
| PDF generation error (font/image issue) | Catch exception, log it, attempt fallback without photo |
| Web search fails | Proceed with training knowledge; note estimation in output |
| Company brand colors unavailable | Fall back to industry defaults; do not block generation |
| ATS platform undetected | Set `application_method = "unknown"` and use industry scheme |
| Date gaps in profile | Surface in Red Flags table; never hide from user |

---

## File & Path Reference

| Asset | Path |
|---|---|
| Headshot source | `/mnt/skills/user/resume-optimizer/assets/headshot.png` |
| Headshot working copy | `/home/claude/resume-optimizer-skill/assets/headshot.png` |
| Master profile | `/home/claude/resume-optimizer-skill/assets/master_profile.json` |
| PDF generator script | `/mnt/skills/user/resume-optimizer/scripts/pdf_generator.py` |
| ATS strategy reference | `/mnt/skills/user/resume-optimizer/references/ats-strategy.md` |
| Design templates reference | `/mnt/skills/user/resume-optimizer/references/design-templates.md` |
| All outputs | `/mnt/user-data/outputs/` |

---

## Quick Reference: Conversation Triggers

The skill handles all of these naturally:

- `"Optimize my resume for Senior Product Manager at Stripe"`
- `"Here's a job URL: [url] — tailor my resume to it"`
- `"I want to apply to this: [paste JD]"`
- `"What keywords am I missing for this role?"`
- `"Make me 5 different resume versions for different sales roles"`
- `"Update my resume to target Director-level positions"`
- `"ATS-friendly resume for tech companies"`
- `"Create a cover letter for [company] [role]"`
- `"Optimize my LinkedIn headline and About section"`
- `"What interview questions should I prep for this job?"`
- `"I got a new certification — add it to my profile"`
- `"Build me a full application repository"`
- `"Show me what changed between my original and optimized resume"`

---

## Dependencies

- Python: `reportlab`, `pypdf`
- Install: `pip install reportlab pypdf --break-system-packages`
- Tools: `web_fetch`, `web_search`
- Scripts: `scripts/pdf_generator.py` (full PDF generation engine)
- References: `references/ats-strategy.md`, `references/design-templates.md`
