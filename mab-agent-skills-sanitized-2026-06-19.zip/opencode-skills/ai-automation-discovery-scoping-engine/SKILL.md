---
name: ai-automation-discovery-scoping-engine
description: |
  Systematic framework for identifying automation opportunities and creating detailed implementation scopes for AI projects. Evaluates processes through time savings, error reduction, scalability, and employee satisfaction. Produces actionable project charters with clear success metrics and realistic timelines. Provides process analysis for automation candidates, ROI calculation frameworks, technical feasibility assessment, tool selection recommendations, implementation scope documents, and change management planning. Use for opportunity identification, SOW creation, ROI business cases, and project documentation.
---
