---
name: mab-strategy-intelligence-vault
description: |
  MAB AI Strategies' self-learning intelligence accumulation system. Logs every strategy engine output to a structured Google Sheets database, surfaces patterns across accumulated work, builds vertical-specific trend intelligence, and generates dashboards for monitoring market signals. Triggers when the user says any of: "log this strategy", "add to vault", "track this", "save to intelligence vault", "what trends are we seeing in [vertical]", "show me the intelligence dashboard", "predictive analysis for [industry]", or any request to analyze accumulated MAB strategy data. Also triggers automatically as the recommended follow-up step after every mab-vertical-strategy-engine run. This skill is the difference between executing one strategy at a time and building a learning system that compounds intelligence with every engagement.
---

# MAB Strategy Intelligence Vault
## The Compounding Intelligence System

> Every strategy run is a data point. Every data point sharpens the next strategy. The vault turns one-off engagements into a learning system that becomes more valuable with every use.

---

## DESIGN PRINCIPLE

A strategy delivered without being captured is a strategy half-used. The first time MAB analyzes the HVAC vertical, it's research. The fifth time, with proper logging, it's pattern recognition. The twentieth time it's a predictive system that can tell you which pain points to lead with before the discovery call even happens.

The vault is not documentation. It is the substrate from which MAB's competitive moat grows.

---

## SYSTEM ARCHITECTURE

The vault lives in Google Workspace, organized as a layered intelligence system:

```
Master Spreadsheet: "MAB Strategy Vault — Master Log"
├─ Tab 1: All Strategies Log (every run, all fields)
├─ Tab 2: Pain Point Catalog (extracted, deduplicated)
├─ Tab 3: Automation Recommendations Catalog
├─ Tab 4: ROI Reference Table (estimated vs. actual when known)
├─ Tab 5: Outcomes Tracker (won/lost/in-progress)
└─ Tab 6: Geographic Heat Map Data

Industry Workbooks (one per vertical):
├─ HVAC Strategy Vault.xlsx
├─ Healthcare Strategy Vault.xlsx
├─ Legal Strategy Vault.xlsx
└─ [Created dynamically as new verticals enter the system]

Each Industry Workbook contains:
├─ Strategies (all engagements in this vertical)
├─ Common Pain Points (frequency-ranked)
├─ Successful Angles (what closed deals)
├─ Failed Angles (what didn't resonate)
├─ Average Financial Profile (revenue, margin, waste estimates)
└─ Predictive Flags (emerging patterns worth watching)

Dashboard Spreadsheet: "MAB Intelligence Dashboard"
├─ Cross-vertical trends
├─ Win rate analysis
├─ Geographic opportunity map
├─ Trend velocity indicators
└─ Predictive alerts
```

---

## STEP 1: CAPTURE PROTOCOL (every strategy)

After every strategy engine run, capture these data points to the master log:

```
REQUIRED FIELDS:
├─ run_date: [ISO date]
├─ run_id: [Unique identifier — UUID or sequential]
├─ input_type: [industry | company | geographic | trend | promotion]
├─ input_value: [The actual user input]
├─ vertical: [Industry classification]
├─ sub_segment: [More specific tier within vertical]
├─ company_size: [SMB | mid-market | enterprise]
├─ geographic_focus: [State/region/city]
├─ relationship_type: [insider | warm | cold | prospect]
├─ top_3_pain_points: [Comma-separated, extracted from strategy]
├─ top_5_automations: [Comma-separated, extracted from strategy]
├─ phase_priorities: [Sequence chosen, e.g., "1,2,3,5,4"]
├─ estimated_annual_benefit: [Dollar value from financial model]
├─ estimated_investment: [Dollar value from financial model]
├─ projected_roi_pct: [Percentage]
├─ projected_payback_weeks: [Number]
├─ unique_insights: [What did this strategy reveal that's novel?]
├─ outcome: [pending | won | lost | abandoned | in-progress]
├─ outcome_date: [Updated when status changes]
├─ actual_results: [Populated post-implementation if applicable]
└─ notes: [Free-form observations]
```

**Logging trigger workflow:**

1. After strategy engine completes, ask user: "Log to intelligence vault? (Y/n)"
2. If yes, extract above fields from strategy output
3. Use `Google Drive` MCP to append row to master spreadsheet
4. If applicable, also append to industry-specific workbook
5. Confirm to user: "Logged. This is your [Nth] strategy in the vault, [Mth] in this vertical."

If Google Drive MCP unavailable, generate a structured markdown record the user can copy-paste manually into Sheets, OR generate Apps Script that pre-populates the row when run from the Sheet itself.

---

## STEP 2: PATTERN EXTRACTION (continuous)

Every fifth strategy run, perform pattern analysis:

```
Pain Point Frequency Analysis:
├─ Across all strategies in [vertical]
├─ Rank top 10 pain points by frequency
├─ Calculate frequency velocity (rising? declining?)
└─ Surface to dashboard

Automation Recommendation Patterns:
├─ Which automations are recommended most often?
├─ Which combinations cluster together?
├─ Are certain automations gateway recommendations 
   (always followed by another)?

Geographic Concentration:
├─ Where is MAB seeing the most activity?
├─ Are certain pain points geographically clustered?
└─ Where are the white spaces (no strategy yet)?

Financial Pattern Recognition:
├─ Average annual benefit by vertical/size
├─ Average investment by vertical/size
├─ Variance — where are the outliers?
└─ Most common ROI ranges (this becomes credibility ammo)
```

---

## STEP 3: PREDICTIVE LAYER (after 25+ strategies in vault)

Once the vault contains sufficient data, surface predictive insights proactively:

**Pattern-based prompts:**
```
"Based on 28 prior HVAC strategies, this profile (mid-market, 
NE region, paper-based) typically has these 3 pain points 
in this order. Consider leading discovery with these specific 
questions..."

"Strategies for [vertical] with annual revenue under $5M show 
a 73% win rate when leading with Phase 1 (billing). Above 
$10M, leading with Phase 3 (scheduling) has a 82% win rate. 
This prospect is $8M — borderline. Recommend [specific approach]."

"You've now generated 5 strategies in [region]. Three identified 
the same regulatory inflection point. This is becoming a thesis, 
not a coincidence. Consider [productization opportunity]."
```

**Predictive alerts:**
```
"Three strategies in the past 30 days mentioned [emerging trend]. 
Recommend creating a thought leadership piece OR pre-built 
strategy template for this trend before the fourth client asks."

"This vertical is showing 4x growth in MAB inquiry rate over 
prior 90 days. Consider productization — there's enough demand 
to justify standardized offering."

"This client profile matches 87% with [prior won deal]. 
Reference that case study in proposal. Specific elements that 
resonated: [list extracted from outcomes data]."
```

---

## STEP 4: DASHBOARD ARCHITECTURE

The dashboard is the visible payoff of the logging discipline. Build it in Google Sheets with native pivot tables and charts, OR connect to Looker Studio for richer visualization.

See `references/03-dashboard-design.md` for full dashboard layout specifications.

**Core dashboard views (always available):**

```
View 1: PORTFOLIO OVERVIEW
├─ Total strategies generated (all-time, YTD, MTD)
├─ Strategies by outcome (won/lost/in-progress visualization)
├─ Cumulative pipeline value (sum of estimated annual benefits)
└─ Win rate trend (rolling 90-day)

View 2: VERTICAL INTELLIGENCE
├─ Filter: Select vertical
├─ Pain point frequency chart
├─ Automation recommendation distribution
├─ Average ROI for this vertical
└─ Geographic distribution within vertical

View 3: GEOGRAPHIC INTELLIGENCE
├─ Heat map of strategy density by state/region
├─ Win rate by geography
├─ Untapped markets (high opportunity, no presence)
└─ Geographic-vertical matrix (where opportunity intersects)

View 4: TREND VELOCITY
├─ Pain points trending up vs. down
├─ New themes emerging (mentioned in last 30 days but not before)
├─ Theme aging (declining mention rate)
└─ Seasonality pattern detection

View 5: PREDICTIVE ALERTS
├─ Pattern-based recommendations
├─ Outlier detection (this strategy doesn't match the pattern — why?)
└─ Productization signals (vertical reaching critical mass)

View 6: PROOF POINT LIBRARY
├─ Quotable statistics ("we've analyzed X strategies in this vertical...")
├─ Average financial impacts (becomes proposal credibility)
└─ Case study cross-references (which won deals support which claims)
```

---

## STEP 5: CONNECTING TO STRATEGY ENGINE

The vault and the strategy engine should be deeply integrated:

**Pre-strategy:** Strategy engine queries vault before generating
```
"Mark, you've done 3 prior strategies in this vertical. Should I 
load those as additional context, or run this one independently?"
```

**Post-strategy:** Strategy engine offers automatic logging
```
"Strategy delivered. Log to intelligence vault? Detected fields:
[shows pre-populated row]
Confirm or edit before saving."
```

**During strategy:** Strategy engine pulls vault statistics for credibility
```
Instead of "industry estimates suggest 8-15% billing leakage..."
The strategy can say "across 12 prior MAB engagements in this 
vertical, average billing leakage was 11.3%."

That's not just better data. That's defensible claim infrastructure.
```

---

## STEP 6: OUTCOME TRACKING — THE FEEDBACK LOOP

The vault becomes most powerful when outcomes are tracked back to strategies:

```
30 days post-strategy:
└─ Update outcome field (won/lost/abandoned/in-progress)

90 days post-implementation:
└─ Capture actual results vs. projected
└─ Note any surprising findings

Annual review:
└─ Calculate accuracy of MAB's predictions across vault
└─ Identify systematic biases (where MAB consistently 
   over- or under-estimates)
└─ Recalibrate financial models based on actual data
```

This is what transforms MAB from "strategy generator" to "predictive engine with track record." The track record becomes the moat.

---

## TRIGGER PROTOCOL

This skill activates on any of these signals:

```
DIRECT TRIGGERS:
├─ "log this strategy" / "log this to the vault"
├─ "add to intelligence vault"
├─ "track this engagement"
├─ "save this to vault"

ANALYSIS TRIGGERS:
├─ "what trends are we seeing in [vertical]"
├─ "show me intelligence on [industry/region]"
├─ "predictive analysis for [target]"
├─ "what does the vault know about [topic]"
├─ "pattern analysis"

DASHBOARD TRIGGERS:
├─ "show intelligence dashboard"
├─ "vault dashboard"
├─ "MAB analytics"
├─ "win rate analysis"

AUTOMATIC TRIGGERS:
├─ Following any mab-vertical-strategy-engine completion 
   (offers logging as the natural next step)
├─ When user mentions a vertical MAB has prior data on 
   (offers prior intelligence as context)
```

---

## REFERENCE FILES

```
references/01-logging-protocol.md     → Field definitions, capture rules
references/02-data-architecture.md    → Sheet schemas, formulas, validation
references/03-dashboard-design.md     → Visual specifications, chart types
references/04-trend-extraction.md     → How to surface patterns programmatically
references/05-predictive-layer.md     → When and how to generate forecasts
assets/master-log-schema.md           → Copy-paste column headers for setup
assets/apps-script-templates.md       → Apps Script for automation
```

---

## QUALITY GATES

Before any logging operation:

- [ ] All required fields populated (no nulls in critical columns)
- [ ] Industry classification validated against existing taxonomy
- [ ] Financial figures sanity-checked (no obvious typos)
- [ ] Outcome field set to "pending" if unknown (not blank)
- [ ] Notes field captures any context that future analysis would need

Before any pattern report:
- [ ] Sample size sufficient (minimum 5 entries per pattern claim)
- [ ] Confidence level stated explicitly when making predictions
- [ ] Distinction between "observed pattern" and "statistical significance"
- [ ] No claim made that the data doesn't support
