# Sequence Library — 12 Tracks by ICP Type

Each track is a 5-touch sequence. Hooks, value beats, and asks are slotted at runtime by the Write agent. The skeleton below shows structure and intent, not the literal copy.

---

## Track 1: VP Operations / Mid-Market SaaS (50–500 employees)

**Pain anchor:** Ops team drowning in manual workflow stitching across 8+ tools.
**Value beat:** "Built a workflow audit framework for 6 ops teams in [their stage]. Average finding: 14 hrs/week per ops hire recoverable inside 30 days."

**E1 — Hook + value beat + soft ask**
- Subject: `[hook keyword] — quick read`
- Body: 70 words. Hook → one-line value beat → "worth 15 min if [signal]"

**L2 — Connect with note**
- "Sent you a note last week — connecting in case the inbox swallowed it."

**E3 — Pattern interrupt with story**
- Subject: `the part [competitor] missed`
- Body: A specific story from a similar customer. No pitch. Ends with: "That's the kind of thing we'd dig into. Worth a look?"

**L4 — Direct value-add**
- DM with a free resource (audit checklist, ROI calculator) — no ask, no link to book.

**E5 — Permission close**
- Subject: `closing the loop`
- Body: Three options (1/2/3 — open / closed / move me to next quarter).

---

## Track 2: COO / Logistics & Supply Chain (200–2,000 employees)

**Pain anchor:** Forecasting and dispatch automation, especially routing exceptions.
**Value beat:** "We rebuilt [client]'s exception-handling agent in 18 days. 31% reduction in dispatcher-touched exceptions."

Same 5-touch shape as Track 1. Hook variations focus on exception handling, route optimization, and integration with TMS/WMS.

---

## Track 3: Director RevOps / B2B SaaS Series B–D

**Pain anchor:** Pipeline hygiene, forecast accuracy, rep activity instrumentation.
**Value beat:** Forecast variance reduced from ±18% to ±6% in one quarter via custom Salesforce + Claude pipeline-coaching loop.

---

## Track 4: VP Engineering / B2B Tech (engineering automation buyer)

**Pain anchor:** Internal tooling fragmentation, on-call ops burden, ticket triage.
**Value beat:** Built triage agent that reduced p2 escalations 41% across 90 days at [client].

---

## Track 5: VP Customer Success / SaaS Mid-Market

**Pain anchor:** CSM workload, churn signal latency, QBR prep cost.
**Value beat:** Churn-signal detector flags accounts 28 days earlier than legacy NPS-driven model.

---

## Track 6: CFO / Mid-Market Services Firms

**Pain anchor:** Month-end close, AR aging, expense classification.
**Value beat:** Close cycle compressed from 11 days → 5 days at [client] via custom Claude + Excel agent loop.

---

## Track 7: VP Sales / Mid-Market Industrial

**Pain anchor:** Quote turnaround time, rep ramp time, CRM data hygiene.
**Value beat:** Quote turnaround compressed from 4 days → 8 hours at [client]; 22% increase in quote-to-order conversion.

---

## Track 8: Head of People / 200–1,000 employee orgs

**Pain anchor:** Hiring loop coordination, candidate experience, headcount planning.
**Value beat:** Hiring coordination agent recovered 11 hrs/week per recruiter at [client].

---

## Track 9: Director IT / Mid-Market Healthcare-adjacent (NOT clinical)

**Pain anchor:** Help desk volume, software provisioning, license cleanup.
**Value beat:** Help desk ticket auto-resolution rate moved from 12% → 38% at [client] in 60 days.

(Reminder: MAB targets all industries — but Mark's protected-employer firewall + the protected legal matter mean: do not target protected-employer current/former enterprise customers, ever.)

---

## Track 10: VP Marketing / B2B SaaS Series A–C

**Pain anchor:** Content production cost, attribution, MQL quality.
**Value beat:** Content engine produced 18 long-form pieces in Q1 with 3 hrs/week from the marketing team at [client].

---

## Track 11: Founder / 50–200 employee firms (founder-led sales)

**Pain anchor:** Founder still doing too much sales work, can't hire fast enough.
**Value beat:** Built founder-mirror agent that handles first-touch qualification + scheduling for [client]; 6 hrs/week recovered.

---

## Track 12: Operator / PE Portfolio Operating Partner

**Pain anchor:** Cross-portfolio ops standardization, value creation plans, 100-day plans.
**Value beat:** Deployed AI ops audit across 4 portfolio companies in 30 days; identified $4.2M annualized savings.

---

## Hook Library (slot at runtime)

Each hook category lives in `hooks/` and is selected by the Personalization Engine based on the contact's signals. Categories:

- `recent_post` — references contact's LinkedIn post
- `funding_round` — references company's recent raise
- `exec_hire` — references recent hire into a relevant role
- `tech_stack_change` — references G2 review or job posting
- `mutual_connection` — references shared 2nd-degree connection
- `event_attendance` — references conference or webinar appearance
- `podcast_quote` — references something contact said publicly
- `company_announcement` — references product launch / press release

Each hook is verifiable. Sources URL must be < 60 days old.

---

## Banned Phrases (instant regeneration)

- "I hope this email finds you well"
- "I wanted to reach out"
- "Touching base"
- "Circling back"
- "Per my last email"
- "Synergy" / "synergies"
- "Disrupt" / "disruptive"
- "Game-changer" / "game-changing"
- "Bandwidth" (when used as a verb)
- "Best regards" / "Kind regards"
- "Sincerely"
- "Pls" / "kindly"
- Any sentence over 28 words
