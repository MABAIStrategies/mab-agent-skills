# Agent Specs — I/O Contracts

Each agent is a single-responsibility process. They communicate via JSONL files in a shared workspace and Postgres for state. No agent reaches into another agent's internal state.

Workspace path: `/var/mab/swarm/<run_id>/`

---

## Hunt Agent

### Inputs
```json
{
  "icp_id": "string",
  "icp_definition": {
    "size_range": ["50-200", "201-500", "501-1000"],
    "industries": ["B2B SaaS", "Logistics"],
    "geographies": ["US", "CA"],
    "tech_signals_required": ["Salesforce"],
    "tech_signals_excluded": ["HubSpot Enterprise"]
  },
  "max_accounts": 1000,
  "exclusions": {
    "existing_customers": "url_to_list",
    "lost_deals_6mo": "url_to_list",
    "competitors": ["..."]
  }
}
```

### Outputs
- File: `accounts.jsonl`
- Each line: an Account object (see SKILL.md)
- Side effect: write `hunt_run` row to Postgres `swarm.runs` with timestamps + counts

### Failure modes
- All sources return < 50 accounts → emit `INSUFFICIENT_HUNT_VOLUME` error, do not proceed
- Score median below 0.60 → emit `LOW_QUALITY_HUNT` warning, hold for ICP review

---

## Signal Agent

### Inputs
- Reads `accounts.jsonl`
- Reads previous `signals_state.json` (for delta detection)

### Outputs
- Updates `accounts.jsonl` in place with `active_signals[]` and `signal_score`
- Emits `signals_delta.jsonl` (new signals since last run only)

### Source modules
Each source is a separate module under `scripts/signal_sources/`:
- `crunchbase_funding.py`
- `linkedin_exec_moves.py`
- `job_postings.py`
- `sec_filings.py`
- `press_releases.py`
- `common_room.py`
- `g2_review_patterns.py`

Each returns: `[{type, detail, date, weight, source_url}]`

---

## Enrich Agent (Personalization)

### Inputs
- Contact ID + LinkedIn URL
- Company domain

### Outputs
- `hook` field: ≤25 words, with `source_url`
- `hook_confidence`: 0.0–1.0

### Hard rules
- No hook → return `null`, do not invent
- Source URL must be live (HEAD request validation)
- If contact's last LinkedIn post is > 90 days old, fall back to company-level signals
- If still nothing, mark contact as "research backlog"

---

## Write Agent (Sequencer)

### Inputs
- Contact + hook + ICP profile + sequence track ID

### Outputs
- 5 message drafts per contact (E1, L2, E3, L4, E5)
- Each draft: `subject`, `body`, `voice_match_score`, `regeneration_count`

### Voice match scoring
A separate Claude call evaluates each draft against the Brand Bible voice rubric:
- No banned phrases (list in `voice_match.py`)
- Em-dash / semicolon ratio in expected range
- Sign-off matches "— Mark"
- Subject line under 50 chars and lowercase
- Hook present and verifiable

Below 0.75 → regenerate (max 3 attempts) → escalate to Mark.

---

## Route Agent

### Inputs
- Approved sequence object
- Sender pool state (per-inbox daily budget remaining)

### Outputs
- Send dispatch records to chosen platform
- Updates `outbound_sends` table

### Routing logic (priority order)
```
if account.score >= 0.85 and account.has_funding_signal:
  use Outreach (multi-thread)
elif account.is_in_apollo_already:
  use Apollo
elif inbox_pool.has_capacity('instantly'):
  use Instantly
else:
  use Smartlead
```

---

## Triage Agent

### Inputs
- Inbound email or LinkedIn message

### Pipeline
1. Strip quoted history (keep only new content)
2. Classifier call (label + confidence)
3. If `interested_book` → calendar autoresponder + NEXUS deal create
4. If `interested_questions` → draft response, send to Mark for approval
5. If `referral` → auto-thread to colleague
6. Log everything to `inbound_triage` Postgres table

### Classifier
- Primary: Claude Haiku via OpenClaw (low latency, cheap)
- Fallback: local Llama 3.1 8B on GMK mini PC
- Always log raw model output + label + confidence for synthesis review

---

## Synthesis Agent

### Inputs
- All `outbound_sends` for the past 7 days
- All `inbound_triage` for the past 7 days
- Previous synthesis reports (for trend lines)

### Outputs
- Friday 7:00 AM ET — full report PDF + Slack DM to Mark
- Decision queue: each sequence with action (`scale|iterate|kill|pause`)
- ICP drift signals from `not_fit` reply patterns

### Cross-skill handoffs
- Booked-call deals → handed to `mab-revenue-pulse` for tracking
- ICP drift signals → fed back to Hunt agent for next run
- Voice-match failures → Brand Bible review trigger
