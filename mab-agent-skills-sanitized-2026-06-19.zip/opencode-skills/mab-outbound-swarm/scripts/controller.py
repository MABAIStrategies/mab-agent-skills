"""
MAB Outbound Swarm — Controller / Policy Gate.

Repo root: /home/claude/mab-outbound-swarm/
CLI: bash / python 3.10+

Single entrypoint for all swarm actions. No agent sends, drafts, or routes
without going through this controller. The controller's job is to enforce
policy — ICP fit, deliverability, voice match, firewalls — and to refuse
fast and loud when any check fails.

Run: python -m scripts.controller dispatch <action> --payload <path>
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)
CONFIG_PATH = Path(__file__).parent / "swarm_config.json"


class RejectReason(str, Enum):
    ICP_FIT_TOO_LOW = "icp_fit_too_low"
    SUPPRESSED = "suppressed"
    NO_INBOX_BUDGET = "no_inbox_budget"
    NO_PERSONALIZATION = "no_personalization"
    VOICE_MATCH_FAIL = "voice_match_fail"
    protected-employer_FIREWALL = "protected-employer_firewall"
    REFLECTION_FIREWALL = "reflection_firewall"
    INSUFFICIENT_HUNT_VOLUME = "insufficient_hunt_volume"
    DELIVERABILITY_PAUSED = "deliverability_paused"


@dataclass
class PolicyResult:
    allowed: bool
    rejections: list[RejectReason]
    notes: list[str]


def load_config() -> dict[str, Any]:
    with CONFIG_PATH.open() as f:
        return json.load(f)


# ─── Policy checks ──────────────────────────────────────────────────────────


def check_icp_fit(account: dict, cfg: dict) -> RejectReason | None:
    threshold = cfg["controller"]["icp_fit_min"]
    if account.get("score", 0.0) < threshold:
        return RejectReason.ICP_FIT_TOO_LOW
    return None


def check_suppression(contact: dict, suppression_set: set[str]) -> RejectReason | None:
    if contact.get("email", "").lower() in suppression_set:
        return RejectReason.SUPPRESSED
    return None


def check_inbox_budget(inbox_id: str, sends_today: int, cfg: dict) -> RejectReason | None:
    cap = cfg["route"]["max_cold_per_inbox_per_day"]
    if sends_today >= cap:
        return RejectReason.NO_INBOX_BUDGET
    return None


def check_personalization(sequence: dict, cfg: dict) -> RejectReason | None:
    contacts = sequence.get("contacts", [])
    if not contacts:
        return RejectReason.NO_PERSONALIZATION
    null_count = sum(1 for c in contacts if not c.get("hook"))
    null_rate = null_count / len(contacts)
    max_rate = cfg["controller"]["personalization_null_rate_max"]
    if null_rate > max_rate:
        return RejectReason.NO_PERSONALIZATION
    return None


def check_voice_match(draft: dict, cfg: dict) -> RejectReason | None:
    score = draft.get("voice_match_score", 0.0)
    if score < cfg["controller"]["voice_match_min"]:
        return RejectReason.VOICE_MATCH_FAIL
    return None


def check_protected-employer_firewall(payload: dict) -> RejectReason | None:
    """Hard refuse anything that touches protected-employer prospect data."""
    serialized = json.dumps(payload).lower()
    flags = ["protected-employer", "vz_business", "protected-employer-protected"]
    if any(flag in serialized for flag in flags):
        return RejectReason.protected-employer_FIREWALL
    return None


def check_reflection_firewall(payload: dict) -> RejectReason | None:
    """Reflection chats are walled off from tactical prospecting."""
    if "reflection" in str(payload.get("source_chat_id", "")).lower():
        return RejectReason.REFLECTION_FIREWALL
    return None


def check_deliverability(inbox_state: dict, cfg: dict) -> RejectReason | None:
    threshold = cfg["controller"]["deliverability_pause_threshold"]
    if inbox_state.get("score", 1.0) < threshold:
        return RejectReason.DELIVERABILITY_PAUSED
    return None


# ─── Dispatchers ─────────────────────────────────────────────────────────────


def evaluate_send(payload: dict, cfg: dict, suppression: set[str],
                  inbox_state: dict, inbox_sends_today: int) -> PolicyResult:
    rejections: list[RejectReason] = []
    notes: list[str] = []

    for fn in [
        lambda: check_protected-employer_firewall(payload),
        lambda: check_reflection_firewall(payload),
        lambda: check_icp_fit(payload.get("account", {}), cfg),
        lambda: check_suppression(payload.get("contact", {}), suppression),
        lambda: check_personalization(payload.get("sequence", {}), cfg),
        lambda: check_voice_match(payload.get("draft", {}), cfg),
        lambda: check_inbox_budget(payload.get("inbox_id", ""), inbox_sends_today, cfg),
        lambda: check_deliverability(inbox_state, cfg),
    ]:
        result = fn()
        if result:
            rejections.append(result)

    allowed = len(rejections) == 0
    if not allowed:
        logger.warning("Send blocked: %s", [r.value for r in rejections])
    return PolicyResult(allowed=allowed, rejections=rejections, notes=notes)


# ─── CLI ─────────────────────────────────────────────────────────────────────


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_dispatch = sub.add_parser("dispatch")
    p_dispatch.add_argument("action", choices=["send", "draft", "hunt", "triage"])
    p_dispatch.add_argument("--payload", required=True, help="Path to JSON payload")
    args = parser.parse_args()

    cfg = load_config()
    payload = json.loads(Path(args.payload).read_text())

    if args.action == "send":
        # Stubs — wire to real state stores
        suppression: set[str] = set()
        inbox_state = {"score": 0.97}
        inbox_sends_today = 0
        result = evaluate_send(payload, cfg, suppression, inbox_state, inbox_sends_today)
        print(json.dumps({
            "allowed": result.allowed,
            "rejections": [r.value for r in result.rejections],
            "notes": result.notes,
        }, indent=2))
    else:
        # Other dispatch types stubbed
        print(json.dumps({"status": "not_implemented", "action": args.action}))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    main()
