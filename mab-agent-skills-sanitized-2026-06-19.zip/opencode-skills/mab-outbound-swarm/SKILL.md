---
name: mab-outbound-swarm
description: Multi-agent outbound prospecting and sequencing engine for MAB AI Strategies. Orchestrates seven agents (ICP Hunter, Trigger Detector, Personalization, Sequencer, Sender Router, Reply Triage, Synthesis) to scrape mid-market accounts, detect buying signals, draft personalized 5-touch cadences in Mark's voice, push to Apollo/Outreach/Instantly, classify replies into NEXUS CRM, and report weekly with kill/scale/iterate decisions. Use aggressively whenever Mark says "outbound", "prospecting", "cold email", "sequences", "lead gen", "top of funnel", "agent swarm", "fill the pipeline", "I need more leads", "pipeline is dry", or "build a prospecting agent". Also trigger on ICP, account scoring, buy signals, intent data, sequence performance, reply rates, deliverability, or scaling outbound activity. Also surface when Mark talks about packaging a managed lead-gen offering for clients at $25K–$75K white-glove deployment — this swarm is the underlying engine.
---

# MAB Outbound Agent Swarm

Seven coordinated agents that turn ICP definitions into booked discovery calls. Designed to be both Mark's internal prospecting machine and a productized white-glove deployment for MAB AI Strategies clients.

## Architecture at a Glance

```
                     ┌─────────────────────┐
                     │  CONTROLLER / GATE  │  ← single entrypoint, policy gate
                     └──────────┬──────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                       │                       │
   ┌────▼────┐            ┌─────▼─────┐           ┌─────▼──────┐
   │  HUNT   │            │  SIGNAL   │           │ ENRICH     │
   │ (ICP)   │            │ (TRIGGER) │           │ (PERSON-A) │
   └────┬────┘            └─────┬─────┘           └─────┬──────┘
        │                       │                       │
        └───────────┬───────────┴───────────┬───────────┘
                    │                       │
              ┌─────▼─────┐           ┌─────▼─────┐
              │  WRITE    │           │  ROUTE    │
              │ (SEQUENCE)│           │ (SENDER)  │
              └─────┬─────┘           └─────┬─────┘
                    │                       │
                    └───────────┬───────────┘
                                │
                          ┌─────▼─────┐
                          │  TRIAGE   │  ← inbound replies → NEXUS CRM
                          └─────┬─────┘
                                │
                          ┌─────▼─────┐
                          │ SYNTHESIS │  ← weekly perf + kill/scale calls
                          └───────────┘
```

Each agent has a single, narrow responsibility. The controller enforces policy (deliverability, ICP fit, voice match) before any send.

---

## Agent 1: ICP Hunter (`hunt`)

**Job:** Build target account lists from ICP definitions.

**Inputs:**
- ICP profile JSON (firmographic + technographic + signal filters)
- Geographic constraints
- Exclusion lists (existing customers, lost deals < 6mo, competitors)

**Sources (priority order):**
1. Apollo.io (via MCP) — primary firmographic
2. ZoomInfo (via MCP) — depth and contacts
3. Common Room — community signal layer
4. Clay — enrichment chains for tricky filters
5. LinkedIn Sales Navigator (via Phantombuster or browser MCP)
6. Manual seed list import (CSV)

**Output:** `accounts.jsonl` — one account per line with at minimum:
```json
{
  "account_id": "uuid",
  "company": "...",
  "domain": "...",
  "size_range": "201-500",
  "industry": "...",
  "hq_geo": "...",
  "tech_signals": ["Salesforce", "Outreach"],
  "score": 0.82,
  "score_components": {...},
  "raw_sources": ["apollo:...", "linkedin:..."]
}
```

**Scoring (0.0–1.0):**
- Firmographic fit (size, industry) × 0.35
- Technographic fit (tools they use) × 0.20
- Geographic fit × 0.10
- Recent signals (funding, hiring, RFPs) × 0.25
- Network warmth (Mark's 1st/2nd degree connections) × 0.10

Reject below 0.55. Send 0.55–0.74 to a "warm-up" tier (LinkedIn engagement before email). Send 0.75+ direct to sequencing.

---

## Agent 2: Trigger Detector (`signal`)

**Job:** Identify buying signals on the target list.

**Triggers monitored:**
- Funding rounds (Crunchbase, PitchBook via API)
- Executive moves into ICP roles (LinkedIn, news)
- Job postings mentioning relevant tools or pain points
- 10-K / 10-Q language shifts (for public targets)
- M&A activity affecting buyer cohort
- Press releases mentioning automation, AI, efficiency, transformation
- Common Room community engagement spikes
- G2 / TrustRadius review patterns (for tools they're switching from)

**Cadence:** Run `signal` daily on top 500 accounts; weekly on the rest.

**Output:** Append to each account in `accounts.jsonl`:
```json
{
  "active_signals": [
    {"type": "exec_hire", "detail": "Hired VP RevOps from [co]", "date": "...", "weight": 0.8},
    {"type": "funding", "detail": "Series B $42M", "date": "...", "weight": 0.7}
  ],
  "signal_score": 0.74,
  "signal_freshness_days": 6
}
```

Promote any account with ≥1 high-weight signal in the last 14 days to the front of the queue.

---

## Agent 3: Personalization Engine (`enrich`)

**Job:** For each contact in the queue, find one specific, true, citeable hook for the cold message.

**Sources:**
- Contact's recent LinkedIn posts (last 30 days)
- Company recent press / blog posts
- Podcast appearances
- Conference talks
- 10-K language for public companies
- Common Room / community engagement
- Mutual connections in Mark's network

**Output:** `hook` field on each contact — under 25 words, with a verifiable source URL.

**Hard rule:** if no specific hook is findable, the contact gets `hook: null` and is sent to a "research backlog" queue, NOT through cold sequencing. Generic openers ("I see you're in [industry]") are forbidden.

Failure mode prevention: the controller rejects any sequence where ≥30% of contacts have `hook: null`.

---

## Agent 4: Sequencer (`write`)

**Job:** Draft 5-touch sequences in Mark's voice, personalized per contact.

**Sequence skeleton:**

| Touch | Channel | Day | Purpose |
|---|---|---|---|
| 1 | Email | 0 | Hook + value beat + soft ask |
| 2 | LinkedIn | +2 | Connect with note referencing email |
| 3 | Email | +5 | Pattern interrupt (specific story or stat) |
| 4 | LinkedIn DM | +9 | Direct value-add (resource, intro, no pitch) |
| 5 | Email | +14 | Permission close ("worth closing the loop?") |

**Voice guardrails (loaded from MAB Brand Bible):**
- Subject lines under 50 chars, lowercase
- No "I hope this email finds you well"
- Em dashes welcome, semicolons rare
- Numbered choices over bullets when offering options
- Sign "— Mark" not "Best regards"
- One specific hook per email, one clear ask, one value beat

**Quality gate:** Each draft is scored by a Voice Match check (0.0–1.0). Below 0.75 is regenerated. Below 0.75 three times is escalated to Mark with the contact flagged for manual write.

**Output:** `sequences.jsonl` — one sequence per contact with all 5 drafts ready to send.

---

## Agent 5: Sender Router (`route`)

**Job:** Push approved sequences to the right sending platform with deliverability protection.

**Sending stack (priority order):**
1. Instantly.ai — for high-volume cold (warmed-up domains)
2. Apollo.io — for accounts already enriched there
3. Outreach.io — for accounts requiring SDR-style multi-thread
4. Smartlead — fallback if primary throttles
5. Manual queue — for accounts requiring Mark's personal send

**Deliverability rules:**
- Max 40 cold sends per inbox per day
- Max 3 cold sends per domain per day (rolling 7-day)
- Pause any inbox dropping below 95% deliverability score
- Rotate across ≥4 warmed inboxes
- Never send Mon < 8am ET or Fri > 4pm ET
- Skip US holidays + recipient-country holidays
- Honor unsubscribe + reply suppression instantly

**Output:** Send confirmations logged to NEXUS CRM `outbound_sends` with timestamp, inbox used, sequence ID, contact ID.

---

## Agent 6: Reply Triage (`triage`)

**Job:** Classify every inbound reply and route appropriately.

**Classification labels:**

| Label | Meaning | Routing |
|---|---|---|
| `interested_book` | Wants a call | Auto-send calendar link, mark deal Discovery |
| `interested_questions` | Asks a question | Draft response for Mark approval |
| `referral` | Punts to colleague | Auto-thread to colleague, mark warm intro |
| `not_now` | Genuine timing | Move to nurture cadence Q+1 |
| `not_fit` | Wrong target | Add to permanent suppression + flag ICP miss |
| `unsubscribe` | Hard no | Suppress immediately |
| `hostile` | Negative | Suppress + log for Mark review |
| `auto_reply` | OOO / bouncer | Hold sequence until OOO end date |
| `bounce` | Bad address | Mark contact invalid + remove |

**Implementation:** Use a fine-tuned classifier (Claude Sonnet via OpenClaw policy gate works well; can fall back to a Llama 3.1 instance on Mark's GMK mini PC for cost-zero operation). Tag confidence on each label. Confidence < 0.85 escalates to Mark.

**Critical rule:** `interested_book` and `interested_questions` create a deal in NEXUS CRM and a Pulse follow-up entry within 60 seconds of detection.

---

## Agent 7: Synthesis (`synthesize`)

**Job:** Weekly performance report and kill / scale / iterate decisions on every sequence.

**Metrics tracked per sequence:**
- Send volume
- Open rate (caveated — Apple MPP makes this lossy)
- Reply rate
- Positive reply rate (`interested_book` + `interested_questions` + `referral`)
- Booked-call rate
- Deliverability stats per inbox
- Time-to-first-reply distribution

**Decision rules:**
- **Scale**: positive reply rate > 4%, booked-call rate > 1.5%, deliverability > 96%
- **Iterate**: positive reply rate 2%–4%, identifiable variable to change
- **Kill**: positive reply rate < 2% after 250 sends, OR negative reply rate > 5%
- **Pause**: deliverability drops below 92% on any inbox

**Output:** Friday morning report in this exact structure:

```
═══════════════════════════════════════
SWARM SYNTHESIS — Week of [Mon DD]
═══════════════════════════════════════

VOLUME
  Sent:        [N] across [I] inboxes
  Replies:     [N] ([X%])
  Positive:    [N] ([Y%])
  Calls Booked:[N] ([Z%])
  Pipeline $:  $[gross], $[weighted]

🟢 SCALE
  [Sequence name] — [reason]
  → Action: [specific action]

🟡 ITERATE
  [Sequence name] — [hypothesis]
  → Action: [specific change]

🔴 KILL
  [Sequence name] — [reason]
  → Action: archive, refund send budget

🚨 DELIVERABILITY
  [Inbox] — [stat] [recommendation]

🎯 ICP DRIFT
  [Pattern observed in `not_fit` replies — adjust ICP filters]
═══════════════════════════════════════
```

The Synthesis report feeds back into Hunt (ICP refinement) and Write (sequence iteration). The swarm gets smarter every week.

---

## Controller / Policy Gate

Single entrypoint. Every action passes through it.

**Policy checks (in order):**
1. ICP fit ≥ 0.55? Else reject.
2. Suppression list clear? Else reject.
3. Deliverability budget available on assigned inbox? Else queue.
4. Personalization hook present? Else hold for enrichment.
5. Voice match score ≥ 0.75? Else regenerate.
6. protected-employer firewall: zero overlap with protected-employer prospect data? Else hard reject.
7. Reflection chat firewall: zero references? Else hard reject.

The controller logs every reject with reason. Synthesis aggregates rejection reasons weekly to identify systemic issues.

---

## Productization Path (Client Deployment)

This swarm is also a productized offering. White-glove deployment for MAB AI Strategies clients in the $25K–$75K range:

| Tier | Price | Scope | Timeline |
|---|---|---|---|
| Starter | $25K | 2 inboxes, 1 ICP, 1 sequence track, 1,000 contacts/mo | 14 days |
| Growth | $45K | 4 inboxes, 3 ICPs, 3 sequence tracks, 5,000 contacts/mo | 21 days |
| Enterprise | $75K | 8+ inboxes, unlimited ICPs, Salesforce integration, custom reply triage, dedicated synthesis | 30 days |

**What Mark delivers:**
- Configured swarm in client's tooling stack
- ICP definition workshop (4 hours)
- Sequence library customized to client voice
- 30-day performance tuning
- Synthesis dashboard + monthly review for first 90 days

**What Mark does NOT deliver:**
- Client's sending domains (they own those)
- Client's CRM seat licenses
- Ongoing daily SDR work (this is a system, not a service)

ROI framing for proposals: "Our last deployment booked 47 qualified meetings in 60 days at $1,490 fully-loaded cost per meeting — vs $4,200 industry benchmark for outsourced SDR."

(Use real numbers when Mark has them. Don't fabricate.)

---

## Reference Files

- `references/agent_specs.md` — Detailed I/O contracts for each agent
- `references/sequence_library.md` — 12 sequence templates by ICP type
- `scripts/controller.py` — Policy gate implementation
- `scripts/swarm_config.json` — All agent thresholds and routing rules

---

## Failure Modes & Refusal Conditions

The swarm will refuse to operate under these conditions:

- ICP definition is missing or scored < 0.55 average across the seed list
- Personalization Engine returns hook: null on > 30% of queue
- Deliverability dashboard shows any inbox < 92%
- Reply Triage classifier confidence < 0.80 on > 20% of inbounds
- protected-employer prospect data detected in any input

In each case, the controller blocks send and emits a structured error to Mark with the remediation step. The swarm should never push bad outbound. Bad outbound burns domains and reputation faster than it generates pipeline.

---

## Integration with mab-revenue-pulse

The swarm's `interested_book` and `interested_questions` outputs create new deals in NEXUS CRM. Those deals are then governed by `mab-revenue-pulse` — they enter the daily stalled-deal detection loop the moment they go silent past threshold.

The swarm fills the top of funnel. The Pulse keeps the middle of funnel from rotting. Run them together or you're optimizing one half of the equation.
