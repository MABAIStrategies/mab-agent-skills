# MAB Agent Skills

This repository stores reusable agentic skills, plugin manifests, and implementation packs for MAB AI Strategies.

## Repository status

Updated from the June 19, 2026 skill ZIP upload.

| Area | Count |
|---|---:|
| Production microservice skills | 2 |
| OpenCode-native skills | 34 |
| ChatGPT / single-file skills | 10 |
| Multi-platform bundles | 2 |
| Plugin packs | 1 |

## Layout

```text
mab-agent-skills/
├── skills/                    # production-oriented service skills
├── opencode-skills/           # OpenCode-compatible skills: <skill>/SKILL.md
├── chatgpt-skills/            # ChatGPT-style .skill files and skill folders
├── multi-platform-bundles/    # Antigravity / Claude / Kimi / Perplexity variants
├── plugins/                   # plugin manifests and bundled plugin workflows
└── docs/                      # ingestion, licensing, and housekeeping notes
```

## Install: OpenCode skills

```bash
mkdir -p ~/.config/opencode/skills
cp -R opencode-skills/* ~/.config/opencode/skills/
```

For project-scoped use:

```bash
mkdir -p .opencode/skills
cp -R opencode-skills/* .opencode/skills/
```

## Install: ChatGPT-style skills

Use the files under `chatgpt-skills/` as source skill definitions. Most are stored as `.skill` files or as folder-based skills with `SKILL.md`, `references/`, and `agents/`.

## Production service skills

The `skills/` directory contains source-oriented service skills with Python handlers/services where present.

## Housekeeping notes

- This repo is public, so private/legal material and sensitive case-specific content were not committed.
- Font binaries and large vendored Office schema bundles were excluded from this commit.
- Third-party license notices are preserved where practical; see `docs/THIRD_PARTY_NOTICES.md`.
- The previous README claimed 10 complete production microservices. The uploaded source set contained two populated production microservice folders plus other reusable skill formats, so the README now reflects the actual committed inventory.

## Primary index

See [`docs/SKILL_INDEX.md`](docs/SKILL_INDEX.md) for the current inventory.
