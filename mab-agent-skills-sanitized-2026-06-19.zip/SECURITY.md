# Security Policy

This repository may contain reusable automation skills, workflow logic, and integration scaffolding.

## Do not commit

- API keys, OAuth tokens, service-account JSON, private certificates, or client data
- Private legal, HR, employment, health, or family records
- Live customer exports or unredacted CRM/prospecting data
- Binary font files or large vendored artifacts unless explicitly approved

## Review checklist

Before merging new skills:

1. Confirm the skill contains no secrets.
2. Confirm public/private boundaries are correct.
3. Preserve third-party license notices.
4. Prefer references to private artifact storage for binaries and large vendored assets.
5. Add each skill to `docs/SKILL_INDEX.md`.
