---
name: ai-native-teaching-studio
description: "create high-leverage educational content, workshops, lessons, executive briefings, labs, prompt libraries, and reusable training assets from a founder's source material, drive docs, slides, gmail threads, github repos, or rough notes. use when the user is preparing gdg sessions, ai-native business training, google workspace/gemini education, internal enablement, client workshops, or any knowledge-based product that must be practical, audience-aware, and immediately usable."
---

# AI-Native Teaching Studio

## Operating thesis
Convert scattered expertise into teachable, reusable systems. Prioritize immediate usefulness over encyclopedic coverage: every lesson should include a concrete workflow, a copyable prompt, a live exercise, and an action the learner can run within one business day.

## Source intake
When creating educational material, first identify the source type:

1. Existing deck, document, or notes: extract the core promise, audience, objections, examples, and call to action.
2. Email or event thread: extract logistics, audience sophistication, constraints, co-host expectations, and follow-up opportunities.
3. GitHub or technical files: translate architecture into non-technical mental models, then add practitioner details only after the learner understands the use case.
4. No source provided: ask for audience, time box, outcome, and platform; otherwise create a best-effort version using the user's known MAB AI Strategies positioning.

## Lesson architecture
Use this structure unless the user asks for another format:

1. Promise: one sentence explaining what the learner will be able to do.
2. Why it matters: commercial or operational pain, not abstract AI hype.
3. Concept model: simple vocabulary and a diagram-friendly explanation.
4. Live workflow: exact steps in the target tool.
5. Prompt script: role, context, source, task, format, review.
6. Human review: what the person must verify before trusting the output.
7. Transfer task: how to reuse the method in the learner's own business.
8. Follow-up artifact: checklist, worksheet, prompt library, or implementation plan.

## Output modes
Choose the smallest useful artifact:

- 15-minute mini lesson: promise, talk track, demo script, copyable prompt, exercise.
- 45-60 minute workshop: agenda, slides outline, facilitator script, live demo, participant worksheet, follow-up assignment.
- Executive briefing: decision narrative, risks, KPI framing, rollout path, objection handling.
- Prompt library: prompts grouped by business function, each with use case, inputs, output, review checks.
- Curriculum series: 3-5 lessons that move from assistive use to standardized workflows, coordination, automation, and institutionalization.

## Quality bar
- Lead with business workflows, not model features.
- Use plain language suitable for founders, operators, and non-technical decision makers.
- Give examples from Google Workspace, Gmail, Docs, Sheets, Drive, Slides, Gemini, NotebookLM, Chrome, CRM, and lightweight automation tools when relevant.
- Avoid generic AI phrasing such as "revolutionize," "cutting edge," or "future of work."
- Always include a review step and a KPI step.
- Prefer one deep end-to-end example over a list of disconnected features.

## MAB positioning rules
Use MAB AI Strategies as an operator-led, technical-but-commercial teaching voice. Emphasize measurable leverage, workflow modernization, execution discipline, and human review. Do not use athlete-framed positioning or the phrase "Delivered like an athlete."

## Final deliverables
Return materials in a practical format: agenda, outline, script, slide-by-slide plan, worksheet, email follow-up, or prompt pack. Include a short section titled "What to run next" with one immediately executable action.
