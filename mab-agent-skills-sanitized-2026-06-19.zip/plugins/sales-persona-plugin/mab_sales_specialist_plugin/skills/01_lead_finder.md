# Skill: Lead Finder

## Objective
Find ICP-matched leads for MAB AI Strategies LLC across target industries, employee bands, and trigger events.

## Inputs
- ICP definition
- Geography
- Industry targets
- Revenue or employee filters
- Exclusion list

## Actions
1. Pull candidate accounts from approved sources.
2. Score by fit using operational complexity, automation maturity, and urgency signals.
3. Deduplicate by domain and company name.
4. Create normalized lead records.
5. Queue records for CRM sync.

## Outputs
- Ranked lead list
- Fit score
- Reason codes
- Initial service hypothesis

## Failure handling
If source coverage is thin, downgrade confidence and route to Notification Router.
