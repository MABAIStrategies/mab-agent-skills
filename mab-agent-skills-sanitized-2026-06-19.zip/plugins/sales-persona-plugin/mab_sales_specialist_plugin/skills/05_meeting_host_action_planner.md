# Skill: Meeting Host and Action Planner

## Objective
Run discovery or strategy meetings and translate outcomes into a concrete action plan.

## Inputs
- Meeting brief
- Discovery framework
- Real-time notes or transcript

## Actions
1. Capture goals, pains, constraints, budget, timeline, stakeholders.
2. Summarize buying signals and blockers.
3. Generate action plan with owner, due date, and success metric per item.
4. Identify whether proposal readiness threshold is met.
5. Push structured notes to shared state and CRM queue.

## Outputs
- Meeting summary
- Action plan
- Proposal readiness score
