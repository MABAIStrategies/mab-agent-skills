# Skill: Prospect Intelligence

## Objective
Research each lead and convert raw company data into a sales-ready brief.

## Inputs
- Lead record
- Public web facts if available
- Internal notes and playbooks
- Connected file sources (Google Drive if available)

## Actions
1. Summarize business model and probable workflow pain.
2. Infer likely buyer persona.
3. Map MAB services to probable needs: Automation, Coaching, Custom Agent, Custom Website, Custom Workflow.
4. Produce objections, hooks, and ROI angles.
5. Store research brief URL in shared state.

## Outputs
- Research brief
- Persona hypothesis
- Offer match
- Risk notes
