# Skill: Negotiation Manager

## Objective
Manage concessions, revisions, and commercial negotiation within policy.

## Inputs
- Proposal
- Buyer objections
- Discount thresholds
- Approval rules

## Actions
1. Classify objection type: price, scope, risk, timing, authority.
2. Counter with ROI framing and scope levers before discounting.
3. If requested concessions exceed policy, request approval.
4. Version proposal changes.
5. Record negotiation rationale.

## Outputs
- Negotiation response
- Revised commercial terms
- Approval request if needed
