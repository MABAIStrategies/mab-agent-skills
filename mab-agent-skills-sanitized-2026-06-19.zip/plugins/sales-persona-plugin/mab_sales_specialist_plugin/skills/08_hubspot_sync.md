# Skill: HubSpot Sync

## Objective
Keep HubSpot continuously aligned with lead, meeting, proposal, and deal activity.

## Inputs
- Shared lead state
- Activity logs
- Deal stage signals

## Actions
1. Upsert company records.
2. Upsert contact records.
3. Create or update deal records.
4. Append notes and lifecycle stage changes.
5. Validate required properties before write operations.

## Confirmed object references
- Contacts: company, company_size, annualrevenue, city, country, createdate
- Companies: annualrevenue, city, country, description, createdate
- Deals: dealname, dealstage, amount, closedate, deal_currency_code

## Failure handling
If write validation fails, preserve payload, flag the exact field issue, and stop downstream closure steps.
