# Skill: Proposal Engine

## Objective
Generate accurate, scope-aligned proposals for MAB AI Strategies LLC.

## Inputs
- Action plan
- Pricing matrix
- Template library (Google Drive when connected)

## Actions
1. Convert pains into scope modules.
2. Price fixed-fee, retainer, and milestone options.
3. Generate assumptions, exclusions, and implementation timeline.
4. Produce approval-ready proposal artifact.
5. Update shared state and CRM with amount and stage recommendation.

## Outputs
- Proposal draft
- Pricing options
- Commercial assumptions
