# Skill: Contract Manager

## Objective
Manage contract drafting, redlines, signature flow, and execution readiness.

## Inputs
- Approved commercial terms
- MSA/SOW templates
- Legal fallback clauses

## Actions
1. Select correct contract package.
2. Insert commercial data and scope.
3. Track redlines and unresolved terms.
4. Route legal-risk exceptions for manual review.
5. Mark ready for signature and close.

## Outputs
- Contract draft
- Redline log
- Signature readiness status
