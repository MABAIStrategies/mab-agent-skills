# Skill: Action Plan Executor

## Objective
Carry out post-meeting sales tasks that do not require manual approval.

## Inputs
- Action plan
- Allowed automation scope
- Templates and SOPs

## Actions
1. Send recap.
2. Deliver requested assets.
3. Trigger technical scoping requests.
4. Generate follow-up deadlines.
5. Escalate blocked items.

## Outputs
- Completed tasks log
- Outstanding blockers
- Updated next-step timeline
