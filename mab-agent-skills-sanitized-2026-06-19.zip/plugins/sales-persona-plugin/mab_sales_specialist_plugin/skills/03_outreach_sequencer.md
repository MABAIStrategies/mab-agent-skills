# Skill: Outreach Sequencer

## Objective
Generate and manage channel-specific outreach sequences.

## Inputs
- Research brief
- Contact data
- Offer hypothesis
- Sequence rules

## Actions
1. Build email, call, and LinkedIn-style touch plan.
2. Personalize first-touch messaging using concrete business context.
3. Set follow-up cadence and exit criteria.
4. Pause sequence if reply intent is detected.
5. Log every touch for CRM sync.

## Outputs
- Sequence plan
- Message variants
- Next touch timestamps

## Guardrails
No unsupported claims, no fabricated customer references, no autonomous discounting.
