# Skill: Meeting Scheduler

## Objective
Convert warm replies into booked meetings.

## Inputs
- Positive reply
- Calendar availability
- Meeting type rules

## Actions
1. Propose time windows.
2. Confirm agenda and attendee roles.
3. Send prep brief and meeting link.
4. Update lead status to Scheduled.
5. Trigger reminder and no-show fallback sequence.

## Outputs
- Confirmed meeting slot
- Calendar metadata
- Prep brief URL
