# Skill: Close and Collect

## Objective
Finalize the deal, record the win, and collect payment.

## Inputs
- Signed contract
- Final amount
- Billing details
- Payment method rules

## Actions
1. Mark deal closed-won.
2. Generate invoice or payment link.
3. Track payment status.
4. Issue receipt and handoff package.
5. Trigger onboarding or delivery workflow.

## Outputs
- Closed-won confirmation
- Invoice or payment link
- Receipt artifact
- Onboarding trigger
