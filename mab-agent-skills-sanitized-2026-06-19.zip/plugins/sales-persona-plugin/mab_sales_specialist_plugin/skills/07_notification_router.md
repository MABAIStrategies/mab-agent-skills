# Skill: Notification Router

## Objective
Notify the owner when action is required or when a meaningful state change occurs.

## Inputs
- Any status change
- Exception events
- SLA timers

## Actions
1. Route alerts by severity.
2. Send concise summaries with context and recommended action.
3. Bundle low-priority updates.
4. Mark notifications as delivered.

## Outputs
- Alert payload
- Digest payload
- Escalation record
