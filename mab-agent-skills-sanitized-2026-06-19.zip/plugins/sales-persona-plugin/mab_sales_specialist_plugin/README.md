# MAB Sales Specialist Plugin

This bundle defines a multi-skill sales employee for MAB AI Strategies LLC. It spans the full sales lifecycle:
lead generation, prospect research, sequencing, meeting scheduling, meeting execution, action-plan delivery,
HubSpot synchronization, proposal generation, negotiation, contracting, closing, and payment collection.

## Important limitation
Google Drive content could not be inspected in this session because no Google Drive file connector was exposed.
The plugin is therefore configured to consume Drive templates and notes once that connector is enabled, but this
specific build uses placeholder bindings rather than file-grounded template extraction.

## What was tested
- JSON manifest syntax
- Skill file presence and reference integrity
- Lifecycle coverage against requested requirements
- HubSpot schema access for contacts, companies, and deals via the available connector

## Recommended next connection
Expose Google Drive in this chat or upload your source templates. Then the Proposal Engine and Contract Manager
can be rebound to exact MAB templates instead of generic placeholders.
